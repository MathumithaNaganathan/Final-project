@echo off
title B.Sc Computer Science AI Question Paper Generator
echo ==============================================================================
echo   B.Sc COMPUTER SCIENCE - AI QUESTION PAPER GENERATOR ^& LEARNING PORTAL
echo ==============================================================================
echo.

cd /d "%~dp0backend"

echo [1/2] Checking Node.js installation...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found in your system PATH.
    echo Please install Node.js from https://nodejs.org/ (LTS version)
    echo.
    pause
    exit /b 1
)

echo.
echo [2/2] Starting Server on http://localhost:5000 ...
echo Opening application in default web browser...
start http://localhost:5000

node server.js

pause
