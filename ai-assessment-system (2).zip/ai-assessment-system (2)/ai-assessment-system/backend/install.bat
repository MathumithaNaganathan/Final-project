"C:\Program Files\nodejs\npm.cmd" install --no-audit --no-fund
