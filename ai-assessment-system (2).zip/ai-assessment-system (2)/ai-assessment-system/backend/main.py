import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from database import engine, Base
from seed_data import seed_database

# Import routers
from routers import auth, syllabus, papers, study_materials, tests, analytics

# Initialize Database tables
Base.metadata.create_all(bind=engine)

# Create FastAPI app
app = FastAPI(
    title="AI Question Paper Generator & Student Assessment System",
    description="Enterprise-grade full-stack API for syllabus management, AI question paper generation, exam delivery, and student analytics.",
    version="2.0.0"
)

# Enable CORS for cross-origin frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register Module Routers
app.include_router(auth.router)
app.include_router(syllabus.router)
app.include_router(papers.router)
app.include_router(study_materials.router)
app.include_router(tests.router)
app.include_router(analytics.router)

# Seed initial database records on application startup
@app.on_event("startup")
def on_startup():
    try:
        seed_database()
    except Exception as e:
        print(f"Startup seeder notice: {e}")

# Frontend static asset serving
frontend_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=frontend_path), name="static")

@app.get("/")
def serve_index():
    index_file = os.path.join(frontend_path, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": "AI Question Paper Generator & Assessment System API is running! Access /docs for API Swagger docs."}

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "ai-assessment-system", "version": "2.0.0"}
