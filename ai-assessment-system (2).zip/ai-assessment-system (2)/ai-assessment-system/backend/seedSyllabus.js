module.exports = require('./seed/seedSyllabus');
