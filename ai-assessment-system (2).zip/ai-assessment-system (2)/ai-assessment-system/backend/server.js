const path = require("path");
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const dotenv = require("dotenv");

// Load environment variables
dotenv.config();

// Connect to Database
const { connectDB } = require("./config/db");
const { notFound, errorHandler } = require("./middleware/errorHandler");

// Import Routes
const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");
const syllabusRoutes = require("./routes/syllabusRoutes");
const questionRoutes = require("./routes/questionRoutes");
const aiRoutes = require("./routes/aiRoutes");
const paperRoutes = require("./routes/paperRoutes");
const studyRoutes = require("./routes/studyRoutes");
const testRoutes = require("./routes/testRoutes");

// Initialize Express App
const app = express();

// Body parser & CORS
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

if (process.env.NODE_ENV !== "production") {
  app.use(morgan("dev"));
}

// Static Frontend Hosting
const frontendDir = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendDir));

// API Routes
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/user", userRoutes);
app.use("/api/faculty", userRoutes);
app.use("/api/student", userRoutes);
app.use("/api", userRoutes);
app.use("/api/syllabus", syllabusRoutes);
app.use("/api/questions", questionRoutes);
app.use("/api/ai", aiRoutes);
app.use("/api/papers", paperRoutes);
app.use("/api/study-materials", studyRoutes);
app.use("/api/tests", testRoutes);
app.use("/api/results", testRoutes);

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    service: "AI Question Paper Generator & Student Assessment Portal",
    version: "2.0.0"
  });
});

// Explicit routes for dedicated Faculty and Student modules
app.get("/faculty", (req, res) => {
  res.sendFile(path.join(frontendDir, "faculty", "index.html"));
});

app.get(["/faculty/profile", "/faculty/profile.html"], (req, res) => {
  res.sendFile(path.join(frontendDir, "faculty", "profile.html"));
});

app.get("/student", (req, res) => {
  res.sendFile(path.join(frontendDir, "student", "index.html"));
});

app.get(["/student/profile", "/student/profile.html"], (req, res) => {
  res.sendFile(path.join(frontendDir, "student", "profile.html"));
});

app.get("/login", (req, res) => {
  res.sendFile(path.join(frontendDir, "login.html"));
});

// Single Page Application Fallback
app.get("*", (req, res, next) => {
  if (req.originalUrl.startsWith("/api")) {
    return next();
  }
  const indexPath = path.join(frontendDir, "index.html");
  res.sendFile(indexPath);
});

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

// Start Server immediately and initialize DB
const startServer = async () => {
  app.listen(PORT, async () => {
    console.log(`================================================================`);
    console.log(`🚀 AI Question Paper Generator & Student Portal Server running!`);
    console.log(`📡 URL: http://localhost:${PORT}`);
    console.log(`🎓 Mode: ${process.env.NODE_ENV || "development"}`);
    console.log(`================================================================`);

    // Connect to database in background
    try {
      const dbConnected = await connectDB();
      if (dbConnected) {
        const { runMasterSeedIfEmpty } = require("./seed/seed");
        await runMasterSeedIfEmpty();
      }
    } catch (seedErr) {
      console.warn("[Database/Seeder Notice]", seedErr.message);
    }
  });
};

startServer();

module.exports = app;
