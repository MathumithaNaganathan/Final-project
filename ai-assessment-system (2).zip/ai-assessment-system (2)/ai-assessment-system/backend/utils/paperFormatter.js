/**
 * Utility functions for normalizing question paper structures between
 * frontend representation, AI generator outputs, and MongoDB GeneratedPaper schema.
 */

function normalizeToSections(paperData) {
  if (!paperData) return [];

  // 1. If sections array already exists
  if (Array.isArray(paperData.sections) && paperData.sections.length > 0) {
    return paperData.sections.map((sec, idx) => {
      const partLetter = String.fromCharCode(65 + idx);
      const title = (sec.sectionTitle || sec.name || `SECTION ${partLetter}`).trim();

      const questions = (sec.questions || []).map(q => {
        const qText = (q.questionText || q.question || '').trim();
        const hasOr = Boolean(
          q.isOrPair ||
          (typeof q.orQuestion === 'string' && q.orQuestion.trim().length > 0) ||
          (q.orQuestion && typeof q.orQuestion === 'object' && (q.orQuestion.questionText || q.orQuestion.question))
        );

        let orObj = {
          questionText: '',
          options: [],
          correctAnswer: '',
          unit: ''
        };

        if (typeof q.orQuestion === 'string') {
          orObj.questionText = q.orQuestion.trim();
          orObj.unit = String(q.orUnit || q.unit || '1');
        } else if (q.orQuestion && typeof q.orQuestion === 'object') {
          orObj.questionText = (q.orQuestion.questionText || q.orQuestion.question || '').trim();
          orObj.options = Array.isArray(q.orQuestion.options) ? q.orQuestion.options : [];
          orObj.correctAnswer = q.orQuestion.correctAnswer || '';
          orObj.unit = String(q.orQuestion.unit || q.orUnit || q.unit || '1');
        }

        return {
          questionText: qText,
          options: Array.isArray(q.options) ? q.options : [],
          correctAnswer: q.correctAnswer || '',
          marks: Number(q.marks) || Number(sec.marksPerQuestion) || 1,
          difficulty: q.difficulty || 'Medium',
          unit: String(q.unit || '1'),
          isOrPair: hasOr,
          orQuestion: orObj
        };
      });

      const marksPerQ = Number(sec.marksPerQuestion) || (questions.length > 0 ? questions[0].marks : 1);

      return {
        sectionTitle: title,
        instructions: sec.instructions || `Answer ALL questions: (${questions.length} × ${marksPerQ} Marks)`,
        totalQuestions: questions.length,
        marksPerQuestion: marksPerQ,
        questions
      };
    });
  }

  // 2. If parts array exists (Thiagarajar template format)
  if (Array.isArray(paperData.parts) && paperData.parts.length > 0) {
    return paperData.parts.map((part, idx) => {
      const partLetter = (part.part || String.fromCharCode(65 + idx)).toUpperCase();
      let sectionTitle = (part.name || '').toUpperCase().trim();
      if (!sectionTitle || !sectionTitle.startsWith('SECTION')) {
        sectionTitle = `SECTION ${partLetter}`;
      }

      const questions = (part.questions || []).map(q => {
        const qText = (q.questionText || q.question || '').trim();
        const hasOr = Boolean(
          q.isOrPair ||
          (typeof q.orQuestion === 'string' && q.orQuestion.trim().length > 0) ||
          (q.orQuestion && typeof q.orQuestion === 'object' && (q.orQuestion.questionText || q.orQuestion.question))
        );

        let orObj = {
          questionText: '',
          options: [],
          correctAnswer: '',
          unit: ''
        };

        if (typeof q.orQuestion === 'string') {
          orObj.questionText = q.orQuestion.trim();
          orObj.unit = String(q.orUnit || q.unit || '1');
        } else if (q.orQuestion && typeof q.orQuestion === 'object') {
          orObj.questionText = (q.orQuestion.questionText || q.orQuestion.question || '').trim();
          orObj.options = Array.isArray(q.orQuestion.options) ? q.orQuestion.options : [];
          orObj.correctAnswer = q.orQuestion.correctAnswer || '';
          orObj.unit = String(q.orQuestion.unit || q.orUnit || q.unit || '1');
        }

        return {
          questionText: qText,
          options: Array.isArray(q.options) ? q.options : [],
          correctAnswer: q.correctAnswer || '',
          marks: Number(q.marks) || Number(part.marksPerQuestion) || 1,
          difficulty: q.difficulty || 'Medium',
          unit: String(q.unit || '1'),
          isOrPair: hasOr,
          orQuestion: orObj
        };
      });

      const marksPerQ = Number(part.marksPerQuestion) || (questions.length > 0 ? questions[0].marks : 1);

      return {
        sectionTitle,
        instructions: part.instructions || `Answer ALL questions: (${questions.length} × ${marksPerQ} Marks)`,
        totalQuestions: questions.length,
        marksPerQuestion: marksPerQ,
        questions
      };
    });
  }

  return [];
}

function calculatePaperMarks(sections) {
  if (!Array.isArray(sections)) return 0;
  let sum = 0;
  sections.forEach(s => {
    (s.questions || []).forEach(q => {
      sum += (Number(q.marks) || 0);
    });
  });
  return sum;
}

module.exports = {
  normalizeToSections,
  calculatePaperMarks
};
