const PDFDocument = require("pdfkit");
const { COURSE_CODE_MAP } = require("../models/Syllabus");

function getRomanSemester(sem) {
  const map = { 1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI" };
  return map[Number(sem)] || String(sem);
}

/**
 * Generates official Thiagarajar College (Autonomous), Madurai Question Paper PDF
 * Strictly matching the official 6-line header and academic Either/OR print layout
 */
function createQuestionPaperPDF(paperData, stream) {
  return new Promise((resolve, reject) => {
    try {
      // Standard A4 page: 595.28 x 841.89 points
      // Margins: 15mm top/bottom (42.52 pt), 20mm left/right (56.69 pt)
      const doc = new PDFDocument({
        size: "A4",
        margins: { top: 42.52, bottom: 42.52, left: 56.69, right: 56.69 },
        bufferPages: true
      });

      doc.pipe(stream);

      const startX = 56.69;
      const contentWidth = 595.28 - (2 * 56.69); // ~481.9 pt
      const endX = startX + contentWidth;

      const semRoman = paperData.semester ? `${getRomanSemester(paperData.semester)} SEMESTER` : "IV SEMESTER";
      const examMonthYear = (paperData.monthYear || paperData.examMonth || "SEP 2026").toUpperCase();
      let examTypeStr = (paperData.examType || "SUMMATIVE").toUpperCase();
      if (!examTypeStr.includes("EXAMINATION")) {
        examTypeStr = examTypeStr + " EXAMINATIONS";
      }
      const examTitle = `${semRoman} ${examTypeStr}`;
      
      const collegeName = (paperData.collegeName || "THIAGARAJAR COLLEGE (AUTONOMOUS), MADURAI - 9").toUpperCase();
      const degreeStr = paperData.degree || "B.Sc. (Computer Science)";
      const subjectName = (paperData.subject || "ADVANCED JAVA PROGRAMMING").toUpperCase();
      const courseCode = paperData.courseCode || COURSE_CODE_MAP[paperData.subject] || (paperData.semester ? `UCS23CT${paperData.semester}1` : "UCS4CT22");
      const duration = paperData.duration || "3 Hours";
      const maxMarks = paperData.totalMarks || 75;

      // Outer exam boundary border
      const drawBorder = () => {
        doc.rect(38, 28, 519, 786).strokeColor("#000000").lineWidth(0.8).stroke();
      };

      drawBorder();

      // Line 1: Top Meta Row
      // Left: "No. of Page(s): [X]", Center: "Time: [X] Hours", Right: "Exam. No. ________"
      const topY = 40;
      doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
        .text(`Time: ${duration}`, startX, topY, { width: contentWidth, align: "center" });
      doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
        .text("Exam. No. ________", startX, topY, { width: contentWidth, align: "right" });

      // Line 2: College Header (Bold, Centered, Uppercase)
      doc.y = topY + 16;
      doc.font("Times-Bold").fontSize(13.5).fillColor("#000000")
        .text(collegeName, startX, doc.y, { width: contentWidth, align: "center" });
      doc.moveDown(0.2);

      // Line 3: Degree Examination (Centered)
      doc.font("Times-Roman").fontSize(10.5).fillColor("#000000")
        .text(`${degreeStr} Degree Examination, ${examMonthYear}`, startX, doc.y, { width: contentWidth, align: "center" });
      doc.moveDown(0.2);

      // Line 4: Semester (Centered, Uppercase)
      doc.font("Times-Bold").fontSize(10.5).fillColor("#000000")
        .text(examTitle, startX, doc.y, { width: contentWidth, align: "center" });
      doc.moveDown(0.25);

      // Line 5: Subject Title (Bold, Centered, Uppercase)
      doc.font("Times-Bold").fontSize(12.5).fillColor("#000000")
        .text(subjectName, startX, doc.y, { width: contentWidth, align: "center" });
      doc.moveDown(0.35);

      // Line 6: Sub-Header Row
      // Left: "[SUBJECT CODE, e.g., UCS4CT22]", Right: "Maximum: [TOTAL MARKS, e.g., 75] Marks"
      const line6Y = doc.y;
      doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
        .text(courseCode, startX, line6Y, { width: 200, align: "left" });
      doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
        .text(`Maximum: ${maxMarks} Marks`, startX, line6Y, { width: contentWidth, align: "right" });

      // Horizontal Line Separator (<hr> or double border)
      doc.moveDown(0.35);
      const sepY = doc.y;
      doc.moveTo(startX, sepY).lineTo(endX, sepY).lineWidth(1).strokeColor("#000000").stroke();
      doc.moveTo(startX, sepY + 2.5).lineTo(endX, sepY + 2.5).lineWidth(0.5).strokeColor("#000000").stroke();
      doc.moveDown(0.45);

      let questionNumber = 1;

      // Render Sections dynamically according to faculty paper configuration
      const partsToRender = (paperData.parts && paperData.parts.length > 0)
        ? paperData.parts
        : (paperData.sections || []).map((sec, idx) => ({
            part: String.fromCharCode(65 + idx),
            name: sec.sectionTitle || `SECTION - ${String.fromCharCode(65 + idx)}`,
            instructions: sec.instructions || "Answer ALL questions:",
            marksPerQuestion: sec.marksPerQuestion,
            questions: sec.questions
          }));

      if (partsToRender && partsToRender.length > 0) {
        partsToRender.forEach((part, partIdx) => {
          if (doc.y > 690) {
            doc.addPage();
            drawBorder();
            doc.y = 42;
          }

          const partLetter = (part.part || String.fromCharCode(65 + partIdx)).toUpperCase();
          let sectionTitle = (part.name || "").toUpperCase().trim();
          if (!sectionTitle || !sectionTitle.startsWith("SECTION")) {
            sectionTitle = `SECTION - ${partLetter}`;
          }

          const qCount = part.questions ? part.questions.length : (part.count || 0);
          let partTotalMarks = 0;
          if (part.questions && part.questions.length > 0) {
            partTotalMarks = part.questions.reduce((sum, q) => sum + (Number(q.marks) || 0), 0);
          }
          const marksPerQ = part.marksPerQuestion || (qCount > 0 ? Math.round(partTotalMarks / qCount) : 1);
          const finalPartTotal = partTotalMarks || (qCount * marksPerQ);
          const weightageText = `(${qCount} x ${marksPerQ} = ${finalPartTotal} Marks)`;
          const subInstruction = part.instructions || "Answer ALL questions:";

          doc.moveDown(0.35);
          const secHeaderY = doc.y;

          // Centered: "SECTION - X"
          doc.font("Times-Bold").fontSize(11).fillColor("#000000")
            .text(sectionTitle, startX, secHeaderY, { width: contentWidth, align: "center" });

          // Right Aligned / Inline: "([Questions Count] x [Marks] = [Total] Marks)"
          doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
            .text(weightageText, startX, secHeaderY, { width: contentWidth, align: "right" });

          doc.moveDown(0.25);

          // Left Aligned Sub-instruction: "Answer ALL questions:"
          doc.font("Times-Italic").fontSize(9.5).fillColor("#000000")
            .text(subInstruction, startX, doc.y, { width: contentWidth, align: "left" });
          doc.moveDown(0.4);

          if (part.questions && part.questions.length > 0) {
            part.questions.forEach((q) => {
              if (doc.y > 700) {
                doc.addPage();
                drawBorder();
                doc.y = 42;
              }

              const isMCQ = q.questionType === "MCQ" || (q.options && Array.isArray(q.options) && q.options.length >= 2);
              const hasOr = Boolean(
                q.isOrPair ||
                (typeof q.orQuestion === "string" && q.orQuestion.trim().length > 0) ||
                (q.orQuestion && typeof q.orQuestion === "object" && (q.orQuestion.questionText || q.orQuestion.question))
              );
              const qMarks = q.marks !== undefined ? q.marks : marksPerQ;

              // Format fill-in-the-blank placeholders if present
              let qText = (q.questionText || q.question || "").replace(/_{3,}/g, "______");
              if (q.questionType === "FillBlank" && !qText.includes("______")) {
                qText += " (______)";
              }

              if (isMCQ) {
                // Section MCQ / Fill-up Question
                const curY = doc.y;
                doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
                  .text(`${questionNumber}.`, startX, curY, { width: 22 });

                doc.font("Times-Roman").fontSize(9.5).fillColor("#000000")
                  .text(qText, startX + 24, curY, { width: contentWidth - 24, align: "left" });

                doc.moveDown(0.25);

                if (q.options && q.options.length >= 2) {
                  const optY = doc.y;
                  const labels = ["(a)", "(b)", "(c)", "(d)"];
                  const col1X = startX + 20; // 20px clean indent
                  const colWidth = (contentWidth - 20) / 2 - 10;
                  const col2X = startX + 20 + colWidth + 10;

                  doc.font("Times-Roman").fontSize(9).fillColor("#000000")
                    .text(`${labels[0]} ${q.options[0]}`, col1X, optY, { width: colWidth });
                  if (q.options[1]) {
                    doc.text(`${labels[1]} ${q.options[1]}`, col2X, optY, { width: colWidth });
                  }
                  doc.moveDown(0.2);

                  if (q.options.length >= 3) {
                    const optY2 = doc.y;
                    doc.text(`${labels[2]} ${q.options[2]}`, col1X, optY2, { width: colWidth });
                    if (q.options[3]) {
                      doc.text(`${labels[3]} ${q.options[3]}`, col2X, optY2, { width: colWidth });
                    }
                    doc.moveDown(0.35);
                  } else {
                    doc.moveDown(0.25);
                  }
                } else {
                  doc.moveDown(0.3);
                }

                questionNumber++;
              } else if (hasOr) {
                // Either/OR Question with (a) ... (OR) ... (b)
                const qNum = questionNumber;
                let rawOr = "";
                if (typeof q.orQuestion === "string") {
                  rawOr = q.orQuestion;
                } else if (q.orQuestion && typeof q.orQuestion === "object") {
                  rawOr = q.orQuestion.questionText || q.orQuestion.question || "";
                }
                let orText = rawOr.replace(/_{3,}/g, "______");

                const curY = doc.y;
                doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
                  .text(`${qNum}. (a)`, startX, curY, { width: 38 });

                doc.font("Times-Roman").fontSize(9.5).fillColor("#000000")
                  .text(qText, startX + 40, curY, { width: contentWidth - 40, align: "left" });

                doc.moveDown(0.2);

                // Render " (OR) " centered between option (a) and option (b)
                doc.font("Times-Bold").fontSize(9).fillColor("#000000")
                  .text("(OR)", startX, doc.y, { width: contentWidth, align: "center" });
                doc.moveDown(0.2);

                if (doc.y > 710) {
                  doc.addPage();
                  drawBorder();
                  doc.y = 42;
                }

                // Indent option labels cleanly (margin-left: 20px)
                const curYb = doc.y;
                doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
                  .text(`(b)`, startX + 20, curYb, { width: 18 });

                doc.font("Times-Roman").fontSize(9.5).fillColor("#000000")
                  .text(orText, startX + 40, curYb, { width: contentWidth - 40, align: "left" });

                doc.moveDown(0.4);
                questionNumber++;
              } else {
                // Direct Theory Question (No OR alternative)
                const qNum = questionNumber;
                const curY = doc.y;
                doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
                  .text(`${qNum}.`, startX, curY, { width: 24 });

                doc.font("Times-Roman").fontSize(9.5).fillColor("#000000")
                  .text(qText, startX + 26, curY, { width: contentWidth - 26, align: "left" });

                doc.moveDown(0.4);
                questionNumber++;
              }
            });
          }
        });
      }

      // Page Footer / Ending: End of paper centered marker: "***" or "=== END OF QUESTION PAPER ==="
      doc.moveDown(0.6);
      if (doc.y > 740) {
        doc.addPage();
        drawBorder();
        doc.y = 45;
      }
      doc.font("Times-Bold").fontSize(9).fillColor("#000000")
        .text("*** END OF QUESTION PAPER ***", startX, doc.y, { width: contentWidth, align: "center" });

      // Finalize buffered pages: stamp "No. of Page(s): [X]" on Line 1 of Page 1, and footer on all pages
      const range = doc.bufferedPageRange();
      for (let i = range.start; i < range.start + range.count; i++) {
        doc.switchToPage(i);
        if (i === 0) {
          doc.font("Times-Bold").fontSize(9.5).fillColor("#000000")
            .text(`No. of Page(s): ${range.count}`, startX, topY, { width: 140, align: "left" });
        }
        doc.font("Times-Roman").fontSize(8.5).fillColor("#475569")
          .text(`Page ${i + 1} of ${range.count}`, startX, 804, { width: contentWidth, align: "center" });
      }

      doc.end();
      resolve();
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Dual PDF Download Option 1:
 * Before / During Test: Export ONLY Questions and Options (Strictly NO Answers included)
 */
function createMCQQuestionsOnlyPDF(testData, stream) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: "A4",
        margins: { top: 32, bottom: 32, left: 36, right: 36 },
        bufferPages: true
      });

      doc.pipe(stream);

      const semRoman = testData.semester ? `${getRomanSemester(testData.semester)} SEMESTER` : "";
      const subjectName = (testData.subject || "COMPUTER SCIENCE").toUpperCase();
      const courseCode = testData.courseCode || COURSE_CODE_MAP[testData.subject] || (testData.semester ? `UCS23CT${testData.semester}2` : "UCS23CT42");
      const unitText = testData.unit && Number(testData.unit) !== 0 ? `UNIT ${testData.unit}` : "COMPREHENSIVE ALL UNITS";
      const totalQ = testData.questions ? testData.questions.length : 0;
      const duration = testData.duration || `${Math.max(15, totalQ * 2)} Minutes`;

      const drawBorder = () => {
        doc.rect(28, 24, 538, 794).strokeColor("#0f172a").lineWidth(1).stroke();
      };

      drawBorder();

      // Header row
      const topY = 38;
      doc.font("Helvetica-Bold").fontSize(10).fillColor("#0f172a")
        .text(courseCode, 38, topY, { width: 200, align: "left" });
      doc.font("Helvetica-Bold").fontSize(10).fillColor("#0f172a")
        .text("Exam. No. [_____]", 330, topY, { width: 226, align: "right" });

      doc.moveDown(0.4);

      // Centered College Header
      doc.font("Helvetica-Bold").fontSize(12.5).fillColor("#000000")
        .text("THIAGARAJAR COLLEGE (AUTONOMOUS), MADURAI - 9", { align: "center" });
      doc.moveDown(0.2);

      doc.font("Helvetica").fontSize(10).fillColor("#0f172a")
        .text("B.Sc. (Computer Science) Degree Examination", { align: "center" });
      doc.moveDown(0.2);

      doc.font("Helvetica-Bold").fontSize(10.5).fillColor("#0f172a")
        .text(`${semRoman ? semRoman + " - " : ""}ONLINE MCQ ASSESSMENT QUESTION SHEET`, { align: "center" });
      doc.moveDown(0.3);

      doc.font("Helvetica-Bold").fontSize(13).fillColor("#000000")
        .text(`${subjectName} (${unitText})`, { align: "center" });
      doc.moveDown(0.4);

      // Meta divider
      const lineY1 = doc.y;
      doc.moveTo(34, lineY1).lineTo(560, lineY1).lineWidth(0.8).strokeColor("#0f172a").stroke();
      doc.moveDown(0.3);

      const metaY = doc.y;
      doc.font("Helvetica-Bold").fontSize(9.5).fillColor("#0f172a")
        .text(`Time: ${duration}`, 40, metaY, { width: 250, align: "left" });
      doc.font("Helvetica-Bold").fontSize(9.5).fillColor("#0f172a")
        .text(`Maximum: ${totalQ} Marks (1 Mark each)`, 305, metaY, { width: 250, align: "right" });

      doc.y = metaY + 16;
      doc.moveTo(34, doc.y).lineTo(560, doc.y).lineWidth(0.8).strokeColor("#0f172a").stroke();
      doc.moveDown(0.4);

      doc.font("Helvetica-Bold").fontSize(9).fillColor("#000000")
        .text("Instructions: Answer ALL questions. Choose the most appropriate option. (Strictly NO answers included):", 40, doc.y, { align: "left" });
      doc.moveDown(0.5);

      if (testData.questions && testData.questions.length > 0) {
        testData.questions.forEach((q, idx) => {
          if (doc.y > 700) {
            doc.addPage();
            drawBorder();
            doc.y = 42;
          }

          const curY = doc.y;
          doc.font("Helvetica-Bold").fontSize(9).fillColor("#000000")
            .text(`${idx + 1}.`, 40, curY, { width: 22 });

          doc.font("Helvetica").fontSize(9).fillColor("#0f172a")
            .text(q.question, 64, curY, { width: 450, align: "left" });

          doc.font("Helvetica").fontSize(8.5).fillColor("#334155")
            .text(`(1)`, 522, curY, { width: 34, align: "right" });

          doc.moveDown(0.2);

          if (q.options && q.options.length >= 4) {
            const optY = doc.y;
            const labels = ["(a)", "(b)", "(c)", "(d)"];
            const col1X = 72;
            const col2X = 310;
            const optWidth = 230;

            doc.font("Helvetica").fontSize(8.5).fillColor("#1e293b")
              .text(`${labels[0]} ${q.options[0]}`, col1X, optY, { width: optWidth });
            doc.text(`${labels[1]} ${q.options[1]}`, col2X, optY, { width: optWidth });
            doc.moveDown(0.2);

            const optY2 = doc.y;
            doc.text(`${labels[2]} ${q.options[2]}`, col1X, optY2, { width: optWidth });
            doc.text(`${labels[3]} ${q.options[3]}`, col2X, optY2, { width: optWidth });
            doc.moveDown(0.35);
          } else {
            doc.moveDown(0.3);
          }
        });
      }

      doc.moveDown(0.6);
      if (doc.y > 740) {
        doc.addPage();
        drawBorder();
        doc.y = 45;
      }
      doc.font("Helvetica-Bold").fontSize(8.5).fillColor("#475569")
        .text("*** END OF QUESTION SHEET ***", { align: "center" });

      const range = doc.bufferedPageRange();
      for (let i = range.start; i < range.start + range.count; i++) {
        doc.switchToPage(i);
        doc.font("Helvetica").fontSize(8).fillColor("#64748b")
          .text(`Page ${i + 1} of ${range.count}`, 38, 804, { align: "center", width: 518 });
      }

      doc.end();
      resolve();
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Dual PDF Download Option 2:
 * After Test Submission: Export full score analysis including Question, Student Answer,
 * Correct Answer, Pass/Fail status, Total Score, and Percentage.
 */
function createTestResultPDF(resultData, stream) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: "A4",
        margins: { top: 32, bottom: 32, left: 36, right: 36 },
        bufferPages: true
      });

      doc.pipe(stream);

      const semRoman = resultData.semester ? `${getRomanSemester(resultData.semester)} SEMESTER` : "";
      const subjectName = (resultData.subject || "COMPUTER SCIENCE").toUpperCase();
      const courseCode = resultData.courseCode || COURSE_CODE_MAP[resultData.subject] || (resultData.semester ? `UCS23CT${resultData.semester}2` : "UCS23CT42");
      const unitText = resultData.unit ? `UNIT ${resultData.unit}` : "ALL UNITS";

      const studentName = resultData.studentName || "Student Candidate";
      const totalMarks = resultData.totalMarks || (resultData.questions ? resultData.questions.length : 10);
      const obtainedMarks = resultData.score !== undefined ? resultData.score : (resultData.obtainedMarks !== undefined ? resultData.obtainedMarks : 0);
      const percentage = resultData.percentage !== undefined ? Number(resultData.percentage) : (totalMarks > 0 ? Number(((obtainedMarks / totalMarks) * 100).toFixed(1)) : 0);
      const isPass = percentage >= 40;
      const passFailStatus = isPass ? "PASS" : "FAIL";

      const drawBorder = () => {
        doc.rect(28, 24, 538, 794).strokeColor("#0f172a").lineWidth(1).stroke();
      };

      drawBorder();

      // Top Row
      const topY = 38;
      doc.font("Helvetica-Bold").fontSize(10).fillColor("#0f172a")
        .text(courseCode, 38, topY, { width: 200, align: "left" });
      doc.font("Helvetica-Bold").fontSize(10).fillColor(isPass ? "#166534" : "#991b1b")
        .text(`Status: ${passFailStatus}`, 330, topY, { width: 226, align: "right" });

      doc.moveDown(0.4);

      // Centered College Header
      doc.font("Helvetica-Bold").fontSize(12.5).fillColor("#000000")
        .text("THIAGARAJAR COLLEGE (AUTONOMOUS), MADURAI - 9", { align: "center" });
      doc.moveDown(0.2);

      doc.font("Helvetica").fontSize(10).fillColor("#0f172a")
        .text("B.Sc. (Computer Science) Degree Examination", { align: "center" });
      doc.moveDown(0.2);

      doc.font("Helvetica-Bold").fontSize(11).fillColor("#0f172a")
        .text(`${semRoman ? semRoman + " - " : ""}ASSESSMENT PERFORMANCE ANALYSIS SCORECARD`, { align: "center" });
      doc.moveDown(0.3);

      doc.font("Helvetica-Bold").fontSize(12.5).fillColor("#000000")
        .text(`${subjectName} (${unitText})`, { align: "center" });
      doc.moveDown(0.4);

      // Meta divider
      const lineY1 = doc.y;
      doc.moveTo(34, lineY1).lineTo(560, lineY1).lineWidth(0.8).strokeColor("#0f172a").stroke();
      doc.moveDown(0.3);

      // Student Performance Summary Box
      const boxY = doc.y;
      doc.rect(38, boxY, 518, 56).fillColor("#f8fafc").fillAndStroke("#cbd5e1");

      doc.font("Helvetica-Bold").fontSize(9.5).fillColor("#0f172a")
        .text(`Candidate Name: ${studentName}`, 48, boxY + 10, { width: 240 });
      doc.text(`Subject: ${resultData.subject}`, 48, boxY + 24, { width: 240 });
      doc.text(`Evaluation Date: ${new Date().toLocaleDateString("en-IN")}`, 48, boxY + 38, { width: 240 });

      doc.font("Helvetica-Bold").fontSize(9.5).fillColor("#0f172a")
        .text(`Total Score: ${obtainedMarks} / ${totalMarks} Marks`, 310, boxY + 10, { width: 230, align: "right" });
      doc.text(`Percentage: ${percentage}%`, 310, boxY + 24, { width: 230, align: "right" });
      doc.font("Helvetica-Bold").fontSize(10).fillColor(isPass ? "#15803d" : "#b91c1c")
        .text(`Result: ${passFailStatus} (${isPass ? "Passed Examination" : "Needs Improvement"})`, 310, boxY + 38, { width: 230, align: "right" });

      doc.y = boxY + 66;
      doc.moveTo(34, doc.y).lineTo(560, doc.y).lineWidth(0.8).strokeColor("#0f172a").stroke();
      doc.moveDown(0.4);

      // Section title
      doc.font("Helvetica-Bold").fontSize(10).fillColor("#000000")
        .text("DETAILED QUESTION-BY-QUESTION SCORE & ANSWER ANALYSIS:", 40, doc.y);
      doc.moveDown(0.4);

      if (resultData.questions && resultData.questions.length > 0) {
        resultData.questions.forEach((q, idx) => {
          if (doc.y > 670) {
            doc.addPage();
            drawBorder();
            doc.y = 42;
          }

          const isCorrect = Boolean(q.isCorrect);
          const studentAns = q.studentAnswer || "Not Answered";
          const correctAns = q.correctAnswer || "";
          const statusIcon = isCorrect ? "[CORRECT]" : (studentAns === "Not Answered" || studentAns === "Unanswered" ? "[UNANSWERED]" : "[INCORRECT]");
          const statusColor = isCorrect ? "#15803d" : (studentAns === "Not Answered" || studentAns === "Unanswered" ? "#d97706" : "#dc2626");

          // Question header
          const curY = doc.y;
          doc.font("Helvetica-Bold").fontSize(9).fillColor("#000000")
            .text(`Q${idx + 1}.`, 40, curY, { width: 24 });

          doc.font("Helvetica").fontSize(9).fillColor("#0f172a")
            .text(q.questionText || q.question || "MCQ Item", 66, curY, { width: 420, align: "left" });

          doc.font("Helvetica-Bold").fontSize(8.5).fillColor(statusColor)
            .text(statusIcon, 490, curY, { width: 66, align: "right" });

          doc.moveDown(0.2);

          // Student Answer & Correct Answer comparison
          const ansY = doc.y;
          doc.font("Helvetica").fontSize(8.5).fillColor("#334155")
            .text(`Your Answer: `, 66, ansY, { continued: true })
            .font("Helvetica-Bold").fillColor(isCorrect ? "#15803d" : "#dc2626")
            .text(studentAns, { continued: true })
            .font("Helvetica").fillColor("#334155")
            .text(`  |  Correct Answer: `, { continued: true })
            .font("Helvetica-Bold").fillColor("#15803d")
            .text(correctAns);

          doc.moveDown(0.2);

          if (q.explanation && q.explanation.trim().length > 0) {
            doc.font("Helvetica-Oblique").fontSize(8).fillColor("#475569")
              .text(`Key Explanation: ${q.explanation}`, 66, doc.y, { width: 480 });
          }

          doc.moveDown(0.35);
          doc.moveTo(66, doc.y).lineTo(555, doc.y).lineWidth(0.4).strokeColor("#e2e8f0").stroke();
          doc.moveDown(0.35);
        });
      }

      doc.moveDown(0.6);
      if (doc.y > 740) {
        doc.addPage();
        drawBorder();
        doc.y = 45;
      }
      doc.font("Helvetica-Bold").fontSize(8.5).fillColor("#475569")
        .text("*** END OF SCORECARD & ANALYSIS REPORT ***", { align: "center" });

      const range = doc.bufferedPageRange();
      for (let i = range.start; i < range.start + range.count; i++) {
        doc.switchToPage(i);
        doc.font("Helvetica").fontSize(8).fillColor("#64748b")
          .text(`Page ${i + 1} of ${range.count}`, 38, 804, { align: "center", width: 518 });
      }

      doc.end();
      resolve();
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = {
  createQuestionPaperPDF,
  createMCQQuestionsOnlyPDF,
  createTestResultPDF
};
