const Syllabus = require("../models/Syllabus");
const Question = require("../models/Question");
const { COURSE_CODE_MAP } = require("../models/Syllabus");
const { SYLLABUS_DATA } = require("../seed/seedSyllabus");
const { QUESTIONS_DATA } = require("../seed/seedQuestions");
const { MCQ_DATA } = require("../seed/seedMCQ");

// ============================================================================
// SEMANTIC DUPLICATE DETECTION ENGINE
// ============================================================================

// Academic exam directive verbs, stopwords, and generic filler words
const EXAM_DIRECTIVE_WORDS = new Set([
  "explain", "describe", "what", "is", "are", "define", "discuss", "differentiate",
  "between", "distinguish", "state", "list", "mention", "elaborate", "give", "write",
  "short", "notes", "on", "detailed", "account", "with", "example", "examples",
  "diagram", "diagrams", "neat", "sketch", "suitable", "syntax", "rules", "rule",
  "characteristics", "features", "feature", "advantages", "advantage", "disadvantages",
  "disadvantage", "comparison", "compare", "contrast", "importance", "significance",
  "role", "purpose", "primary", "concept", "concepts", "in", "of", "the", "a", "an",
  "and", "or", "to", "for", "from", "by", "its", "their", "how", "why", "which",
  "illustrate", "demonstrate", "briefly", "detail", "program", "code", "snippet",
  "implementation", "working", "principles", "principle", "overview", "trace",
  "analysis", "various", "different", "types", "type", "structure", "structures",
  "procedure", "method", "methods", "functions", "function", "state-of-the-art",
  "following", "best", "defines", "accurately", "describes", "key", "main"
]);

/**
 * Basic Porter-style suffix normalization for word stemming
 * Maps plurals, tenses, and derivational suffixes to base form
 */
function stemWord(word) {
  if (!word || word.length <= 3) return word;
  return word
    .toLowerCase()
    .replace(/(ing|edly|ingly|ed|es|s|tion|tions|ment|ments|ity|ities|ive|ives|al|ally)$/i, "");
}

/**
 * Extract core domain concept tokens from question text
 */
function extractConceptTokens(text) {
  if (!text || typeof text !== "string") return [];
  const words = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(w => w.length > 1 && !EXAM_DIRECTIVE_WORDS.has(w));
  return words.map(stemWord).filter(w => w && w.length > 1);
}

/**
 * Calculate Jaccard similarity score between two token arrays: |A ∩ B| / |A ∪ B|
 */
function jaccardSimilarity(tokensA, tokensB) {
  if (!tokensA.length || !tokensB.length) return 0;
  const setA = new Set(tokensA);
  const setB = new Set(tokensB);
  let intersection = 0;
  for (const item of setA) {
    if (setB.has(item)) intersection++;
  }
  const union = new Set([...setA, ...setB]).size;
  return union === 0 ? 0 : intersection / union;
}

/**
 * Character bigram Dice coefficient for fuzzy sequence similarity
 */
function diceBigramSimilarity(str1, str2) {
  const s1 = (str1 || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const s2 = (str2 || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!s1.length || !s2.length) return 0;
  if (s1 === s2) return 1;
  if (s1.length < 2 || s2.length < 2) return 0;

  const getBigrams = str => {
    const bigrams = new Map();
    for (let i = 0; i < str.length - 1; i++) {
      const bg = str.slice(i, i + 2);
      bigrams.set(bg, (bigrams.get(bg) || 0) + 1);
    }
    return bigrams;
  };

  const b1 = getBigrams(s1);
  const b2 = getBigrams(s2);
  let intersection = 0;
  for (const [bg, count1] of b1.entries()) {
    if (b2.has(bg)) {
      intersection += Math.min(count1, b2.get(bg));
    }
  }
  return (2 * intersection) / (s1.length - 1 + s2.length - 1);
}

/**
 * Evaluates whether two question texts are semantically duplicate or near-duplicate.
 * Returns true if Jaccard similarity or Dice sequence similarity exceeds thresholds.
 */
function isSemanticDuplicate(qText1, qText2, threshold = 0.48) {
  if (!qText1 || !qText2) return false;
  const clean1 = qText1.trim().toLowerCase();
  const clean2 = qText2.trim().toLowerCase();
  if (clean1 === clean2) return true;

  const tokens1 = extractConceptTokens(qText1);
  const tokens2 = extractConceptTokens(qText2);

  // If one of the questions has no extracted concept words, fallback to bigram dice
  if (tokens1.length === 0 || tokens2.length === 0) {
    return diceBigramSimilarity(clean1, clean2) >= 0.70;
  }

  // Jaccard similarity on concept keywords
  const jaccard = jaccardSimilarity(tokens1, tokens2);
  if (jaccard >= threshold) return true;

  // Check if smaller concept token set is almost entirely contained in the larger
  const set1 = new Set(tokens1);
  const set2 = new Set(tokens2);
  const [smaller, larger] = set1.size <= set2.size ? [set1, set2] : [set2, set1];
  let subsetMatches = 0;
  for (const t of smaller) {
    if (larger.has(t)) subsetMatches++;
  }
  if (smaller.size >= 2 && (subsetMatches / smaller.size) >= 0.85) {
    return true;
  }

  // Bigram Dice similarity
  const dice = diceBigramSimilarity(clean1, clean2);
  if (dice >= 0.65) return true;

  return false;
}

/**
 * Tests candidate question against an array of existing questions
 */
function hasDuplicateInList(candidateText, existingQuestionsList, threshold = 0.48) {
  if (!candidateText || !Array.isArray(existingQuestionsList)) return false;
  for (const item of existingQuestionsList) {
    const textA = typeof item === "string" ? item : (item.question || item.q || "");
    if (isSemanticDuplicate(candidateText, textA, threshold)) {
      return true;
    }
    const textB = typeof item === "object" ? (item.orQuestion || "") : "";
    if (textB && isSemanticDuplicate(candidateText, textB, threshold)) {
      return true;
    }
  }
  return false;
}

/**
 * Pairwise scan of all questions in a generated paper to check for duplicates
 */
function checkDuplicatesInPaper(paper) {
  if (!paper || !Array.isArray(paper.parts)) {
    return { hasDuplicates: false, duplicateCount: 0, duplicates: [] };
  }

  const flattened = [];
  paper.parts.forEach((part, partIdx) => {
    (part.questions || []).forEach((q, qIdx) => {
      const globalNum = flattened.length + 1;
      if (q.question) {
        flattened.push({
          id: `P${partIdx}_Q${qIdx}_a`,
          section: part.name || `Section ${part.part || partIdx + 1}`,
          qNum: globalNum,
          label: q.orQuestion ? `${globalNum}. (a)` : `${globalNum}.`,
          text: q.question,
          unit: q.unit,
          topic: q.topic,
          isOr: false
        });
      }
      if (q.orQuestion && q.orQuestion.trim().length > 0) {
        flattened.push({
          id: `P${partIdx}_Q${qIdx}_b`,
          section: part.name || `Section ${part.part || partIdx + 1}`,
          qNum: globalNum,
          label: `${globalNum}. (b)`,
          text: q.orQuestion,
          unit: q.orUnit || q.unit,
          topic: q.orTopic || q.topic,
          isOr: true
        });
      }
    });
  });

  const duplicates = [];
  for (let i = 0; i < flattened.length; i++) {
    for (let j = i + 1; j < flattened.length; j++) {
      const q1 = flattened[i];
      const q2 = flattened[j];
      if (isSemanticDuplicate(q1.text, q2.text)) {
        duplicates.push({
          question1: { label: q1.label, section: q1.section, text: q1.text, topic: q1.topic },
          question2: { label: q2.label, section: q2.section, text: q2.text, topic: q2.topic },
          isOrChoicePair: q1.qNum === q2.qNum,
          reason: q1.qNum === q2.qNum
            ? "Either/OR options (a) and (b) are semantically identical or too similar."
            : `Question ${q1.label} and Question ${q2.label} ask duplicate concepts.`
        });
      }
    }
  }

  return {
    hasDuplicates: duplicates.length > 0,
    duplicateCount: duplicates.length,
    duplicates
  };
}

// ============================================================================
// 1. SYLLABUS CONTEXT EXTRACTION & STRICT DATABASE FILTERING
// ============================================================================

/**
 * Retrieve exact Syllabus record using semester, subject, and unit(s)
 * Returns structured syllabus topics and strictly filtered unit bounds
 */
async function getSyllabusContext(semester, subject, selectedUnits) {
  const semNum = Number(semester) || 1;
  const cleanSubject = (subject || "").trim();

  // 1. Retrieve from MongoDB using case-insensitive match
  let syllabus = await Syllabus.findOne({
    semester: semNum,
    subject: { $regex: new RegExp(`^${cleanSubject.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i") }
  });

  if (!syllabus) {
    syllabus = await Syllabus.findOne({ semester: semNum, subject: cleanSubject });
  }

  // 2. Fallback to SYLLABUS_DATA if MongoDB has not yet been seeded
  if (!syllabus && Array.isArray(SYLLABUS_DATA)) {
    const matched = SYLLABUS_DATA.find(s =>
      s.semester === semNum && s.subject.toLowerCase() === cleanSubject.toLowerCase()
    );
    if (matched) {
      try {
        syllabus = await Syllabus.create(matched);
      } catch (err) {
        syllabus = matched;
      }
    }
  }

  const unitsData = (syllabus && Array.isArray(syllabus.units) && syllabus.units.length > 0)
    ? syllabus.units
    : [1, 2, 3, 4, 5].map(num => ({
        unitNumber: num,
        unitTitle: `Unit ${num}`,
        topics: [
          `Core Concepts of Unit ${num}`,
          `Operational Principles`,
          `Implementation Details`,
          `Advanced Applications`
        ]
      }));

  // Filter by requested selectedUnits if provided and not "All Units" (value 0)
  let targetUnits = unitsData;
  if (Array.isArray(selectedUnits) && selectedUnits.length > 0 && !selectedUnits.includes(0)) {
    const numericUnits = selectedUnits.map(Number);
    const filtered = unitsData.filter(u => numericUnits.includes(u.unitNumber));
    if (filtered.length > 0) {
      targetUnits = filtered;
    }
  }

  // Extract exact unitTitle and topics array for dynamic AI prompt & algorithmic binding
  const syllabusTopics = targetUnits.map(u => ({
    unitNumber: u.unitNumber,
    unitTitle: u.unitTitle || `Unit ${u.unitNumber}`,
    topics: (Array.isArray(u.topics) && u.topics.length > 0)
      ? u.topics
      : [`Core Concepts of Unit ${u.unitNumber}`]
  }));

  const selectedUnitNumbers = targetUnits.map(u => u.unitNumber);
  const courseCode = (syllabus && syllabus.courseCode) || COURSE_CODE_MAP[cleanSubject] || `UCS23CT${semNum}0`;

  return {
    syllabus,
    targetUnits,
    syllabusTopics,
    selectedUnitNumbers,
    courseCode,
    subjectName: syllabus ? syllabus.subject : cleanSubject
  };
}

// ============================================================================
// 2. DYNAMIC AI PROMPT CONSTRUCTION (OPENAI)
// ============================================================================

/**
 * Build dynamic AI prompt bound strictly to the selected subject and topics
 */
function buildAIPrompt(subject, semester, syllabusTopics, sectionConfigs, difficulty) {
  const prompt = `
You are an expert examiner for the subject: "${subject}" (Semester: ${semester}).
Generate questions strictly based ONLY on the following syllabus topics:
Syllabus Topics: ${JSON.stringify(syllabusTopics)}

STRICT RULES:
1. DO NOT generate questions from any other subject (e.g., if subject is "Programming in C", DO NOT generate questions for Java, DBMS, Networks, etc.).
2. All questions MUST directly map to the provided topics.
3. EITHER/OR DIFFERENTIATION RULE: For any Either/OR questions with option (a) and option (b), option (a) and option (b) MUST be on completely DIFFERENT topics or concepts within that unit. Option (b) must NOT duplicate the topic, stem, or concept of Option (a).
4. SEMANTIC DUPLICATE PREVENTION: No two questions in the entire question paper may ask the same concept or have semantic similarity. Every question must be distinct.
5. Format: Return valid JSON array matching the requested schema.

Target Difficulty Profile: ${difficulty || "Medium"}
Section Breakdown:
${JSON.stringify(sectionConfigs, null, 2)}
`;
  return prompt;
}

/**
 * Call OpenAI API if key is configured, or return null to fall back to the Algorithmic Engine
 */
async function callOpenAI(messages, responseFormat = { type: "json_object" }) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey || apiKey.trim() === "" || apiKey === "your_openai_api_key_here") {
    return null;
  }

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages,
        response_format: responseFormat,
        temperature: 0.6
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    const content = data.choices[0]?.message?.content;
    return JSON.parse(content);
  } catch (err) {
    return null;
  }
}

// ============================================================================
// ACADEMIC QUESTION GENERATION TEMPLATES & REPERTOIRE
// ============================================================================

/**
 * Generate academic question text for theory and Either/OR
 * Uses subject-specific phrasing and varied stems to eliminate repetition
 */
function generateAcademicQuestionText(subject, unitNum, topic, marks, difficulty, index) {
  const safeIdx = Math.abs(Number(index) || 0);

  if (marks <= 2) {
    const stems = [
      `Define ${topic} in ${subject}. State its primary significance.`,
      `State any two key features or advantages of ${topic}.`,
      `What is the primary role of ${topic}? Give a short example.`,
      `List any four essential properties or constraints of ${topic}.`,
      `Differentiate between fundamental constructs in ${topic}.`,
      `Mention the syntax and declaration rules used in ${topic}.`,
      `Why is ${topic} essential in modern computer science systems?`,
      `What is the runtime complexity or storage overhead associated with ${topic}?`,
      `Outline the basic working mechanism of ${topic} with a brief statement.`,
      `What happens when invalid inputs or edge conditions occur in ${topic}?`
    ];
    return stems[safeIdx % stems.length];
  } else if (marks <= 5) {
    const stems = [
      `Explain the architecture and working principles of ${topic} with a suitable diagram.`,
      `Describe the operational workflow and syntax associated with ${topic}.`,
      `Compare and contrast different approaches and variations used in ${topic}.`,
      `Write short technical notes on the significance and implementation of ${topic}.`,
      `Discuss the step-by-step procedure involved in executing ${topic}.`,
      `Analyze the role of ${topic} in system performance and resource management.`,
      `Explain how error detection and exception handling are managed in ${topic}.`,
      `Provide an algorithmic solution or code snippet demonstrating ${topic}.`,
      `Illustrate the memory allocation and execution cycle of ${topic}.`,
      `Examine the practical use cases and design trade-offs of ${topic} in ${subject}.`
    ];
    return stems[safeIdx % stems.length];
  } else if (marks <= 7) {
    const stems = [
      `Elaborate on the structural components, algorithm trace, and practical execution of ${topic} with illustrations.`,
      `Critically evaluate the performance trade-offs, advantages, and limitations of ${topic} in ${subject}.`,
      `Describe the end-to-end design patterns and data structures utilized when implementing ${topic}.`,
      `Discuss real-world applications and system integration challenges associated with ${topic}.`,
      `Compare traditional approaches with optimized state-of-the-art implementations of ${topic}.`,
      `Demonstrate the end-to-end trace of ${topic} highlighting key constraints, state transitions, and boundary rules.`
    ];
    return stems[safeIdx % stems.length];
  } else {
    // 10 Marks Comprehensive / Long Essay
    const stems = [
      `Explain in detail the concepts, architecture, and practical applications of ${topic} with complete block diagrams and illustrative code examples.`,
      `Critically analyze ${topic} in ${subject}. Discuss its algorithm design, complexity analysis, and real-world deployment challenges.`,
      `Elaborate on the complete lifecycle and structural components of ${topic} with comprehensive examples.`,
      `Demonstrate the end-to-end implementation of ${topic} highlighting key constraints, error handling, and performance optimization techniques.`,
      `Evaluate alternative architectural designs for ${topic} and justify the optimal design for large-scale computing environments.`,
      `Provide a comprehensive technical treatise on ${topic}: Discuss theory, mathematical or architectural formulation, execution steps, and industrial relevance.`
    ];
    return stems[safeIdx % stems.length];
  }
}

/**
 * Generate detailed model answer text for sample questions
 */
function generateDetailedModelAnswer(subject, topic, marks) {
  if (marks === 1) {
    return `Correct answer and explanation: Highlights the foundational definition of ${topic}, identifying key architectural traits and practical specifications in ${subject}.`;
  } else if (marks === 2) {
    return `Definition: ${topic} is an essential construct in ${subject} providing modular encapsulation and deterministic execution.\nKey Characteristics: 1. Strict boundary validation; 2. Optimized runtime memory profile.\nExample/Syntax: Implemented using standard language keywords and parameter bindings.\nGrading Key: Definition (1M) + Features/Syntax (1M).`;
  } else if (marks === 4) {
    return `Core Concept: ${topic} coordinates data transformations and operational flow in ${subject}.\nDetailed Points:\n1. Working Mechanism: Uses structured components to regulate state.\n2. Comparison/Variants: Contrasts with unoptimized direct execution by maintaining bounded overhead.\n3. Implementation Note: Requires proper initialization and error handlers.\nGrading Key: Concept explanation (2M) + Technical mechanism & code/syntax (2M).`;
  } else if (marks === 5) {
    return `1. Introduction & Architecture:\n${topic} represents a core pillar of ${subject}, responsible for coordinating workflow and data integrity.\n\n2. Working Principles:\n- Step 1: Input ingestion and validation against formal constraints.\n- Step 2: Algorithmic transformation maintaining invariant properties.\n- Step 3: State output and deterministic resource clean-up.\n\n3. Key Advantages:\n- Enhanced computational throughput\n- Fault isolation and predictable error recovery\n\n4. Grading Scheme:\n- Architecture & Diagram: 2 Marks\n- Working Principles & Syntax: 2 Marks\n- Practical Application/Example: 1 Mark`;
  } else if (marks === 7) {
    return `1. In-Depth Overview:\n${topic} is critically analyzed within ${subject} as a high-performance subsystem.\n\n2. Structural Analysis & Diagrammatic Flow:\nIllustrates interaction between primary components, memory layouts, and data pathways.\n\n3. Algorithmic Trace & Case Example:\nStep-by-step trace showing variable states, loop iterations, and boundary conditions.\n\n4. Complexity & Optimization:\n- Time Complexity: O(n log n) or O(n) depending on data density.\n- Space Complexity: O(1) auxiliary working storage.\n\n5. Grading Criteria:\n- Comprehensive Theory: 3 Marks | Block Diagram: 2 Marks | Algorithm/Trace: 2 Marks.`;
  } else {
    // 10 Marks
    return `1. Theoretical Foundations & Comprehensive Overview:\n${topic} constitutes an advanced foundational system within ${subject}. It is systematically deployed across production enterprise environments to deliver scalable, secure, and robust execution.\n\n2. Architectural Design & Component Interaction:\n- Subsystem A: Controller module managing scheduling and concurrency controls.\n- Subsystem B: Storage abstraction layer enforcing transactional atomicity.\n- Subsystem C: Interface layer processing caller requests and formatting responses.\n\n3. Complete Algorithm & Code Implementation:\nFull algorithmic formulation featuring defensive validation, structured execution, and resource cleanup.\n\n4. Complexity Analysis:\n- Best Case: O(1) instantaneous resolution\n- Average & Worst Case: O(n) linear bounds with formal mathematical proof.\n\n5. Real-World Case Study & Industrial Standards:\nDeployment in cloud environments and distributed clusters highlights its resiliency against edge failures.\n\n6. University Marking Breakdown:\n- Detailed Concept & Theory: 3 Marks\n- Architecture / Circuit / Flow Diagram: 3 Marks\n- Implementation Code / Proof: 2 Marks\n- Complexity & Case Study: 2 Marks (Total = 10 Marks).`;
  }
}

// ============================================================================
// 3. QUESTION PAPER GENERATION ENGINE (AI + ALGORITHMIC FALLBACK)
// ============================================================================

/**
 * Generate AI Question Paper with strict subject & syllabus filtering,
 * different OR (a)/(b) options, and semantic duplicate detection.
 */
async function generateAlgorithmicPaper(params) {
  const {
    semester,
    subject,
    selectedUnits,
    examType,
    monthYear,
    duration,
    totalMarks,
    difficulty,
    sections,
    sectionA,
    sectionB,
    sectionC
  } = params;

  // 1. MongoDB Syllabus Context Extraction
  const {
    syllabus,
    targetUnits,
    syllabusTopics,
    selectedUnitNumbers,
    courseCode,
    subjectName
  } = await getSyllabusContext(semester, subject, selectedUnits);

  // 2. Strictly filter database queries using { semester, subject, unit: { $in: selectedUnits } }
  const dbFilter = {
    semester: Number(semester),
    subject: subjectName,
    unit: { $in: selectedUnitNumbers }
  };

  const existingMCQs = await Question.find({
    ...dbFilter,
    questionType: "MCQ"
  }).lean();

  const existingTheory = await Question.find({
    ...dbFilter,
    questionType: "Theory"
  }).lean();

  const targetTotal = Number(totalMarks) || 75;

  // 3. Resolve Section Breakdown Configuration
  let sectionConfigs = [];
  if (Array.isArray(sections) && sections.length > 0) {
    sectionConfigs = sections.map((sec, idx) => {
      const qCount = Math.max(1, Number(sec.questionCount || sec.count) || 1);
      const mPerQ = Math.max(1, Number(sec.marksPerQuestion || sec.marksPerQ || sec.marks) || 1);
      const name = (sec.name || `Section ${String.fromCharCode(65 + idx)}`).trim();
      let partLetter = sec.part || name.replace(/^(section|part)\s*/i, "").trim();
      if (!partLetter) partLetter = String.fromCharCode(65 + idx);
      return {
        name,
        part: partLetter,
        questionCount: qCount,
        marksPerQuestion: mPerQ,
        instructions: sec.instructions,
        type: sec.type || (mPerQ === 1 ? "MCQ" : "Theory")
      };
    });
  } else if (sectionA || sectionB || sectionC) {
    if (sectionA && Number(sectionA.questionCount || sectionA.count) > 0) {
      const qCount = Number(sectionA.questionCount || sectionA.count);
      const mPerQ = Number(sectionA.marksPerQuestion || sectionA.marksPerQ || 1);
      sectionConfigs.push({
        name: sectionA.name || "Section A",
        part: "A",
        questionCount: qCount,
        marksPerQuestion: mPerQ,
        instructions: sectionA.instructions,
        type: sectionA.type || (mPerQ === 1 ? "MCQ" : "Theory")
      });
    }
    if (sectionB && Number(sectionB.questionCount || sectionB.count) > 0) {
      const qCount = Number(sectionB.questionCount || sectionB.count);
      const mPerQ = Number(sectionB.marksPerQuestion || sectionB.marksPerQ || 5);
      sectionConfigs.push({
        name: sectionB.name || "Section B",
        part: "B",
        questionCount: qCount,
        marksPerQuestion: mPerQ,
        instructions: sectionB.instructions,
        type: sectionB.type || "Theory"
      });
    }
    if (sectionC && (sectionC.enabled !== false) && Number(sectionC.questionCount || sectionC.count) > 0) {
      const qCount = Number(sectionC.questionCount || sectionC.count);
      const mPerQ = Number(sectionC.marksPerQuestion || sectionC.marksPerQ || 10);
      sectionConfigs.push({
        name: sectionC.name || "Section C",
        part: "C",
        questionCount: qCount,
        marksPerQuestion: mPerQ,
        instructions: sectionC.instructions,
        type: sectionC.type || "Theory"
      });
    }
  }

  if (sectionConfigs.length === 0) {
    sectionConfigs = [
      { name: "Section A", part: "A", questionCount: 10, marksPerQuestion: 1, type: "MCQ" },
      { name: "Section B", part: "B", questionCount: 5, marksPerQuestion: 5, type: "Theory" },
      { name: "Section C", part: "C", questionCount: 4, marksPerQuestion: 10, type: "Theory" }
    ];
  }

  // 4. Try OpenAI Generation with the specified dynamic prompt
  const aiPrompt = buildAIPrompt(subjectName, semester, syllabusTopics, sectionConfigs, difficulty);
  const openAIResult = await callOpenAI([
    {
      role: "system",
      content: `You are an expert university examiner creating a standard question paper for ${subjectName}. Output valid JSON.`
    },
    {
      role: "user",
      content: aiPrompt
    }
  ]);

  if (openAIResult && Array.isArray(openAIResult.parts) && openAIResult.parts.length === sectionConfigs.length) {
    // Validate that questions conform strictly to the subject and do not violate duplicate rules
    const paperAudit = checkDuplicatesInPaper(openAIResult);
    if (!paperAudit.hasDuplicates) {
      return {
        title: `${subjectName.toUpperCase()}`,
        collegeName: "THIAGARAJAR COLLEGE (AUTONOMOUS), MADURAI - 9",
        degree: "B.Sc. (Computer Science) Degree Examination",
        semester: Number(semester),
        subject: subjectName,
        courseCode,
        monthYear: monthYear || "APRIL 2026",
        examType: examType || "Summative Examination",
        duration: duration || "3 Hours",
        targetTotalMarks: targetTotal,
        totalMarks: targetTotal,
        difficulty: difficulty || "Medium",
        parts: openAIResult.parts
      };
    }
  }

  // 5. Algorithmic Generation with Strict Syllabus Mapping & Semantic Deduplication
  const usedQuestionsList = []; // Keeps track of all questions in paper to guarantee zero duplicates
  const parts = [];

  sectionConfigs.forEach((sec, sIdx) => {
    const qCount = Number(sec.questionCount) || 1;
    const mPerQ = Number(sec.marksPerQuestion) || 1;
    const isMCQ = sec.type === "MCQ" || (mPerQ === 1 && sec.type !== "Theory");
    const partLetter = sec.part || String.fromCharCode(65 + sIdx);

    const partObj = {
      part: partLetter,
      name: sec.name || `Section ${partLetter}`,
      instructions: sec.instructions || `Answer ALL questions: (${qCount} × ${mPerQ} = ${qCount * mPerQ} Marks)`,
      marksPerQuestion: mPerQ,
      questions: []
    };

    for (let i = 0; i < qCount; i++) {
      const u = targetUnits[(sIdx * qCount + i) % targetUnits.length];
      const topicsList = (u.topics && u.topics.length > 0)
        ? u.topics
        : [`Core Concepts of Unit ${u.unitNumber}`];

      // Select Topic A for primary question
      const topicA = topicsList[i % topicsList.length];

      if (isMCQ) {
        // Attempt to find an unused matching MCQ from the DB for this subject and unit
        let chosenMCQ = null;
        const matchingDB = existingMCQs.filter(
          m => m.unit === u.unitNumber && !hasDuplicateInList(m.question, usedQuestionsList)
        );

        if (matchingDB.length > 0) {
          chosenMCQ = matchingDB[i % matchingDB.length];
        }

        if (chosenMCQ && chosenMCQ.options && chosenMCQ.options.length >= 4) {
          usedQuestionsList.push(chosenMCQ.question);
          partObj.questions.push({
            question: chosenMCQ.question,
            marks: mPerQ,
            difficulty: chosenMCQ.difficulty || "Easy",
            unit: chosenMCQ.unit || u.unitNumber,
            topic: chosenMCQ.topic || topicA,
            questionType: "MCQ",
            options: chosenMCQ.options,
            correctAnswer: chosenMCQ.correctAnswer || chosenMCQ.options[0]
          });
        } else {
          // Generate subject-bound MCQ for topicA
          const mcqStems = [
            {
              q: `Which of the following best defines the primary purpose of ${topicA} in ${subjectName}?`,
              opts: [
                `To structure modular abstraction and optimize resource execution`,
                `To bypass memory boundary safety protocols during execution`,
                `To enforce mandatory offline compilation overhead`,
                `To eliminate data type verification completely`
              ],
              ans: `To structure modular abstraction and optimize resource execution`
            },
            {
              q: `What is a fundamental characteristic of ${topicA} in ${subjectName}?`,
              opts: [
                `Deterministic execution governed by standard language specifications`,
                `Unbounded asynchronous memory fragmentation`,
                `Total absence of state encapsulation`,
                `Incompatible runtime linking errors`
              ],
              ans: `Deterministic execution governed by standard language specifications`
            },
            {
              q: `In ${subjectName}, ${topicA} is primarily implemented to achieve:`,
              opts: [
                `High architectural cohesion and reliable state maintenance`,
                `Unrestricted global variable collisions`,
                `Bypassing error-handling cascades`,
                `Disabling register caching mechanisms`
              ],
              ans: `High architectural cohesion and reliable state maintenance`
            },
            {
              q: `What algorithmic complexity bound is typically associated with ${topicA}?`,
              opts: [
                `Bounded linear O(n) or logarithmic O(log n) efficiency`,
                `Mandatory exponential O(2^n) latency`,
                `Unbounded non-deterministic execution loops`,
                `Factorial O(n!) operational overhead`
              ],
              ans: `Bounded linear O(n) or logarithmic O(log n) efficiency`
            }
          ];

          let stemObj = mcqStems[i % mcqStems.length];
          let attempts = 0;
          while (hasDuplicateInList(stemObj.q, usedQuestionsList) && attempts < mcqStems.length) {
            attempts++;
            stemObj = mcqStems[(i + attempts) % mcqStems.length];
          }

          usedQuestionsList.push(stemObj.q);
          partObj.questions.push({
            question: stemObj.q,
            marks: mPerQ,
            difficulty: difficulty === "Mixed" ? (i % 2 === 0 ? "Easy" : "Medium") : difficulty,
            unit: u.unitNumber,
            topic: topicA,
            questionType: "MCQ",
            options: stemObj.opts,
            correctAnswer: stemObj.ans
          });
        }
      } else {
        // Theory / Descriptive question with Either/OR (a)/(b) support
        // 1. Generate Option (a)
        let qTextA = "";
        const matchingTheoryA = existingTheory.filter(
          t => t.unit === u.unitNumber && !hasDuplicateInList(t.question, usedQuestionsList)
        );

        if (matchingTheoryA.length > 0 && Math.random() > 0.4) {
          qTextA = matchingTheoryA[0].question;
        } else {
          let stemOffset = 0;
          do {
            qTextA = generateAcademicQuestionText(subjectName, u.unitNumber, topicA, mPerQ, difficulty, i + stemOffset);
            stemOffset++;
          } while (hasDuplicateInList(qTextA, usedQuestionsList) && stemOffset < 15);
        }
        usedQuestionsList.push(qTextA);

        const questionItem = {
          question: qTextA,
          marks: mPerQ,
          difficulty: difficulty === "Mixed" ? (mPerQ <= 2 ? "Easy" : mPerQ <= 5 ? "Medium" : "Hard") : difficulty,
          unit: u.unitNumber,
          topic: topicA,
          questionType: "Theory",
          answer: generateDetailedModelAnswer(subjectName, topicA, mPerQ)
        };

        // 2. Either/OR Choice: Option (b) MUST be on a DIFFERENT topic and completely distinct
        const isEitherOr = mPerQ >= 4 || sec.type === "Either/OR";
        if (isEitherOr) {
          // Find a DIFFERENT topic from the same unit
          const distinctTopics = topicsList.filter(t => t.trim().toLowerCase() !== topicA.trim().toLowerCase());
          let topicB = "";
          if (distinctTopics.length > 0) {
            topicB = distinctTopics[(i + 1) % distinctTopics.length];
          } else {
            // If the unit has only 1 topic, derive a distinct orthogonal focus
            topicB = `${topicA} Implementation & Performance Optimization`;
          }

          let qTextB = "";
          const matchingTheoryB = existingTheory.filter(
            t => t.unit === u.unitNumber &&
                 t.question !== qTextA &&
                 !isSemanticDuplicate(t.question, qTextA) &&
                 !hasDuplicateInList(t.question, usedQuestionsList)
          );

          if (matchingTheoryB.length > 0 && Math.random() > 0.4) {
            qTextB = matchingTheoryB[0].question;
          } else {
            let stemOffsetB = 5;
            let candidateB = "";
            let tries = 0;
            do {
              candidateB = generateAcademicQuestionText(subjectName, u.unitNumber, topicB, mPerQ, difficulty, i + stemOffsetB);
              stemOffsetB++;
              tries++;
            } while (
              (isSemanticDuplicate(candidateB, qTextA) || hasDuplicateInList(candidateB, usedQuestionsList)) &&
              tries < 20
            );
            qTextB = candidateB;
          }

          // Safety guarantee: If still semantic duplicate of qTextA, force distinct phrasing
          if (isSemanticDuplicate(qTextA, qTextB)) {
            qTextB = `Critically evaluate the system architecture, memory trace, and real-world implementation techniques of ${topicB} in ${subjectName}.`;
          }

          usedQuestionsList.push(qTextB);

          questionItem.orQuestion = qTextB;
          questionItem.orUnit = u.unitNumber;
          questionItem.orTopic = topicB;
          questionItem.orAnswer = generateDetailedModelAnswer(subjectName, topicB, mPerQ);
        }

        partObj.questions.push(questionItem);
      }
    }

    parts.push(partObj);
  });

  // Calculate total marks across parts
  let calculatedSum = 0;
  parts.forEach(p => {
    (p.questions || []).forEach(q => {
      calculatedSum += Number(q.marks) || 0;
    });
  });

  return {
    title: `${subjectName.toUpperCase()}`,
    collegeName: "THIAGARAJAR COLLEGE (AUTONOMOUS), MADURAI - 9",
    degree: "B.Sc. (Computer Science) Degree Examination",
    semester: Number(semester),
    subject: subjectName,
    courseCode,
    monthYear: monthYear || "APRIL 2026",
    examType: examType || "Summative Examination",
    duration: duration || "3 Hours",
    targetTotalMarks: targetTotal,
    totalMarks: calculatedSum,
    difficulty: difficulty || "Medium",
    parts
  };
}

/**
 * Main Question Paper Generation API
 */
async function generateQuestionPaper(params) {
  return await generateAlgorithmicPaper(params);
}

// ============================================================================
// 4. SINGLE QUESTION REGENERATION ENGINE
// ============================================================================

/**
 * Regenerate single question with duplicate prevention and Either/OR counterpart avoidance
 */
async function regenerateIndividualQuestion({
  semester,
  subject,
  unit,
  topic,
  marks,
  difficulty,
  currentQuestion,
  counterpartQuestion,
  excludeQuestions = [],
  isOrQuestion = false
}) {
  const semNum = Number(semester) || 1;
  const unitNum = Number(unit) || 1;
  const markVal = Number(marks) || 5;

  const { targetUnits, subjectName } = await getSyllabusContext(semNum, subject, [unitNum]);
  const matchedUnit = targetUnits.find(u => u.unitNumber === unitNum) || targetUnits[0] || {
    unitNumber: unitNum,
    topics: [topic || "Core Concept"]
  };

  const topicsList = (matchedUnit.topics && matchedUnit.topics.length > 0)
    ? matchedUnit.topics
    : [topic || "Core Concept"];

  // If regenerating an OR question and counterpart is provided, ensure a different topic is used
  let chosenTopic = topic;
  if (counterpartQuestion) {
    const counterpartTokens = extractConceptTokens(counterpartQuestion);
    const nonOverlapping = topicsList.filter(t => {
      const tTokens = extractConceptTokens(t);
      return jaccardSimilarity(tTokens, counterpartTokens) < 0.35;
    });
    if (nonOverlapping.length > 0) {
      chosenTopic = nonOverlapping[Math.floor(Math.random() * nonOverlapping.length)];
    }
  }

  // Exclusion list contains current question, counterpart question, and existing questions in section
  const forbiddenList = [currentQuestion, counterpartQuestion, ...excludeQuestions].filter(Boolean);

  let newQuestionText = "";
  let attempts = 0;
  while (attempts < 25) {
    const randomIdx = Math.floor(Math.random() * 20) + attempts;
    const candidate = generateAcademicQuestionText(
      subjectName,
      unitNum,
      chosenTopic,
      markVal,
      difficulty || "Medium",
      randomIdx
    );

    const isDup = forbiddenList.some(f => isSemanticDuplicate(candidate, f));
    if (!isDup) {
      newQuestionText = candidate;
      break;
    }
    attempts++;
  }

  if (!newQuestionText) {
    newQuestionText = `Critically evaluate the architectural patterns, algorithmic workflow, and practical applications of ${chosenTopic} in ${subjectName}.`;
  }

  return {
    question: newQuestionText,
    marks: markVal,
    difficulty: difficulty || "Medium",
    unit: unitNum,
    topic: chosenTopic,
    questionType: markVal === 1 ? "MCQ" : "Theory",
    answer: generateDetailedModelAnswer(subjectName, chosenTopic, markVal)
  };
}

// ============================================================================
// 5. STUDENT CATEGORIZED QUESTION BANK
// ============================================================================

/**
 * Generate Categorized Questions (1M, 2M, 4M, 5M, 7M, 10M) for Student Question Bank
 */
async function getCategorizedQuestionsForUnit(semester, subject, unit) {
  const { targetUnits, subjectName } = await getSyllabusContext(semester, subject, [Number(unit) || 1]);
  const matchedUnit = targetUnits.find(u => u.unitNumber === (Number(unit) || 1)) || targetUnits[0] || {
    topics: ["Core Fundamentals", "Architecture & Syntax", "Control Flow & Methods", "Implementation Techniques", "Advanced Applications"]
  };
  const topics = matchedUnit.topics || ["Core Fundamentals", "Advanced Applications"];

  const markTiers = [1, 2, 3, 4, 5, 7, 10];
  const categorized = {};

  for (const m of markTiers) {
    categorized[m] = [];
    const questionsPerTier = m === 1 ? 4 : 2;

    for (let i = 0; i < questionsPerTier; i++) {
      const top = topics[(i + m) % topics.length];

      if (m === 1) {
        categorized[m].push({
          semester: Number(semester),
          subject: subjectName,
          unit: Number(unit) || 1,
          topic: top,
          marks: 1,
          questionType: "MCQ",
          difficulty: i === 0 ? "Easy" : "Medium",
          question: `Which of the following statements is TRUE regarding ${top} in ${subjectName}?`,
          options: [
            `It enforces structured modular abstraction and resource optimization`,
            `It bypasses memory allocation safety protocols completely`,
            `It requires infinite non-deterministic recursion to terminate`,
            `It operates without any language type validation`
          ],
          correctAnswer: `It enforces structured modular abstraction and resource optimization`,
          answer: `In ${subjectName}, ${top} complies with standard language specifications providing deterministic and optimal runtime behavior.`
        });
      } else {
        const qText = generateAcademicQuestionText(subjectName, Number(unit) || 1, top, m, "Medium", i);
        categorized[m].push({
          semester: Number(semester),
          subject: subjectName,
          unit: Number(unit) || 1,
          topic: top,
          marks: m,
          questionType: "Theory",
          difficulty: m <= 4 ? "Easy" : (m <= 7 ? "Medium" : "Hard"),
          question: qText,
          answer: generateDetailedModelAnswer(subjectName, top, m)
        });
      }
    }
  }

  return categorized;
}

module.exports = {
  getSyllabusContext,
  generateQuestionPaper,
  regenerateIndividualQuestion,
  getCategorizedQuestionsForUnit,
  generateAcademicQuestionText,
  generateDetailedModelAnswer,
  isSemanticDuplicate,
  hasDuplicateInList,
  checkDuplicatesInPaper
};
