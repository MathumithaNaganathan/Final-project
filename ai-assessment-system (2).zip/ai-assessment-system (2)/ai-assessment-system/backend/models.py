import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, Float, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import Base

def generate_uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    name = Column(String(100), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="FACULTY") # 'FACULTY' | 'STUDENT' | 'ADMIN'
    department = Column(String(100), default="Computer Science & Engineering")
    profile_bio = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    syllabus_units = relationship("SyllabusUnit", back_populates="faculty", cascade="all, delete-orphan")
    question_papers = relationship("QuestionPaper", back_populates="faculty", cascade="all, delete-orphan")
    study_materials = relationship("StudyMaterial", back_populates="faculty", cascade="all, delete-orphan")
    test_attempts = relationship("TestAttempt", back_populates="student", cascade="all, delete-orphan")
    performance_summaries = relationship("PerformanceSummary", back_populates="student", cascade="all, delete-orphan")


class SyllabusUnit(Base):
    __tablename__ = "syllabus_units"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    faculty_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    subject_code = Column(String(50), nullable=False, index=True)
    subject_name = Column(String(150), nullable=False)
    unit_number = Column(Integer, nullable=False)
    unit_title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    faculty = relationship("User", back_populates="syllabus_units")
    topics = relationship("SyllabusTopic", back_populates="unit", cascade="all, delete-orphan")
    study_materials = relationship("StudyMaterial", back_populates="unit")


class SyllabusTopic(Base):
    __tablename__ = "syllabus_topics"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    unit_id = Column(String(36), ForeignKey("syllabus_units.id", ondelete="CASCADE"), nullable=False, index=True)
    topic_name = Column(String(200), nullable=False)
    learning_objectives = Column(Text, nullable=True)
    bloom_taxonomy_level = Column(String(50), default="Understand") # Remember, Understand, Apply, Analyze, Evaluate, Create
    weightage_percentage = Column(Integer, default=10)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    unit = relationship("SyllabusUnit", back_populates="topics")
    questions = relationship("Question", back_populates="topic")


class QuestionPaper(Base):
    __tablename__ = "question_papers"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    faculty_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    subject_code = Column(String(50), nullable=False, index=True)
    subject_name = Column(String(150), nullable=False)
    title = Column(String(255), nullable=False)
    paper_set = Column(String(10), default="A") # Set 'A', 'B', 'C'
    exam_duration_mins = Column(Integer, default=60)
    total_marks = Column(Integer, default=100)
    difficulty_level = Column(String(30), default="Medium") # Easy, Medium, Hard, Balanced
    instructions = Column(Text, nullable=True)
    is_published = Column(Boolean, default=False, index=True)
    ai_prompt_meta = Column(Text, nullable=True) # JSON serialized parameters/context
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    faculty = relationship("User", back_populates="question_papers")
    questions = relationship("Question", back_populates="paper", cascade="all, delete-orphan", order_by="Question.question_order")
    test_attempts = relationship("TestAttempt", back_populates="paper", cascade="all, delete-orphan")


class Question(Base):
    __tablename__ = "questions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    paper_id = Column(String(36), ForeignKey("question_papers.id", ondelete="CASCADE"), nullable=False, index=True)
    topic_id = Column(String(36), ForeignKey("syllabus_topics.id", ondelete="SET NULL"), nullable=True)
    question_order = Column(Integer, nullable=False, default=1)
    question_type = Column(String(30), nullable=False, default="MCQ") # MCQ, SHORT_ANSWER, LONG_ANSWER, NUMERICAL, CASE_STUDY
    question_text = Column(Text, nullable=False)
    options = Column(Text, nullable=True) # JSON string: [{"id": "A", "text": "..."}, {"id": "B", "text": "..."}]
    correct_answer = Column(Text, nullable=True) # Option key (e.g. "A") or rubric/text
    explanation = Column(Text, nullable=True)
    marks = Column(Integer, default=1)
    bloom_level = Column(String(50), default="Understand")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    paper = relationship("QuestionPaper", back_populates="questions")
    topic = relationship("SyllabusTopic", back_populates="questions")
    answers = relationship("StudentAnswer", back_populates="question", cascade="all, delete-orphan")


class StudyMaterial(Base):
    __tablename__ = "study_materials"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    faculty_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    unit_id = Column(String(36), ForeignKey("syllabus_units.id", ondelete="SET NULL"), nullable=True, index=True)
    title = Column(String(255), nullable=False)
    material_type = Column(String(50), nullable=False, default="PDF_NOTE") # PDF_NOTE, REFERENCE_LINK, SLIDES, SAMPLE_PAPER
    file_url = Column(Text, nullable=False)
    description = Column(Text, nullable=True)
    tags = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    faculty = relationship("User", back_populates="study_materials")
    unit = relationship("SyllabusUnit", back_populates="study_materials")


class TestAttempt(Base):
    __tablename__ = "test_attempts"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    student_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    paper_id = Column(String(36), ForeignKey("question_papers.id", ondelete="CASCADE"), nullable=False, index=True)
    start_time = Column(DateTime, default=datetime.utcnow)
    submission_time = Column(DateTime, nullable=True)
    status = Column(String(30), default="IN_PROGRESS") # IN_PROGRESS, SUBMITTED, GRADED, TIMED_OUT
    total_score = Column(Float, default=0.0)
    max_possible_score = Column(Float, default=0.0)
    percentage = Column(Float, default=0.0)
    time_taken_seconds = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    student = relationship("User", back_populates="test_attempts")
    paper = relationship("QuestionPaper", back_populates="test_attempts")
    answers = relationship("StudentAnswer", back_populates="attempt", cascade="all, delete-orphan")


class StudentAnswer(Base):
    __tablename__ = "student_answers"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    attempt_id = Column(String(36), ForeignKey("test_attempts.id", ondelete="CASCADE"), nullable=False, index=True)
    question_id = Column(String(36), ForeignKey("questions.id", ondelete="CASCADE"), nullable=False, index=True)
    selected_option = Column(Text, nullable=True)
    text_response = Column(Text, nullable=True)
    is_correct = Column(Boolean, default=False)
    awarded_marks = Column(Float, default=0.0)
    faculty_or_ai_feedback = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    attempt = relationship("TestAttempt", back_populates="answers")
    question = relationship("Question", back_populates="answers")


class PerformanceSummary(Base):
    __tablename__ = "performance_summaries"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    student_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_code = Column(String(50), nullable=False)
    topic_name = Column(String(200), nullable=False)
    total_questions_attempted = Column(Integer, default=0)
    total_questions_correct = Column(Integer, default=0)
    mastery_percentage = Column(Float, default=0.0)
    last_evaluated_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    student = relationship("User", back_populates="performance_summaries")
