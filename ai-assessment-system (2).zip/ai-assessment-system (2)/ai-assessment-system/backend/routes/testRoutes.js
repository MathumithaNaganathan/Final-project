const express = require("express");
const router = express.Router();
const {
  getTestQuestions,
  submitTest,
  getStudentResults,
  getResultById,
  exportTestQuestionsPDF,
  exportTestResultPDF,
  downloadResultPDFById
} = require("../controllers/testController");
const { optionalProtect } = require("../middleware/authMiddleware");

// Test question delivery
router.get("/questions", getTestQuestions);

// Test submission & result creation
router.post("/submit", optionalProtect, submitTest);
router.post("/", optionalProtect, submitTest);

// PDF Exports
// Dual PDF 1: Before/During Test - Questions and Options only, strictly NO answers
router.post("/export-questions-pdf", exportTestQuestionsPDF);

// Dual PDF 2: After Test Submission - Full score analysis & answers scorecard
router.post("/export-result-pdf", exportTestResultPDF);
router.get("/results/:id/pdf", downloadResultPDFById);
router.get("/:id/pdf", downloadResultPDFById);

// Student historical results
router.get("/student/:studentId", optionalProtect, getStudentResults);
router.get("/results/student/:studentId", optionalProtect, getStudentResults);
router.get("/my-results", optionalProtect, getStudentResults);
router.get("/history", optionalProtect, getStudentResults);

// Single result details
router.get("/details/:id", getResultById);
router.get("/results/:id", getResultById);
router.get("/:id", getResultById);

module.exports = router;
