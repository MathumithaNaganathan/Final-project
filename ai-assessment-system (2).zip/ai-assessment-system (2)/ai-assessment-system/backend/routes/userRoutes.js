const express = require("express");
const router = express.Router();
const {
  getUserProfile,
  updateUserProfile,
  changeUserPassword
} = require("../controllers/userController");
const { protect } = require("../middleware/authMiddleware");

// All routes are protected by authMiddleware
router.get("/profile", protect, getUserProfile);
router.get("/me", protect, getUserProfile);
router.get("/user/profile", protect, getUserProfile);
router.get("/faculty/profile", protect, getUserProfile);
router.get("/student/profile", protect, getUserProfile);

router.put("/profile", protect, updateUserProfile);
router.patch("/profile", protect, updateUserProfile);
router.put("/user/profile", protect, updateUserProfile);
router.patch("/user/profile", protect, updateUserProfile);
router.put("/faculty/profile", protect, updateUserProfile);
router.patch("/faculty/profile", protect, updateUserProfile);
router.put("/student/profile", protect, updateUserProfile);
router.patch("/student/profile", protect, updateUserProfile);

router.put("/change-password", protect, changeUserPassword);
router.put("/user/change-password", protect, changeUserPassword);
router.put("/faculty/change-password", protect, changeUserPassword);
router.put("/student/change-password", protect, changeUserPassword);

module.exports = router;
