const express = require("express");
const router = express.Router();
const {
  getStudyMaterials,
  getMaterialById,
  createStudyMaterial,
  updateStudyMaterial,
  deleteStudyMaterial
} = require("../controllers/studyController");
const { protect, requireRole } = require("../middleware/authMiddleware");

router.get("/", getStudyMaterials);
router.get("/:id", getMaterialById);
router.post("/", protect, requireRole("Faculty"), createStudyMaterial);
router.put("/:id", protect, requireRole("Faculty"), updateStudyMaterial);
router.delete("/:id", protect, requireRole("Faculty"), deleteStudyMaterial);

module.exports = router;
