const express = require("express");
const router = express.Router();
const {
  getQuestions,
  getCategorizedQuestions,
  getQuestionsBySubject,
  getQuestionsByUnit,
  getQuestionById,
  createQuestion,
  updateQuestion,
  deleteQuestion
} = require("../controllers/questionController");
const { optionalProtect } = require("../middleware/authMiddleware");

// Categorized sample questions (1M, 2M, 4M, 5M, 7M, 10M) with Detailed Answers for Students
router.get("/categorized/:semester/:subject/:unit", getCategorizedQuestions);

router.get("/", getQuestions);
router.get("/:semester/:subject", getQuestionsBySubject);
router.get("/:semester/:subject/:unit", getQuestionsByUnit);
router.get("/id/:id", getQuestionById);

// Question CRUD
router.post("/", optionalProtect, createQuestion);
router.put("/:id", optionalProtect, updateQuestion);
router.delete("/:id", optionalProtect, deleteQuestion);

module.exports = router;
