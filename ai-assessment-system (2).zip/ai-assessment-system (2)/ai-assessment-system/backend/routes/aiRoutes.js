const express = require("express");
const router = express.Router();
const {
  generatePaper,
  regenerateQuestion,
  checkPaperDuplicates,
  getCategorizedQuestions
} = require("../controllers/aiController");
const { optionalProtect } = require("../middleware/authMiddleware");

// Faculty AI Question Paper Generation & Duplicate Auditing
router.post("/generate-paper", optionalProtect, generatePaper);
router.post("/regenerate-question", optionalProtect, regenerateQuestion);
router.post("/check-duplicates", optionalProtect, checkPaperDuplicates);

// Student Categorized Question Bank (1M, 2M, 4M, 5M, 7M, 10M with Detailed Answers)
router.get("/categorized-questions", optionalProtect, getCategorizedQuestions);

module.exports = router;
