const express = require("express");
const router = express.Router();
const {
  savePaper,
  getAllPapers,
  getPaperById,
  updatePaper,
  deletePaper,
  downloadPaperPDF,
  exportDirectPDF
} = require("../controllers/paperController");
const { optionalProtect, protect, requireRole } = require("../middleware/authMiddleware");

// Faculty check guardrail: students are forbidden from saving/mutating papers
const facultyOnlyGuard = (req, res, next) => {
  if (req.user && req.user.role && req.user.role.toLowerCase() === "student") {
    return res.status(403).json({ success: false, message: "Forbidden: Students cannot manage examination papers" });
  }
  next();
};

router.post("/", optionalProtect, facultyOnlyGuard, savePaper);
router.get("/", optionalProtect, getAllPapers);
router.get("/history", optionalProtect, getAllPapers);
router.post("/export-pdf", optionalProtect, exportDirectPDF);
router.get("/:id", optionalProtect, getPaperById);
router.put("/:id", optionalProtect, facultyOnlyGuard, updatePaper);
router.delete("/:id", optionalProtect, facultyOnlyGuard, deletePaper);
router.get("/:id/pdf", optionalProtect, downloadPaperPDF);

module.exports = router;
