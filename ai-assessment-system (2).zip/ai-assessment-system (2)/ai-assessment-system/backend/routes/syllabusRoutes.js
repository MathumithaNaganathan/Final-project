const express = require("express");
const router = express.Router();
const {
  getAllSyllabus,
  getSyllabusBySemester,
  getSubjectUnits,
  createSyllabus,
  updateSyllabus,
  deleteSyllabus,
  addUnitTopic,
  updateUnitTopic,
  deleteUnitTopic,
  updateUnitTitle
} = require("../controllers/syllabusController");
const { optionalProtect } = require("../middleware/authMiddleware");

// Read operations (public / accessible to faculty & students)
router.get("/", getAllSyllabus);
router.get("/:semester", getSyllabusBySemester);
router.get("/:semester/:subject", getSubjectUnits);

// Full CRUD operations for Faculty (authenticated)
router.post("/", optionalProtect, createSyllabus);
router.put("/:id", optionalProtect, updateSyllabus);
router.delete("/:id", optionalProtect, deleteSyllabus);

// Dynamic Unit & Topic CRUD operations (Instant DB sync)
router.post("/:id/units/:unitNumber/topics", optionalProtect, addUnitTopic);
router.put("/:id/units/:unitNumber/topics/:topicIndex", optionalProtect, updateUnitTopic);
router.delete("/:id/units/:unitNumber/topics/:topicIndex", optionalProtect, deleteUnitTopic);
router.put("/:id/units/:unitNumber/title", optionalProtect, updateUnitTitle);

module.exports = router;
