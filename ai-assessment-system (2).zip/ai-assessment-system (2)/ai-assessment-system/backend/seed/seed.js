const path = require('path');
const mongoose = require("mongoose");
const { connectDB } = require("../config/db");
const User = require("../models/User");
const Syllabus = require("../models/Syllabus");
const Question = require("../models/Question");
const StudyMaterial = require("../models/StudyMaterial");
const GeneratedPaper = require("../models/GeneratedPaper");

const { seedSyllabus } = require("./seedSyllabus");
const { seedQuestions } = require("./seedQuestions");
const { seedMCQ } = require("./seedMCQ");
const { seedStudyMaterials } = require("./seedStudyMaterials");

async function seedUsers() {
  await User.deleteMany({});
  
  const faculty = await User.create({
    name: "Dr. Rajesh Sharma",
    username: "faculty",
    email: "faculty@college.edu",
    password: "faculty123",
    role: "Faculty",
    department: "B.Sc Computer Science",
    semester: 1,
    phone: "9876543210",
    dob: "1982-05-15",
    gender: "Male",
    address: "Department of Computer Science, Thiagarajar College (Autonomous), Madurai - 625009",
    designation: "Associate Professor",
    qualification: "M.Sc., M.Phil., Ph.D.",
    profilePhoto: ""
  });

  const student = await User.create({
    name: "Anand Kumar",
    username: "student",
    email: "student@college.edu",
    password: "student123",
    role: "Student",
    department: "B.Sc Computer Science",
    semester: 1,
    phone: "9843215678",
    dob: "2004-08-20",
    gender: "Male",
    address: "12, College Road, Teppakulam, Madurai - 625009",
    designation: "",
    qualification: "Higher Secondary (Computer Science)",
    profilePhoto: ""
  });

  console.log("[Seed] Created default Faculty (username: faculty / pass: faculty123) and Student (username: student / pass: student123)");
  return { faculty, student };
}

async function runMasterSeed() {
  console.log("[Seed] Starting master database population...");
  await seedUsers();
  await seedSyllabus();
  await Question.deleteMany({});
  await seedQuestions();
  await seedMCQ();
  await seedStudyMaterials();
  console.log("[Seed] Master database seeding completed successfully!");
}

async function runMasterSeedIfEmpty() {
  const syllabusCount = await Syllabus.countDocuments();
  const userCount = await User.countDocuments();
  const questionCount = await Question.countDocuments();
  if (syllabusCount === 0 || userCount === 0 || questionCount === 0) {
    console.log("[Seed] Database is uninitialized or missing collections. Populating default data...");
    await runMasterSeed();
  } else {
    console.log("[Seed] Database already contains initialized records (" + syllabusCount + " syllabus subjects, " + questionCount + " questions).");
  }
}

if (require.main === module) {
  (async () => {
    try {
      require("dotenv").config({ path: path.join(__dirname, "..", ".env") });
      await connectDB();
      await runMasterSeed();
      console.log("[Seed] Done. Exiting.");
      process.exit(0);
    } catch (err) {
      console.error("[Seed] Fatal error:", err);
      process.exit(1);
    }
  })();
}

module.exports = { runMasterSeed, runMasterSeedIfEmpty };
