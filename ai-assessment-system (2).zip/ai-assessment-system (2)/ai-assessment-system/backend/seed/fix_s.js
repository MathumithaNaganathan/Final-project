﻿const fs = require("fs");
const path = require("path");

const sPath = path.join(__dirname, "seed.js");
let content = fs.readFileSync(sPath, "utf8");
content = "const path = require('path');\n" + content;
fs.writeFileSync(sPath, content, "utf8");
console.log("Fixed seed.js path import");
