﻿const fs = require("fs");
const path = require("path");

const S = [
  // Sem 1
  [1, "Programming in C", "Theory", [
    [1, "Introduction to C & Fundamentals", ["Introduction to C", "Constants", "Variables", "Data Types", "Operators", "Expressions", "Input/Output"]],
    [2, "Control Statements & Loops", ["If", "If-Else", "Nested If", "Else-If Ladder", "Switch", "Goto", "While", "Do-While", "For", "Jumps"]],
    [3, "Arrays, Strings & Functions", ["Arrays", "2D/Multidimensional Arrays", "Strings", "String Functions", "Functions", "Recursion", "Scope/Lifetime"]],
    [4, "Structures & Unions", ["Structures", "Arrays of Structures", "Nested Structures", "Structures & Functions", "Unions", "Preprocessor"]],
    [5, "Pointers & File Management", ["Pointers", "Pointer Expressions", "Pointers & Arrays/Functions/Structures", "File Management", "Command-Line Arguments"]]
  ]],
  [1, "Programming in C Lab", "Lab", [
    [1, "Simple Programs", ["Interest calculation", "Biggest number", "Odd/Even", "Prime numbers", "Unit conversions", "LCM & GCD", "Fibonacci sequence"]],
    [2, "Array & Matrix Operations", ["Array ordering", "Matrix addition & multiplication", "Matrix transpose", "Call by value & address", "Recursion"]],
    [3, "String Manipulations", ["Alphabetical ordering", "Palindrome check", "Substring extraction", "Vowels & consonants counting"]],
    [4, "Structure Programs", ["Student mark list processing", "Electricity EB bill calculation"]],
    [5, "File Handling Programs", ["Odd/even numbers file separation", "Vowels/non-vowels extraction"]]
  ]],
  [1, "Discrete Mathematics", "Theory", [
    [1, "Propositional Logic", ["Propositional Logic", "Propositions", "Conditional Statements", "Truth Tables", "Logical Equivalences", "De Morgan's Laws", "Logic Circuits"]],
    [2, "Sets, Functions & Sequences", ["Sets", "Set Operations", "Functions", "One-to-One/Onto", "Inverse & Composition", "Sequences", "Recurrence Relations", "Summations"]],
    [3, "Number Theory", ["Divisibility", "Division Algorithm", "Modular Arithmetic", "Representation of Integers", "Prime Numbers & GCD"]],
    [4, "Relations", ["Relations", "Properties of Relations", "Matrices of Relations", "Digraphs", "Closure", "Warshall's Algorithm", "Equivalence Relations/Classes"]],
    [5, "Graphs", ["Graphs", "Graph Models", "Terminology", "Special Graphs", "Bipartite Graphs", "Adjacency & Incidence Matrices"]]
  ]],
  [1, "Digital Principles and Computer Organisation", "Theory", [
    [1, "Number Systems & Digital Logic", ["Number Systems", "Binary/Octal/Hexadecimal", "ASCII", "Excess-3", "Gray Code", "Basic & Universal Gates"]],
    [2, "Boolean Algebra & Arithmetic", ["Boolean Laws", "SOP/POS", "K-Map Simplification", "Don't-Care Conditions", "Binary Arithmetic", "2's Complement", "Adders/Subtracters"]],
    [3, "Combinational Logic Circuits", ["Multiplexer", "Demultiplexer", "Decoders", "Encoders", "Seven-Segment Decoder", "XOR Gates", "Parity Generators/Checkers"]],
    [4, "Central Processing Unit (CPU)", ["CPU Architecture", "Register Organization", "Stack Organization", "Instruction Formats", "Addressing Modes", "Data Transfer/Manipulation", "Program Control"]],
    [5, "Computer Arithmetic", ["Multiplication Algorithms", "Division Algorithms", "Floating-Point Arithmetic", "Decimal Arithmetic Unit"]]
  ]],

  // Sem 2
  [2, "Java Programming", "Theory", [
    [1, "Java Fundamentals & OOP", ["History/Evolution of Java", "OOP Principles", "Data Types", "Arrays", "Classes & Objects", "Methods", "Constructors", "This Keyword", "Garbage Collection"]],
    [2, "Classes, Inheritance & Polymorphism", ["Method Overloading", "Recursion", "Access Control", "Static & Final", "Varargs", "Inheritance", "Method Overriding", "Dynamic Dispatch", "Abstract Classes"]],
    [3, "Packages, Interfaces & Exceptions", ["Packages", "Interfaces", "Exception Handling", "Try/Catch", "Throw/Throws/Finally", "User-Defined Exceptions"]],
    [4, "Multithreading & Strings", ["Multithreading Model", "Thread Priorities", "Thread Synchronization", "Inter-thread Communication", "String & StringBuffer Classes"]],
    [5, "AWT & GUI Components", ["AWT Hierarchy", "Windows & Frames", "Graphics & Colors", "Fonts", "AWT Controls", "Layout Managers", "Menus"]]
  ]],
  [2, "Java Programming Lab", "Lab", [
    [1, "Core OOP Programs", ["Arrays manipulation", "Method & constructor overloading", "Inheritance hierarchies", "Method overriding", "Dynamic method dispatch"]],
    [2, "Packages & Interfaces", ["Interface implementation", "Custom package creation & import", "Exception handling try-catch", "Custom exceptions"]],
    [3, "Multithreading & Strings", ["Multiple threads execution", "Thread synchronization", "String & StringBuffer processing"]],
    [4, "Graphics & AWT", ["Graphics drawing", "Font & Color settings", "AWT Button & TextField controls"]],
    [5, "Layout & Applets", ["FlowLayout & BorderLayout", "CardLayout & GridLayout", "Interactive GUI forms"]]
  ]],
  [2, "Basic Statistics", "Theory", [
    [1, "Measures of Central Tendency & Dispersion", ["Introduction to Statistics", "Arithmetic Mean", "Median & Mode", "Measures of Dispersion", "Standard Deviation", "Variance"]],
    [2, "Correlation & Regression", ["Correlation Overview", "Karl Pearson Correlation", "Rank Correlation", "Linear Regression", "Regression Lines & Equations"]],
    [3, "Probability Theory", ["Probability Basics", "Addition & Multiplication Theorems", "Conditional Probability", "Bayes' Theorem"]],
    [4, "Random Variables & Expectation", ["Random Variables", "Probability Distributions", "Mathematical Expectation", "Moment Generating Function", "Characteristic Function"]],
    [5, "Theoretical Distributions", ["Binomial Distribution", "Poisson Distribution", "Normal Distribution", "Properties & Applications"]]
  ]],
  [2, "Web Technology Lab", "Lab", [
    [1, "HTML5 Fundamentals", ["HTML presentation tags", "List tags", "Table structures", "Frame & iframe tags", "Form elements & validation", "Navigation menus"]],
    [2, "CSS3 Styling & Layouts", ["Responsive webpage design", "CSS styles & selectors", "CSS box model", "Positioning & Z-index", "Color palettes & gradients", "CSS transformations & transitions"]],
    [3, "JavaScript Basics", ["JavaScript conditions & loops", "User-defined functions", "Array, Number, String objects", "Date & Math objects"]],
    [4, "DOM & Event Handling", ["DOM manipulation", "Mouse & keyboard events", "Dynamic HTML updates"]],
    [5, "Interactive Web Applications", ["Client-side form validation", "Student marksheet generator", "Shopping cart prototype"]]
  ]],

  // Sem 3
  [3, "Data Structures and Algorithms", "Theory", [
    [1, "Algorithm Analysis & ADT", ["Basic Terminology", "Data Structure Classification", "Operations on Data Structures", "Abstract Data Types (ADT)", "Algorithms", "Control Structures", "Time & Space Complexity", "Big-O, Omega, Theta Notations"]],
    [2, "Arrays & Linked Lists", ["Arrays & Pointers", "Strings & Pointer Manipulations", "Singly Linked List", "Circular Linked List", "Doubly Linked List", "Linked List Applications"]],
    [3, "Stacks & Queues", ["Stack ADT using Arrays & Linked Lists", "Multiple Stacks", "Infix to Postfix Conversion", "Evaluation of Postfix", "Queues Representation", "Circular Queue", "Deque", "Priority Queue"]],
    [4, "Trees & Binary Search Trees", ["Tree Terminology", "Binary Trees", "Binary Search Trees (BST)", "Expression Trees", "Tree Traversals (Inorder, Preorder, Postorder)", "Huffman Tree", "BST Operations (Insert, Delete, Search)", "Threaded Binary Trees"]],
    [5, "Graphs & Sorting Algorithms", ["Graph Terminology", "Directed Graphs", "Adjacency Matrix & List Representation", "BFS & DFS Graph Traversals", "Dijkstra Shortest Path", "Linear & Binary Search", "Bubble, Insertion, Selection, Merge, Quick Sort"]]
  ]],
  [3, "Data Structures and Algorithm Lab", "Lab", [
    [1, "Searching & Basic Array Operations", ["Linear Search", "Binary Search", "Merging two sorted arrays", "Multidimensional array manipulation"]],
    [2, "String & Singly Linked List", ["String operations & transformations", "Character/word/line counting in text", "Singly linked list insertion & deletion", "Node counting in linked list"]],
    [3, "Advanced Linked Lists", ["Doubly linked list operations", "Circular linked list implementation", "Polynomial addition using linked list"]],
    [4, "Stack & Queue Implementations", ["Stack using array", "Stack using linked list", "Infix to postfix conversion", "Queue using array", "Queue using linked list"]],
    [5, "Sorting Algorithms", ["Bubble sort & Insertion sort", "Selection sort & Merge sort", "Quick sort implementation"]]
  ]],
  [3, "RDBMS / DBMS", "Theory", [
    [1, "Database Concepts & Relational Model", ["Database Systems Purpose", "Views of Data", "Database Languages", "DBMS Architecture & Engine", "Users & Administrators", "Relational Model", "Database Schema", "Keys (Primary, Foreign, Candidate)", "Schema Diagrams", "Relational Algebra"]],
    [2, "Data Modeling & Normalization", ["Data Modeling", "Functional Dependencies", "Database Normalization (1NF, 2NF, 3NF, BCNF)", "Dependency Diagrams", "Denormalization", "ER Model", "Entity Sets & Attributes", "Relationship Cardinalities"]],
    [3, "SQL: DDL & DML", ["SQL Fundamentals", "DDL (CREATE, ALTER, DROP, RENAME, TRUNCATE)", "Data Types & Constraints", "DML (INSERT, UPDATE, DELETE, SELECT)", "WHERE Clause", "Sorting with ORDER BY", "Substitution Variables", "CASE Expressions"]],
    [4, "SQL Functions, Joins & PL/SQL Basics", ["Built-in Functions (String, Math, Date)", "Grouping with GROUP BY & HAVING", "SQL Joins (Inner, Left, Right, Full Outer)", "Views", "PL/SQL Fundamentals", "PL/SQL Block Structure", "Variables & Assignment", "Bind Variables"]],
    [5, "Advanced PL/SQL & Transactions", ["PL/SQL Control Structures", "Nested Blocks", "SQL in PL/SQL", "Transactions & ACID Properties", "Exception Handling", "PL/SQL Records", "Stored Procedures & Functions", "Database Triggers"]]
  ]],
  [3, "RDBMS Lab / DBMS Lab", "Lab", [
    [1, "DDL & Table Constraints", ["Table creation with Primary Key & Foreign Key", "ALTER and DROP table commands", "Check and Unique constraints"]],
    [2, "DML & Queries", ["INSERT, UPDATE, DELETE records", "Complex SELECT queries with WHERE and ORDER BY", "Aggregate functions and GROUP BY"]],
    [3, "Joins & Subqueries", ["Inner and Outer Joins", "Nested subqueries and Correlated queries", "Set operations (UNION, INTERSECT, MINUS)"]],
    [4, "Views & Security", ["Creating and updating Views", "Grant and Revoke authorizations"]],
    [5, "PL/SQL Programming", ["PL/SQL Conditional and Loop programs", "Stored Procedures and Functions", "Explicit Cursors", "Triggers implementation"]]
  ]],
  [3, "Computational Methods", "Theory", [
    [1, "Roots of Equations", ["Bisection Method", "Successive Approximation", "Method of False Position (Regula Falsi)", "Newton-Raphson Method", "Horner's Method"]],
    [2, "Linear Algebraic Equations", ["Gauss Elimination", "Gauss-Jordan Method", "Matrix Triangularisation", "Crout's Method", "Iterative Methods (Jacobi, Gauss-Seidel)"]],
    [3, "Interpolation", ["Linear Interpolation", "Newton's Forward Interpolation", "Newton's Backward Interpolation", "Divided Differences", "Newton's Divided Difference Formula", "Lagrange Interpolation", "Inverse Interpolation"]],
    [4, "Numerical Differentiation & Integration", ["Numerical Differentiation", "Newton's Differences Differentiation", "Trapezoidal Rule", "Romberg's Method", "Simpson's 1/3 Rule", "Simpson's 3/8 Rule"]],
    [5, "Numerical Solution of ODEs", ["Taylor's Series Method", "Euler's Method", "Improved & Modified Euler's Method", "Runge-Kutta 4th Order Method", "Predictor-Corrector Methods", "Milne's Method"]]
  ]],

  // Sem 4
  [4, "Advanced Java Programming", "Theory", [
    [1, "Java Collections & Networking", ["Java Collections Framework", "ArrayList & LinkedList", "HashSet, LinkedHashSet, TreeSet", "PriorityQueue & ArrayDeque", "HashMap & TreeMap", "TCP/IP Sockets", "UDP Datagram Sockets"]],
    [2, "Swing GUI Development", ["Swing Architecture", "JComponent Classes", "Event Handling in Swing", "Swing Controls (JButton, JTextField, JTable, JTree, JDialog)"]],
    [3, "JDBC & Database Connectivity", ["JDBC Drivers & Architecture", "JDBC Interfaces (Connection, Statement, PreparedStatement, ResultSet)", "Database Connection Steps", "Executing CRUD Queries"]],
    [4, "Servlet Technology", ["Servlet Architecture", "Servlet Lifecycle", "GenericServlet & HttpServlet", "Request & Response Handling", "Session Tracking", "Cookies & HTTP Sessions"]],
    [5, "JSP (Java Server Pages)", ["JSP Architecture & Engine", "JSP Syntax & Directives", "Scriptlets, Expressions & Declarations", "JSP Implicit Objects", "JavaBeans in JSP", "JSP Database Access"]]
  ]],
  [4, "Advanced Java Programming Lab", "Lab", [
    [1, "Collections & Networking", ["Collections and Iterator implementations", "TCP Client-Server Chat", "UDP Message Transmission"]],
    [2, "Swing GUI Applications", ["Swing Event Handling", "Student Registration Form with JTable", "Menu-driven desktop tool"]],
    [3, "JDBC Database Operations", ["JDBC CRUD operations", "PreparedStatements with parameterized queries", "ResultSet metadata processing"]],
    [4, "Servlet Web Applications", ["Servlet authentication system", "Servlet CRUD application", "Session tracking with cookies"]],
    [5, "JSP Web Applications", ["JSP form processing", "JSP database integration", "JSP login and portal session"]]
  ]],
  [4, "Computer Networks", "Theory", [
    [1, "Data Communications & Reference Models", ["Data Communication Components", "Networks & Topologies", "Network Types (LAN, MAN, WAN)", "OSI 7-Layer Model", "TCP/IP Protocol Suite", "Protocol Layering"]],
    [2, "Physical & Data Link Layers", ["Transmission Media (Guided & Unguided)", "Data Link Layer Services", "Framing Techniques", "Error Detection & Correction (CRC, Hamming)", "Ethernet & CSMA/CD"]],
    [3, "Network Layer & Routing", ["Hubs, Switches & Routers", "Network Layer Services", "Packet Switching", "IPv4 Addressing & Subnetting", "ICMP & Mobile IP", "Routing Algorithms (Distance Vector, Link State)"]],
    [4, "Transport Layer Protocols", ["Transport Services", "Port Addressing", "Encapsulation & Multiplexing", "Flow Control & Error Control", "Congestion Control", "UDP Protocol", "TCP Protocol & 3-Way Handshake", "TCP Timers"]],
    [5, "Application Layer & Services", ["Application Layer Paradigms", "HTTP & HTTPS", "World Wide Web (WWW)", "FTP Protocol", "Electronic Mail (SMTP, POP3, IMAP)", "TELNET & SSH", "Domain Name System (DNS)"]]
  ]],
  [4, "PHP Programming Lab", "Lab", [
    [1, "PHP Fundamentals", ["PHP syntax and variables", "Constants and data types", "Operators and expressions", "Control statements and loops"]],
    [2, "Arrays & Strings", ["Indexed and associative arrays", "Key-value pair manipulations", "String handling functions", "Math and date functions"]],
    [3, "Functions & Forms", ["User-defined functions and recursion", "HTML form processing with GET and POST", "Form validation"]],
    [4, "Cookies & Sessions", ["Cookie creation and retrieval", "Session management and tracking", "User login authentication"]],
    [5, "MySQL Integration", ["Connecting PHP with MySQL", "User registration form insertion", "Displaying and updating database records"]]
  ]],
  [4, "Operations Research", "Theory", [
    [1, "Linear Programming Problems (LPP)", ["Operations Research Overview", "LPP Formulation", "Assumptions of Linear Programming", "Canonical & Standard Forms", "Graphical Solution Method"]],
    [2, "Simplex Method", ["Simplex Maximization Algorithm", "Artificial Variable Techniques", "Two-Phase Method", "Big-M (Penalty) Method"]],
    [3, "Duality in LPP", ["Concept of Duality", "Primal-Dual Relationships", "Formulation of Dual Problems", "Dual Simplex Method"]],
    [4, "Transportation Problems", ["Transportation Model Formulation", "North-West Corner Rule", "Least Cost Method", "Vogel's Approximation Method (VAM)", "Optimality Test (MODI / Stepping Stone)"]],
    [5, "Assignment Problems", ["Assignment Problem Formulation", "Hungarian Algorithm for Solution", "Unbalanced Assignment Problems", "Maximization Cases", "Travelling Salesperson Problem"]]
  ]],

  // Sem 5
  [5, "Advanced Computer Networks", "Theory", [
    [1, "Routing & Switch Architecture", ["Routing Concepts", "Static vs Dynamic Routing", "Routing Tables & Metrics", "Switching Technologies", "MAC Address Table", "VLAN Concepts", "Basic Switch Configuration"]],
    [2, "Routing Protocols & Spanning Tree", ["Routing Information Protocol (RIP)", "OSPF Protocol", "EIGRP Protocol", "Border Gateway Protocol (BGP)", "Spanning Tree Protocol (STP)", "VLAN Trunking (802.1Q)"]],
    [3, "EtherChannel & Network Troubleshooting", ["Ethernet Channel & Link Aggregation", "Load Balancing", "Network Troubleshooting Tools (Ping, Traceroute, Netstat)", "TCP/UDP Analysis", "Routing Issue Resolution", "Performance Optimization"]],
    [4, "Network Security & Quality of Service", ["Network Security Fundamentals", "Threats & Vulnerabilities", "Firewalls & Packet Filters", "Quality of Service (QoS)", "Bandwidth Management", "Latency & Jitter Control"]],
    [5, "Modern Perimeter Security & AAA", ["Modern Security Threats", "Cisco Router Security", "AAA (Authentication, Authorization, Accounting)", "Firewall Technologies & DMZ", "Intrusion Prevention Systems (IPS)", "LAN Security Best Practices"]]
  ]],
  [5, "Advanced Computer Networks Lab", "Lab", [
    [1, "Network Topologies", ["LAN, WAN, MAN simulation", "Subnetting and IP configuration"]],
    [2, "Switching & VLANs", ["Switch configuration", "VLAN segmentation and trunking", "Inter-VLAN routing"]],
    [3, "Static & Dynamic Routing", ["Static routing setup", "RIP configuration", "OSPF single and multi-area routing"]],
    [4, "Advanced Protocols", ["EIGRP configuration", "BGP peering setup", "Access Control Lists (ACL)"]],
    [5, "Packet Analysis", ["Wireshark packet capture", "Packet Tracer monitoring and troubleshooting"]]
  ]],
  [5, "Cloud Computing", "Theory", [
    [1, "Cloud Vision & Foundations", ["Cloud Computing Vision & Definition", "Reference Model", "Cloud Characteristics", "Distributed Systems Evolution", "Virtualization Overview", "Web 2.0 & SOA", "AWS, Google App Engine, Microsoft Azure", "Hadoop & Salesforce/Aneka"]],
    [2, "Virtualization Technology", ["Virtualization Characteristics", "Virtualization Taxonomy", "Execution Virtualization", "Hardware Virtualization", "Virtualization Advantages & Disadvantages", "Hypervisors: Xen, VMware, Hyper-V, KVM"]],
    [3, "Cloud Architecture & Service Models", ["Cloud Architecture", "Infrastructure as a Service (IaaS)", "Platform as a Service (PaaS)", "Software as a Service (SaaS)", "Deployment Models (Public, Private, Hybrid, Community)", "Cloud Economics", "Interoperability & Scalability", "Security & Privacy"]],
    [4, "Cloud Platforms & Technologies", ["Amazon Web Services (EC2, S3, RDS, IAM)", "Google App Engine Architecture", "Microsoft Azure Cloud Services", "SQL Azure & NoSQL in Cloud"]],
    [5, "Cloud Applications & Use Cases", ["Scientific & High-Performance Applications", "Healthcare & Biology Clouds", "Geoscience Data Processing", "CRM & ERP Solutions", "Productivity & Collaboration Suites", "Social Networking & Media Streaming", "Cloud Gaming"]]
  ]],
  [5, "Cloud Computing Lab", "Lab", [
    [1, "Virtual Machines & EC2", ["Creating AWS EC2 Linux instances", "SSH connection and security groups", "Apache web server setup on cloud"]],
    [2, "Storage & IAM", ["AWS S3 bucket creation and permissions", "IAM user creation and policy attachment", "EBS volume attachment and snapshots"]],
    [3, "Serverless & Database", ["AWS Lambda function deployment", "RDS MySQL database instance creation", "Connecting web app to cloud DB"]],
    [4, "Networking & Scaling", ["VPC configuration with subnets", "Application Load Balancer setup", "Auto-scaling groups configuration"]],
    [5, "PaaS Deployment", ["Deploying web app on Google App Engine", "Heroku/Render app deployment"]]
  ]],
  [5, "Linear Algebra", "Theory", [
    [1, "Matrices & Gaussian Elimination", ["Matrix Operations", "Gaussian Elimination", "Matrix Multiplication", "Triangular Factors (LU Decomposition)", "Row Exchanges & Permutation Matrices", "Inverses & Transposes"]],
    [2, "Vector Spaces & Subspaces", ["Vector Spaces & Subspaces", "Solving Ax=0 and Ax=b", "Linear Independence", "Basis and Dimension", "The Four Fundamental Subspaces", "Linear Transformations"]],
    [3, "Orthogonality & Projections", ["Orthogonality of Vectors", "Orthogonal Subspaces", "Projections onto Subspaces", "Least Squares Approximations", "Orthogonal Bases", "Gram-Schmidt Process"]],
    [4, "Eigenvalues & Eigenvectors", ["Eigenvalues and Eigenvectors Definition", "Diagonalization of a Matrix", "Difference Equations", "Powers of Matrix A", "Matrix Exponentials"]],
    [5, "Positive Definite Matrices & SVD", ["Positive Definite Matrices", "Minima, Maxima and Saddle Points", "Tests for Positive Definiteness", "Singular Value Decomposition (SVD)", "Principal Component Analysis (PCA) Foundations"]]
  ]],

  // Sem 6
  [6, "AI & Machine Learning", "Theory", [
    [1, "Data Science & AI/ML Foundations", ["Data Science Overview", "Artificial Intelligence Concepts", "Machine Learning & Deep Learning", "Supervised vs Unsupervised Learning", "AI Applications across Industries", "ML Development Tools", "Scikit-Learn Framework"]],
    [2, "Classification Algorithms", ["Classification Overview", "K-Nearest Neighbors (KNN)", "Decision Tree Classifiers", "Entropy & Information Gain", "Random Forest Ensembles", "Support Vector Machines (SVM)", "Kernel Tricks"]],
    [3, "Regression Analysis", ["Regression Concepts", "Simple Linear Regression", "Multiple Linear Regression", "Polynomial Regression", "Logistic Regression for Binary Outcomes", "Maximum Likelihood Estimation (MLE)", "Cost Functions & Gradient Descent"]],
    [4, "Unsupervised Learning & Clustering", ["Unsupervised Learning Paradigms", "K-Means Clustering", "Hierarchical Clustering", "Association Rule Mining (Apriori)", "Anomaly & Outlier Detection", "Dimensionality Reduction (PCA)"]],
    [5, "Feature Engineering & AI Process Automation", ["Feature Engineering Techniques", "Data Transformation & Scaling", "Feature Selection Methods", "Process Automation with Selenium", "ChatGPT / LLM API Automation with Python", "Model Evaluation Metrics (Precision, Recall, F1-Score, ROC-AUC)"]]
  ]],
  [6, "AI & ML Lab", "Lab", [
    [1, "Data Preprocessing & EDA", ["Data cleaning and missing value imputation", "Exploratory Data Analysis (EDA) with visualization", "Feature scaling and normalization"]],
    [2, "Supervised Learning Models", ["Linear Regression implementation", "Logistic Regression on classification dataset", "K-Nearest Neighbors (KNN) model"]],
    [3, "Tree & Ensemble Models", ["Decision Tree Classifier and visual tree export", "Random Forest Classifier and feature importance", "Support Vector Machine (SVM)"]],
    [4, "Clustering & Unsupervised Learning", ["K-Means clustering and Elbow method", "PCA dimensionality reduction on high-dimensional data"]],
    [5, "AI Automation", ["ChatGPT/LLM API integration with Python", "Automated email generator script", "Web scraping and automated Excel report generation"]]
  ]],
  [6, "Data Analytics with Python", "Theory", [
    [1, "Python Basics & Core Structures", ["Python Features & Execution", "Python Virtual Machine (PVM)", "Memory Management & Garbage Collection", "Data Types & Operators", "Input/Output Formatting", "Control Statements", "Python Arrays"]],
    [2, "Python Collections & Functional Programming", ["Python Lists & Methods", "Tuples & Immutability", "Functions & Scope", "Dictionaries & Key-Value Operations", "Lambda Functions", "List & Dict Comprehensions", "Map, Filter, Reduce"]],
    [3, "Data Analysis Workflow & Libraries", ["Data Analysis Process", "Data Extraction & Preparation", "Data Cleaning Techniques", "Data Visualization Principles", "Predictive Modeling Basics", "Model Validation", "NumPy, Pandas, Matplotlib, SciPy Ecosystem"]],
    [4, "NumPy & Pandas Structures", ["NumPy ndarray Object", "Array Indexing, Slicing & Iterating", "Boolean Indexing", "Shape Manipulation & Broadcasting", "Pandas Series & DataFrames", "Data Mapping, Sorting & Ranking", "Correlation & Covariance", "Handling Missing Data (NaN)"]],
    [5, "Data Transformation & Visualization", ["Reading & Writing CSV, Excel & Text Files", "Data Preparation & Merging", "Concatenation & Pivoting", "Matplotlib & Seaborn Visualization", "Line, Histogram, Bar, Pie Charts & Scatter Plots", "Jupyter Notebook Visualizations"]]
  ]],
  [6, "Data Analytics with Python Lab", "Lab", [
    [1, "Python Basics", ["Control statements and loop programs", "Custom functions and lambda expressions", "List, set, tuple, dictionary manipulations"]],
    [2, "NumPy Operations", ["NumPy array creation and indexing", "Matrix operations and broadcasting", "Statistical operations on NumPy arrays"]],
    [3, "Pandas DataFrames", ["DataFrame creation from CSV files", "Data filtering, grouping and aggregation", "Handling missing values and data cleaning"]],
    [4, "Statistical Analysis", ["Correlation and covariance matrices", "Descriptive statistics summary", "Normal distribution curves"]],
    [5, "Data Visualization", ["Matplotlib bar charts and histograms", "Seaborn heatmaps and scatter plots", "Interactive dashboards in Jupyter"]]
  ]],
  [6, "Operating Systems", "Theory", [
    [1, "OS Overview & System Calls", ["Operating System Functions", "OS Structures & Architectures", "OS Operations & Dual-Mode Execution", "Operating System Environments", "OS Services", "User Interfaces", "System Calls & System Programs"]],
    [2, "Process Management & CPU Scheduling", ["Process Concept & Process Control Block (PCB)", "Process Scheduling Queues", "Process Operations (Creation, Termination)", "Inter-Process Communication (IPC)", "CPU Scheduling Concepts", "Scheduling Algorithms (FCFS, SJF, Priority, Round Robin, Multilevel Queue)"]],
    [3, "Process Synchronization & Deadlocks", ["Process Synchronization", "Critical Section Problem", "Peterson's Solution", "Semaphores & Mutexes", "Classic Synchronization Problems", "Deadlock Definition & Characterization", "Deadlock Prevention, Avoidance (Banker's Algorithm), Detection & Recovery"]],
    [4, "Memory Management & Virtual Memory", ["Memory Management Fundamentals", "Swapping", "Contiguous Memory Allocation", "Paging Architecture", "Segmentation", "Virtual Memory Concepts", "Demand Paging", "Page Replacement Algorithms (FIFO, LRU, Optimal)", "Allocation of Frames & Thrashing"]],
    [5, "File Systems & OS Security", ["File Concepts & Attributes", "File Access Methods (Sequential, Direct)", "File Allocation Methods (Contiguous, Linked, Indexed)", "Free-Space Management", "OS Security Goals", "Program, System & Network Threats", "Protection Mechanisms & Access Control"]]
  ]],
  [6, "Data Mining and Warehousing", "Theory", [
    [1, "Data Mining Foundations & KDD", ["Data Mining Overview", "Classification & Regression Concepts", "Time Series & Prediction", "Clustering & Summarization", "Association Rules & Sequence Discovery", "Knowledge Discovery in Databases (KDD) Process", "Data Mining Issues & Metrics", "Social Implications of Data Mining"]],
    [2, "Classification Techniques", ["Classification & Prediction Tasks", "Bayesian Classification (Naive Bayes)", "K-Nearest Neighbor (KNN)", "Decision Tree Induction: ID3 Algorithm", "C4.5 Algorithm", "CART Algorithm", "Attribute Selection Measures"]],
    [3, "Cluster Analysis", ["Clustering Concepts & Types", "Similarity & Distance Measures", "Outlier Analysis", "Hierarchical Clustering (Agglomerative, Divisive)", "Partitional Clustering (K-Means, K-Medoids)", "Minimum Spanning Tree (MST) Clustering"]],
    [4, "Association Rule Mining", ["Association Rule Mining Concepts", "Large Itemsets & Support-Confidence Framework", "Apriori Algorithm", "Sampling & Partitioning Approaches", "Parallel & Distributed Association Algorithms", "Incremental Association Rules"]],
    [5, "Advanced Data Mining", ["Web Mining (Content, Structure, Usage)", "Spatial Data Mining", "Spatial Classification & Clustering", "Temporal Mining & Time Series Patterns", "Temporal Association Rules"]]
  ]],
  [6, "Open Source Technology Lab", "Lab", [
    [1, "Linux Installation & Environment", ["Linux Client OS installation (Ubuntu)", "Linux Server OS installation", "Dual-boot and VirtualBox setup"]],
    [2, "Linux Commands & Shell Scripting", ["Essential Linux file & directory commands", "User and permission management (chmod, chown)", "Shell scripting with variables, conditionals, loops", "Gawk and sed text processing"]],
    [3, "Software & Runtimes Installation", ["Package managers (APT, YUM)", "Installing Python, GCC, Java on Linux", "Environment variables and PATH configuration"]],
    [4, "Web Server & Database Setup", ["Apache2 web server installation and virtual hosts", "MySQL server installation and security setup", "PHP installation and Apache module configuration"]],
    [5, "LAMP Stack Integration", ["Connecting PHP with MySQL on Linux", "Deploying open source web application", "Backup and restore MySQL database in Linux"]]
  ]]
];

const formattedSyllabus = S.map(([sem, sub, type, units]) => ({
  semester: sem,
  subject: sub,
  subjectType: type,
  units: units.map(([num, title, topics]) => ({
    unitNumber: num,
    unitTitle: title,
    topics
  }))
}));

const syllabusFileContent = "const Syllabus = require('../models/Syllabus');\n\nconst SYLLABUS_DATA = " + JSON.stringify(formattedSyllabus, null, 2) + ";\n\nasync function seedSyllabus() {\n  await Syllabus.deleteMany({});\n  const inserted = await Syllabus.insertMany(SYLLABUS_DATA);\n  console.log('[Seed] Seeded ' + inserted.length + ' syllabus records for Semesters 1 to 6');\n  return inserted;\n}\n\nmodule.exports = { seedSyllabus, SYLLABUS_DATA };\n";

fs.writeFileSync(path.join(__dirname, "seedSyllabus.js"), syllabusFileContent, "utf8");
console.log("Successfully created seedSyllabus.js");
