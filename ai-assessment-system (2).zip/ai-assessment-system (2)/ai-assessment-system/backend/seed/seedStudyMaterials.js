const StudyMaterial = require('../models/StudyMaterial');

const STUDY_MATERIALS_DATA = [
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types & Operators",
    "title": "Comprehensive Guide to C Data Types and Operator Precedence",
    "content": "<h3>1. Introduction & Overview</h3>\n<p>In C programming, data types specify the type and size of data associated with variables. C supports primitive data types (<code>char</code>, <code>int</code>, <code>float</code>, <code>double</code>, <code>void</code>) and derived types (arrays, pointers, structures, unions).</p>\n\n<h3>2. Key Definitions</h3>\n<ul>\n  <li><strong>Primitive Data Types:</strong> Fundamental storage representations built into the compiler.</li>\n  <li><strong>Signed vs. Unsigned:</strong> Signed types reserve the MSB (Most Significant Bit) for sign; unsigned types utilize all bits for positive magnitude, doubling the positive range.</li>\n  <li><strong>Operator Precedence:</strong> Dictates the priority order in which operators in an expression are evaluated.</li>\n</ul>\n\n<h3>3. Important Points & Memory Sizes</h3>\n<table border=\"1\" cellpadding=\"6\" style=\"border-collapse: collapse; width: 100%; margin: 10px 0;\">\n  <tr style=\"background-color: #f1f5f9;\">\n    <th>Type</th><th>Bytes</th><th>Format Specifier</th><th>Typical Range</th>\n  </tr>\n  <tr><td>char</td><td>1</td><td>%c</td><td>-128 to 127</td></tr>\n  <tr><td>int</td><td>4</td><td>%d / %i</td><td>-2,147,483,648 to 2,147,483,647</td></tr>\n  <tr><td>float</td><td>4</td><td>%f</td><td>3.4E-38 to 3.4E+38 (6 decimal places)</td></tr>\n  <tr><td>double</td><td>8</td><td>%lf</td><td>1.7E-308 to 1.7E+308 (15 decimal places)</td></tr>\n</table>\n\n<h3>4. Code Example</h3>\n<pre style=\"background: #1e293b; color: #f8fafc; padding: 12px; border-radius: 8px;\"><code>#include &lt;stdio.h&gt;\n\nint main() {\n    int count = 10;\n    float price = 99.50f;\n    char grade = 'A';\n    \n    printf(\"Item Count: %d | Unit Price: $%.2f | Grade: %c\\n\", count, price, grade);\n    return 0;\n}</code></pre>\n\n<h3>5. Reference Notes & Best Practices</h3>\n<p>Always initialize local variables before use to avoid undefined garbage values. Use <code>sizeof()</code> operator for architecture-independent memory calculations.</p>"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "title": "Stack and Queue Abstract Data Types: Concepts, Operations, and Applications",
    "content": "<h3>1. Overview of Linear Data Structures</h3>\n<p>Stacks and Queues are fundamental linear ADTs where insertion and deletion operations follow strict sequential rules.</p>\n\n<h3>2. Stack ADT (LIFO Principle)</h3>\n<p>A Stack operates on the <strong>Last-In, First-Out (LIFO)</strong> principle. Operations:</p>\n<ul>\n  <li><code>push(x)</code>: Adds element x to top of stack. Time Complexity: <strong>O(1)</strong></li>\n  <li><code>pop()</code>: Removes and returns element from top. Time Complexity: <strong>O(1)</strong></li>\n  <li><code>peek() / top()</code>: Inspects top element without removal. Time Complexity: <strong>O(1)</strong></li>\n  <li><code>isEmpty() / isFull()</code>: Checks boundary conditions.</li>\n</ul>\n\n<h3>3. Applications of Stacks</h3>\n<ol>\n  <li>Infix to Postfix expression conversion and arithmetic evaluation.</li>\n  <li>Backtracking algorithms (Maze solving, N-Queens problem).</li>\n  <li>Function call execution and runtime stack frame management.</li>\n  <li>Undo/Redo buffers in text editors.</li>\n</ol>\n\n<h3>4. Queue ADT (FIFO Principle)</h3>\n<p>A Queue operates on the <strong>First-In, First-Out (FIFO)</strong> principle. Elements enter at the <code>rear</code> and leave from the <code>front</code>.</p>\n<ul>\n  <li><strong>Circular Queue:</strong> Overcomes linear queue memory wastage by wrapping indices: <code>rear = (rear + 1) % capacity</code>.</li>\n  <li><strong>Priority Queue:</strong> Elements are dequeued based on priority value rather than arrival order.</li>\n</ul>"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 2,
    "topic": "Data Modeling & Normalization",
    "title": "Relational Database Normalization: 1NF to BCNF with Functional Dependencies",
    "content": "<h3>1. Introduction to Normalization</h3>\n<p>Database Normalization is the systematic process of organizing fields and tables in a relational database to minimize redundancy and eliminate anomalies (Insertion, Update, Deletion anomalies).</p>\n\n<h3>2. Normal Forms Hierarchy</h3>\n<ul>\n  <li><strong>First Normal Form (1NF):</strong> All table attributes must contain atomic (indivisible) values. No repeating groups or arrays allowed.</li>\n  <li><strong>Second Normal Form (2NF):</strong> Must be in 1NF and have NO Partial Functional Dependency. Every non-prime attribute must be fully functionally dependent on the whole candidate key.</li>\n  <li><strong>Third Normal Form (3NF):</strong> Must be in 2NF and have NO Transitive Dependency (X &rarr; Y and Y &rarr; Z where X is superkey and Z is non-prime).</li>\n  <li><strong>Boyce-Codd Normal Form (BCNF):</strong> A stricter 3.5NF where for every non-trivial functional dependency X &rarr; Y, X MUST be a Super Key.</li>\n</ul>\n\n<h3>3. Real-World Normalization Example</h3>\n<p>Consider an unnormalized Student Course record with multiple courses per row. Decomposing into <code>Students(StudentID, Name, Dept)</code> and <code>Enrollments(StudentID, CourseID, Grade)</code> establishes 3NF compliance.</p>"
  },
  {
    "semester": 6,
    "subject": "AI & Machine Learning",
    "unit": 1,
    "topic": "Data Science & AI/ML Foundations",
    "title": "Foundations of Artificial Intelligence, Machine Learning, and Scikit-Learn",
    "content": "<h3>1. Core Taxonomy of AI, ML, and Deep Learning</h3>\n<p>Artificial Intelligence represents the broad science of simulating human intelligence in machines. Machine Learning is a subset focusing on algorithms that learn from empirical data without explicit rule programming.</p>\n\n<h3>2. Machine Learning Paradigms</h3>\n<ul>\n  <li><strong>Supervised Learning:</strong> Learns mapping function <code>y = f(x)</code> from labeled dataset. Tasks: Classification (discrete targets) and Regression (continuous values).</li>\n  <li><strong>Unsupervised Learning:</strong> Uncovers latent structures in unlabeled data. Tasks: K-Means Clustering, Principal Component Analysis (PCA), Association Rules.</li>\n  <li><strong>Reinforcement Learning:</strong> Goal-directed learning via trial-and-error feedback from an environment (rewards/penalties).</li>\n</ul>\n\n<h3>3. Model Evaluation Metrics</h3>\n<table border=\"1\" cellpadding=\"6\" style=\"border-collapse: collapse; width: 100%;\">\n  <tr style=\"background-color: #f1f5f9;\"><th>Metric</th><th>Formula</th><th>Use Case</th></tr>\n  <tr><td>Accuracy</td><td>(TP + TN) / (TP + TN + FP + FN)</td><td>Balanced class distributions</td></tr>\n  <tr><td>Precision</td><td>TP / (TP + FP)</td><td>Minimizing False Positives (Spam filtering)</td></tr>\n  <tr><td>Recall (Sensitivity)</td><td>TP / (TP + FN)</td><td>Minimizing False Negatives (Medical diagnosis)</td></tr>\n  <tr><td>F1-Score</td><td>2 * (Precision * Recall) / (Precision + Recall)</td><td>Harmonic mean for imbalanced data</td></tr>\n</table>"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "Process Management & CPU Scheduling",
    "title": "Operating Systems: Process Control, State Transitions, and CPU Scheduling",
    "content": "<h3>1. Process Concepts & Process Control Block (PCB)</h3>\n<p>A process is a program in execution containing program counter, stack, data section, and registers. The Operating System represents each process using a <strong>Process Control Block (PCB)</strong>.</p>\n\n<h3>2. CPU Scheduling Metrics</h3>\n<ul>\n  <li><strong>CPU Utilization:</strong> Percentage of time CPU is actively busy.</li>\n  <li><strong>Throughput:</strong> Number of processes completed per unit time.</li>\n  <li><strong>Turnaround Time:</strong> Interval from process submission to completion.</li>\n  <li><strong>Waiting Time:</strong> Total duration spent in the ready queue.</li>\n  <li><strong>Response Time:</strong> Time from submission to first response output.</li>\n</ul>\n\n<h3>3. Classic Scheduling Algorithms</h3>\n<ol>\n  <li><strong>FCFS (First-Come, First-Served):</strong> Non-preemptive, easy to implement, vulnerable to convoy effect.</li>\n  <li><strong>SJF (Shortest Job First):</strong> Provably optimal average waiting time; requires burst time estimation.</li>\n  <li><strong>Round Robin (RR):</strong> Preemptive with time quantum &delta;; ensures fair CPU allocation in interactive environments.</li>\n  <li><strong>Priority Scheduling:</strong> Allocates CPU based on priority levels; ageing prevents starvation.</li>\n</ol>"
  }
];

async function seedStudyMaterials() {
  await StudyMaterial.deleteMany({});
  const inserted = await StudyMaterial.insertMany(STUDY_MATERIALS_DATA);
  console.log('[Seed] Seeded ' + inserted.length + ' comprehensive study material modules');
  return inserted;
}

module.exports = { seedStudyMaterials, STUDY_MATERIALS_DATA };
