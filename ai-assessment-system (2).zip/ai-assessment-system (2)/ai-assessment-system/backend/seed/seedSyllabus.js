const Syllabus = require('../models/Syllabus');

const SYLLABUS_DATA = [
  {
    "semester": 1,
    "subject": "Programming in C",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Introduction to C & Fundamentals",
        "topics": [
          "Introduction to C",
          "Constants",
          "Variables",
          "Data Types",
          "Operators",
          "Expressions",
          "Input/Output"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Control Statements & Loops",
        "topics": [
          "If",
          "If-Else",
          "Nested If",
          "Else-If Ladder",
          "Switch",
          "Goto",
          "While",
          "Do-While",
          "For",
          "Jumps"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Arrays, Strings & Functions",
        "topics": [
          "Arrays",
          "2D/Multidimensional Arrays",
          "Strings",
          "String Functions",
          "Functions",
          "Recursion",
          "Scope/Lifetime"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Structures & Unions",
        "topics": [
          "Structures",
          "Arrays of Structures",
          "Nested Structures",
          "Structures & Functions",
          "Unions",
          "Preprocessor"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Pointers & File Management",
        "topics": [
          "Pointers",
          "Pointer Expressions",
          "Pointers & Arrays/Functions/Structures",
          "File Management",
          "Command-Line Arguments"
        ]
      }
    ]
  },
  {
    "semester": 1,
    "subject": "Programming in C Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Simple Programs",
        "topics": [
          "Interest calculation",
          "Biggest number",
          "Odd/Even",
          "Prime numbers",
          "Unit conversions",
          "LCM & GCD",
          "Fibonacci sequence"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Array & Matrix Operations",
        "topics": [
          "Array ordering",
          "Matrix addition & multiplication",
          "Matrix transpose",
          "Call by value & address",
          "Recursion"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "String Manipulations",
        "topics": [
          "Alphabetical ordering",
          "Palindrome check",
          "Substring extraction",
          "Vowels & consonants counting"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Structure Programs",
        "topics": [
          "Student mark list processing",
          "Electricity EB bill calculation"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "File Handling Programs",
        "topics": [
          "Odd/even numbers file separation",
          "Vowels/non-vowels extraction"
        ]
      }
    ]
  },
  {
    "semester": 1,
    "subject": "Discrete Mathematics",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Propositional Logic",
        "topics": [
          "Propositional Logic",
          "Propositions",
          "Conditional Statements",
          "Truth Tables",
          "Logical Equivalences",
          "De Morgan's Laws",
          "Logic Circuits"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Sets, Functions & Sequences",
        "topics": [
          "Sets",
          "Set Operations",
          "Functions",
          "One-to-One/Onto",
          "Inverse & Composition",
          "Sequences",
          "Recurrence Relations",
          "Summations"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Number Theory",
        "topics": [
          "Divisibility",
          "Division Algorithm",
          "Modular Arithmetic",
          "Representation of Integers",
          "Prime Numbers & GCD"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Relations",
        "topics": [
          "Relations",
          "Properties of Relations",
          "Matrices of Relations",
          "Digraphs",
          "Closure",
          "Warshall's Algorithm",
          "Equivalence Relations/Classes"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Graphs",
        "topics": [
          "Graphs",
          "Graph Models",
          "Terminology",
          "Special Graphs",
          "Bipartite Graphs",
          "Adjacency & Incidence Matrices"
        ]
      }
    ]
  },
  {
    "semester": 1,
    "subject": "Digital Principles and Computer Organisation",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Number Systems & Digital Logic",
        "topics": [
          "Number Systems",
          "Binary/Octal/Hexadecimal",
          "ASCII",
          "Excess-3",
          "Gray Code",
          "Basic & Universal Gates"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Boolean Algebra & Arithmetic",
        "topics": [
          "Boolean Laws",
          "SOP/POS",
          "K-Map Simplification",
          "Don't-Care Conditions",
          "Binary Arithmetic",
          "2's Complement",
          "Adders/Subtracters"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Combinational Logic Circuits",
        "topics": [
          "Multiplexer",
          "Demultiplexer",
          "Decoders",
          "Encoders",
          "Seven-Segment Decoder",
          "XOR Gates",
          "Parity Generators/Checkers"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Central Processing Unit (CPU)",
        "topics": [
          "CPU Architecture",
          "Register Organization",
          "Stack Organization",
          "Instruction Formats",
          "Addressing Modes",
          "Data Transfer/Manipulation",
          "Program Control"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Computer Arithmetic",
        "topics": [
          "Multiplication Algorithms",
          "Division Algorithms",
          "Floating-Point Arithmetic",
          "Decimal Arithmetic Unit"
        ]
      }
    ]
  },
  {
    "semester": 2,
    "subject": "Java Programming",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Java Fundamentals & OOP",
        "topics": [
          "History/Evolution of Java",
          "OOP Principles",
          "Data Types",
          "Arrays",
          "Classes & Objects",
          "Methods",
          "Constructors",
          "This Keyword",
          "Garbage Collection"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Classes, Inheritance & Polymorphism",
        "topics": [
          "Method Overloading",
          "Recursion",
          "Access Control",
          "Static & Final",
          "Varargs",
          "Inheritance",
          "Method Overriding",
          "Dynamic Dispatch",
          "Abstract Classes"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Packages, Interfaces & Exceptions",
        "topics": [
          "Packages",
          "Interfaces",
          "Exception Handling",
          "Try/Catch",
          "Throw/Throws/Finally",
          "User-Defined Exceptions"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Multithreading & Strings",
        "topics": [
          "Multithreading Model",
          "Thread Priorities",
          "Thread Synchronization",
          "Inter-thread Communication",
          "String & StringBuffer Classes"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "AWT & GUI Components",
        "topics": [
          "AWT Hierarchy",
          "Windows & Frames",
          "Graphics & Colors",
          "Fonts",
          "AWT Controls",
          "Layout Managers",
          "Menus"
        ]
      }
    ]
  },
  {
    "semester": 2,
    "subject": "Java Programming Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Core OOP Programs",
        "topics": [
          "Arrays manipulation",
          "Method & constructor overloading",
          "Inheritance hierarchies",
          "Method overriding",
          "Dynamic method dispatch"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Packages & Interfaces",
        "topics": [
          "Interface implementation",
          "Custom package creation & import",
          "Exception handling try-catch",
          "Custom exceptions"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Multithreading & Strings",
        "topics": [
          "Multiple threads execution",
          "Thread synchronization",
          "String & StringBuffer processing"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Graphics & AWT",
        "topics": [
          "Graphics drawing",
          "Font & Color settings",
          "AWT Button & TextField controls"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Layout & Applets",
        "topics": [
          "FlowLayout & BorderLayout",
          "CardLayout & GridLayout",
          "Interactive GUI forms"
        ]
      }
    ]
  },
  {
    "semester": 2,
    "subject": "Basic Statistics",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Measures of Central Tendency & Dispersion",
        "topics": [
          "Introduction to Statistics",
          "Arithmetic Mean",
          "Median & Mode",
          "Measures of Dispersion",
          "Standard Deviation",
          "Variance"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Correlation & Regression",
        "topics": [
          "Correlation Overview",
          "Karl Pearson Correlation",
          "Rank Correlation",
          "Linear Regression",
          "Regression Lines & Equations"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Probability Theory",
        "topics": [
          "Probability Basics",
          "Addition & Multiplication Theorems",
          "Conditional Probability",
          "Bayes' Theorem"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Random Variables & Expectation",
        "topics": [
          "Random Variables",
          "Probability Distributions",
          "Mathematical Expectation",
          "Moment Generating Function",
          "Characteristic Function"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Theoretical Distributions",
        "topics": [
          "Binomial Distribution",
          "Poisson Distribution",
          "Normal Distribution",
          "Properties & Applications"
        ]
      }
    ]
  },
  {
    "semester": 2,
    "subject": "Web Technology Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "HTML5 Fundamentals",
        "topics": [
          "HTML presentation tags",
          "List tags",
          "Table structures",
          "Frame & iframe tags",
          "Form elements & validation",
          "Navigation menus"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "CSS3 Styling & Layouts",
        "topics": [
          "Responsive webpage design",
          "CSS styles & selectors",
          "CSS box model",
          "Positioning & Z-index",
          "Color palettes & gradients",
          "CSS transformations & transitions"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "JavaScript Basics",
        "topics": [
          "JavaScript conditions & loops",
          "User-defined functions",
          "Array, Number, String objects",
          "Date & Math objects"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "DOM & Event Handling",
        "topics": [
          "DOM manipulation",
          "Mouse & keyboard events",
          "Dynamic HTML updates"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Interactive Web Applications",
        "topics": [
          "Client-side form validation",
          "Student marksheet generator",
          "Shopping cart prototype"
        ]
      }
    ]
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Algorithm Analysis & ADT",
        "topics": [
          "Basic Terminology",
          "Data Structure Classification",
          "Operations on Data Structures",
          "Abstract Data Types (ADT)",
          "Algorithms",
          "Control Structures",
          "Time & Space Complexity",
          "Big-O, Omega, Theta Notations"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Arrays & Linked Lists",
        "topics": [
          "Arrays & Pointers",
          "Strings & Pointer Manipulations",
          "Singly Linked List",
          "Circular Linked List",
          "Doubly Linked List",
          "Linked List Applications"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Stacks & Queues",
        "topics": [
          "Stack ADT using Arrays & Linked Lists",
          "Multiple Stacks",
          "Infix to Postfix Conversion",
          "Evaluation of Postfix",
          "Queues Representation",
          "Circular Queue",
          "Deque",
          "Priority Queue"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Trees & Binary Search Trees",
        "topics": [
          "Tree Terminology",
          "Binary Trees",
          "Binary Search Trees (BST)",
          "Expression Trees",
          "Tree Traversals (Inorder, Preorder, Postorder)",
          "Huffman Tree",
          "BST Operations (Insert, Delete, Search)",
          "Threaded Binary Trees"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Graphs & Sorting Algorithms",
        "topics": [
          "Graph Terminology",
          "Directed Graphs",
          "Adjacency Matrix & List Representation",
          "BFS & DFS Graph Traversals",
          "Dijkstra Shortest Path",
          "Linear & Binary Search",
          "Bubble, Insertion, Selection, Merge, Quick Sort"
        ]
      }
    ]
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithm Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Searching & Basic Array Operations",
        "topics": [
          "Linear Search",
          "Binary Search",
          "Merging two sorted arrays",
          "Multidimensional array manipulation"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "String & Singly Linked List",
        "topics": [
          "String operations & transformations",
          "Character/word/line counting in text",
          "Singly linked list insertion & deletion",
          "Node counting in linked list"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Advanced Linked Lists",
        "topics": [
          "Doubly linked list operations",
          "Circular linked list implementation",
          "Polynomial addition using linked list"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Stack & Queue Implementations",
        "topics": [
          "Stack using array",
          "Stack using linked list",
          "Infix to postfix conversion",
          "Queue using array",
          "Queue using linked list"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Sorting Algorithms",
        "topics": [
          "Bubble sort & Insertion sort",
          "Selection sort & Merge sort",
          "Quick sort implementation"
        ]
      }
    ]
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Database Concepts & Relational Model",
        "topics": [
          "Database Systems Purpose",
          "Views of Data",
          "Database Languages",
          "DBMS Architecture & Engine",
          "Users & Administrators",
          "Relational Model",
          "Database Schema",
          "Keys (Primary, Foreign, Candidate)",
          "Schema Diagrams",
          "Relational Algebra"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Data Modeling & Normalization",
        "topics": [
          "Data Modeling",
          "Functional Dependencies",
          "Database Normalization (1NF, 2NF, 3NF, BCNF)",
          "Dependency Diagrams",
          "Denormalization",
          "ER Model",
          "Entity Sets & Attributes",
          "Relationship Cardinalities"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "SQL: DDL & DML",
        "topics": [
          "SQL Fundamentals",
          "DDL (CREATE, ALTER, DROP, RENAME, TRUNCATE)",
          "Data Types & Constraints",
          "DML (INSERT, UPDATE, DELETE, SELECT)",
          "WHERE Clause",
          "Sorting with ORDER BY",
          "Substitution Variables",
          "CASE Expressions"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "SQL Functions, Joins & PL/SQL Basics",
        "topics": [
          "Built-in Functions (String, Math, Date)",
          "Grouping with GROUP BY & HAVING",
          "SQL Joins (Inner, Left, Right, Full Outer)",
          "Views",
          "PL/SQL Fundamentals",
          "PL/SQL Block Structure",
          "Variables & Assignment",
          "Bind Variables"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Advanced PL/SQL & Transactions",
        "topics": [
          "PL/SQL Control Structures",
          "Nested Blocks",
          "SQL in PL/SQL",
          "Transactions & ACID Properties",
          "Exception Handling",
          "PL/SQL Records",
          "Stored Procedures & Functions",
          "Database Triggers"
        ]
      }
    ]
  },
  {
    "semester": 3,
    "subject": "RDBMS Lab / DBMS Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "DDL & Table Constraints",
        "topics": [
          "Table creation with Primary Key & Foreign Key",
          "ALTER and DROP table commands",
          "Check and Unique constraints"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "DML & Queries",
        "topics": [
          "INSERT, UPDATE, DELETE records",
          "Complex SELECT queries with WHERE and ORDER BY",
          "Aggregate functions and GROUP BY"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Joins & Subqueries",
        "topics": [
          "Inner and Outer Joins",
          "Nested subqueries and Correlated queries",
          "Set operations (UNION, INTERSECT, MINUS)"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Views & Security",
        "topics": [
          "Creating and updating Views",
          "Grant and Revoke authorizations"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "PL/SQL Programming",
        "topics": [
          "PL/SQL Conditional and Loop programs",
          "Stored Procedures and Functions",
          "Explicit Cursors",
          "Triggers implementation"
        ]
      }
    ]
  },
  {
    "semester": 3,
    "subject": "Computational Methods",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Roots of Equations",
        "topics": [
          "Bisection Method",
          "Successive Approximation",
          "Method of False Position (Regula Falsi)",
          "Newton-Raphson Method",
          "Horner's Method"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Linear Algebraic Equations",
        "topics": [
          "Gauss Elimination",
          "Gauss-Jordan Method",
          "Matrix Triangularisation",
          "Crout's Method",
          "Iterative Methods (Jacobi, Gauss-Seidel)"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Interpolation",
        "topics": [
          "Linear Interpolation",
          "Newton's Forward Interpolation",
          "Newton's Backward Interpolation",
          "Divided Differences",
          "Newton's Divided Difference Formula",
          "Lagrange Interpolation",
          "Inverse Interpolation"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Numerical Differentiation & Integration",
        "topics": [
          "Numerical Differentiation",
          "Newton's Differences Differentiation",
          "Trapezoidal Rule",
          "Romberg's Method",
          "Simpson's 1/3 Rule",
          "Simpson's 3/8 Rule"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Numerical Solution of ODEs",
        "topics": [
          "Taylor's Series Method",
          "Euler's Method",
          "Improved & Modified Euler's Method",
          "Runge-Kutta 4th Order Method",
          "Predictor-Corrector Methods",
          "Milne's Method"
        ]
      }
    ]
  },
  {
    "semester": 4,
    "subject": "Advanced Java Programming",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Java Collections & Networking",
        "topics": [
          "Java Collections Framework",
          "ArrayList & LinkedList",
          "HashSet, LinkedHashSet, TreeSet",
          "PriorityQueue & ArrayDeque",
          "HashMap & TreeMap",
          "TCP/IP Sockets",
          "UDP Datagram Sockets"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Swing GUI Development",
        "topics": [
          "Swing Architecture",
          "JComponent Classes",
          "Event Handling in Swing",
          "Swing Controls (JButton, JTextField, JTable, JTree, JDialog)"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "JDBC & Database Connectivity",
        "topics": [
          "JDBC Drivers & Architecture",
          "JDBC Interfaces (Connection, Statement, PreparedStatement, ResultSet)",
          "Database Connection Steps",
          "Executing CRUD Queries"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Servlet Technology",
        "topics": [
          "Servlet Architecture",
          "Servlet Lifecycle",
          "GenericServlet & HttpServlet",
          "Request & Response Handling",
          "Session Tracking",
          "Cookies & HTTP Sessions"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "JSP (Java Server Pages)",
        "topics": [
          "JSP Architecture & Engine",
          "JSP Syntax & Directives",
          "Scriptlets, Expressions & Declarations",
          "JSP Implicit Objects",
          "JavaBeans in JSP",
          "JSP Database Access"
        ]
      }
    ]
  },
  {
    "semester": 4,
    "subject": "Advanced Java Programming Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Collections & Networking",
        "topics": [
          "Collections and Iterator implementations",
          "TCP Client-Server Chat",
          "UDP Message Transmission"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Swing GUI Applications",
        "topics": [
          "Swing Event Handling",
          "Student Registration Form with JTable",
          "Menu-driven desktop tool"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "JDBC Database Operations",
        "topics": [
          "JDBC CRUD operations",
          "PreparedStatements with parameterized queries",
          "ResultSet metadata processing"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Servlet Web Applications",
        "topics": [
          "Servlet authentication system",
          "Servlet CRUD application",
          "Session tracking with cookies"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "JSP Web Applications",
        "topics": [
          "JSP form processing",
          "JSP database integration",
          "JSP login and portal session"
        ]
      }
    ]
  },
  {
    "semester": 4,
    "subject": "Computer Networks",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Data Communications & Reference Models",
        "topics": [
          "Data Communication Components",
          "Networks & Topologies",
          "Network Types (LAN, MAN, WAN)",
          "OSI 7-Layer Model",
          "TCP/IP Protocol Suite",
          "Protocol Layering"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Physical & Data Link Layers",
        "topics": [
          "Transmission Media (Guided & Unguided)",
          "Data Link Layer Services",
          "Framing Techniques",
          "Error Detection & Correction (CRC, Hamming)",
          "Ethernet & CSMA/CD"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Network Layer & Routing",
        "topics": [
          "Hubs, Switches & Routers",
          "Network Layer Services",
          "Packet Switching",
          "IPv4 Addressing & Subnetting",
          "ICMP & Mobile IP",
          "Routing Algorithms (Distance Vector, Link State)"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Transport Layer Protocols",
        "topics": [
          "Transport Services",
          "Port Addressing",
          "Encapsulation & Multiplexing",
          "Flow Control & Error Control",
          "Congestion Control",
          "UDP Protocol",
          "TCP Protocol & 3-Way Handshake",
          "TCP Timers"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Application Layer & Services",
        "topics": [
          "Application Layer Paradigms",
          "HTTP & HTTPS",
          "World Wide Web (WWW)",
          "FTP Protocol",
          "Electronic Mail (SMTP, POP3, IMAP)",
          "TELNET & SSH",
          "Domain Name System (DNS)"
        ]
      }
    ]
  },
  {
    "semester": 4,
    "subject": "PHP Programming Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "PHP Fundamentals",
        "topics": [
          "PHP syntax and variables",
          "Constants and data types",
          "Operators and expressions",
          "Control statements and loops"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Arrays & Strings",
        "topics": [
          "Indexed and associative arrays",
          "Key-value pair manipulations",
          "String handling functions",
          "Math and date functions"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Functions & Forms",
        "topics": [
          "User-defined functions and recursion",
          "HTML form processing with GET and POST",
          "Form validation"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Cookies & Sessions",
        "topics": [
          "Cookie creation and retrieval",
          "Session management and tracking",
          "User login authentication"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "MySQL Integration",
        "topics": [
          "Connecting PHP with MySQL",
          "User registration form insertion",
          "Displaying and updating database records"
        ]
      }
    ]
  },
  {
    "semester": 4,
    "subject": "Operations Research",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Linear Programming Problems (LPP)",
        "topics": [
          "Operations Research Overview",
          "LPP Formulation",
          "Assumptions of Linear Programming",
          "Canonical & Standard Forms",
          "Graphical Solution Method"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Simplex Method",
        "topics": [
          "Simplex Maximization Algorithm",
          "Artificial Variable Techniques",
          "Two-Phase Method",
          "Big-M (Penalty) Method"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Duality in LPP",
        "topics": [
          "Concept of Duality",
          "Primal-Dual Relationships",
          "Formulation of Dual Problems",
          "Dual Simplex Method"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Transportation Problems",
        "topics": [
          "Transportation Model Formulation",
          "North-West Corner Rule",
          "Least Cost Method",
          "Vogel's Approximation Method (VAM)",
          "Optimality Test (MODI / Stepping Stone)"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Assignment Problems",
        "topics": [
          "Assignment Problem Formulation",
          "Hungarian Algorithm for Solution",
          "Unbalanced Assignment Problems",
          "Maximization Cases",
          "Travelling Salesperson Problem"
        ]
      }
    ]
  },
  {
    "semester": 5,
    "subject": "Advanced Computer Networks",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Routing & Switch Architecture",
        "topics": [
          "Routing Concepts",
          "Static vs Dynamic Routing",
          "Routing Tables & Metrics",
          "Switching Technologies",
          "MAC Address Table",
          "VLAN Concepts",
          "Basic Switch Configuration"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Routing Protocols & Spanning Tree",
        "topics": [
          "Routing Information Protocol (RIP)",
          "OSPF Protocol",
          "EIGRP Protocol",
          "Border Gateway Protocol (BGP)",
          "Spanning Tree Protocol (STP)",
          "VLAN Trunking (802.1Q)"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "EtherChannel & Network Troubleshooting",
        "topics": [
          "Ethernet Channel & Link Aggregation",
          "Load Balancing",
          "Network Troubleshooting Tools (Ping, Traceroute, Netstat)",
          "TCP/UDP Analysis",
          "Routing Issue Resolution",
          "Performance Optimization"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Network Security & Quality of Service",
        "topics": [
          "Network Security Fundamentals",
          "Threats & Vulnerabilities",
          "Firewalls & Packet Filters",
          "Quality of Service (QoS)",
          "Bandwidth Management",
          "Latency & Jitter Control"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Modern Perimeter Security & AAA",
        "topics": [
          "Modern Security Threats",
          "Cisco Router Security",
          "AAA (Authentication, Authorization, Accounting)",
          "Firewall Technologies & DMZ",
          "Intrusion Prevention Systems (IPS)",
          "LAN Security Best Practices"
        ]
      }
    ]
  },
  {
    "semester": 5,
    "subject": "Advanced Computer Networks Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Network Topologies",
        "topics": [
          "LAN, WAN, MAN simulation",
          "Subnetting and IP configuration"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Switching & VLANs",
        "topics": [
          "Switch configuration",
          "VLAN segmentation and trunking",
          "Inter-VLAN routing"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Static & Dynamic Routing",
        "topics": [
          "Static routing setup",
          "RIP configuration",
          "OSPF single and multi-area routing"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Advanced Protocols",
        "topics": [
          "EIGRP configuration",
          "BGP peering setup",
          "Access Control Lists (ACL)"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Packet Analysis",
        "topics": [
          "Wireshark packet capture",
          "Packet Tracer monitoring and troubleshooting"
        ]
      }
    ]
  },
  {
    "semester": 5,
    "subject": "Cloud Computing",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Cloud Vision & Foundations",
        "topics": [
          "Cloud Computing Vision & Definition",
          "Reference Model",
          "Cloud Characteristics",
          "Distributed Systems Evolution",
          "Virtualization Overview",
          "Web 2.0 & SOA",
          "AWS, Google App Engine, Microsoft Azure",
          "Hadoop & Salesforce/Aneka"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Virtualization Technology",
        "topics": [
          "Virtualization Characteristics",
          "Virtualization Taxonomy",
          "Execution Virtualization",
          "Hardware Virtualization",
          "Virtualization Advantages & Disadvantages",
          "Hypervisors: Xen, VMware, Hyper-V, KVM"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Cloud Architecture & Service Models",
        "topics": [
          "Cloud Architecture",
          "Infrastructure as a Service (IaaS)",
          "Platform as a Service (PaaS)",
          "Software as a Service (SaaS)",
          "Deployment Models (Public, Private, Hybrid, Community)",
          "Cloud Economics",
          "Interoperability & Scalability",
          "Security & Privacy"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Cloud Platforms & Technologies",
        "topics": [
          "Amazon Web Services (EC2, S3, RDS, IAM)",
          "Google App Engine Architecture",
          "Microsoft Azure Cloud Services",
          "SQL Azure & NoSQL in Cloud"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Cloud Applications & Use Cases",
        "topics": [
          "Scientific & High-Performance Applications",
          "Healthcare & Biology Clouds",
          "Geoscience Data Processing",
          "CRM & ERP Solutions",
          "Productivity & Collaboration Suites",
          "Social Networking & Media Streaming",
          "Cloud Gaming"
        ]
      }
    ]
  },
  {
    "semester": 5,
    "subject": "Cloud Computing Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Virtual Machines & EC2",
        "topics": [
          "Creating AWS EC2 Linux instances",
          "SSH connection and security groups",
          "Apache web server setup on cloud"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Storage & IAM",
        "topics": [
          "AWS S3 bucket creation and permissions",
          "IAM user creation and policy attachment",
          "EBS volume attachment and snapshots"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Serverless & Database",
        "topics": [
          "AWS Lambda function deployment",
          "RDS MySQL database instance creation",
          "Connecting web app to cloud DB"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Networking & Scaling",
        "topics": [
          "VPC configuration with subnets",
          "Application Load Balancer setup",
          "Auto-scaling groups configuration"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "PaaS Deployment",
        "topics": [
          "Deploying web app on Google App Engine",
          "Heroku/Render app deployment"
        ]
      }
    ]
  },
  {
    "semester": 5,
    "subject": "Linear Algebra",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Matrices & Gaussian Elimination",
        "topics": [
          "Matrix Operations",
          "Gaussian Elimination",
          "Matrix Multiplication",
          "Triangular Factors (LU Decomposition)",
          "Row Exchanges & Permutation Matrices",
          "Inverses & Transposes"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Vector Spaces & Subspaces",
        "topics": [
          "Vector Spaces & Subspaces",
          "Solving Ax=0 and Ax=b",
          "Linear Independence",
          "Basis and Dimension",
          "The Four Fundamental Subspaces",
          "Linear Transformations"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Orthogonality & Projections",
        "topics": [
          "Orthogonality of Vectors",
          "Orthogonal Subspaces",
          "Projections onto Subspaces",
          "Least Squares Approximations",
          "Orthogonal Bases",
          "Gram-Schmidt Process"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Eigenvalues & Eigenvectors",
        "topics": [
          "Eigenvalues and Eigenvectors Definition",
          "Diagonalization of a Matrix",
          "Difference Equations",
          "Powers of Matrix A",
          "Matrix Exponentials"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Positive Definite Matrices & SVD",
        "topics": [
          "Positive Definite Matrices",
          "Minima, Maxima and Saddle Points",
          "Tests for Positive Definiteness",
          "Singular Value Decomposition (SVD)",
          "Principal Component Analysis (PCA) Foundations"
        ]
      }
    ]
  },
  {
    "semester": 6,
    "subject": "AI & Machine Learning",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Data Science & AI/ML Foundations",
        "topics": [
          "Data Science Overview",
          "Artificial Intelligence Concepts",
          "Machine Learning & Deep Learning",
          "Supervised vs Unsupervised Learning",
          "AI Applications across Industries",
          "ML Development Tools",
          "Scikit-Learn Framework"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Classification Algorithms",
        "topics": [
          "Classification Overview",
          "K-Nearest Neighbors (KNN)",
          "Decision Tree Classifiers",
          "Entropy & Information Gain",
          "Random Forest Ensembles",
          "Support Vector Machines (SVM)",
          "Kernel Tricks"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Regression Analysis",
        "topics": [
          "Regression Concepts",
          "Simple Linear Regression",
          "Multiple Linear Regression",
          "Polynomial Regression",
          "Logistic Regression for Binary Outcomes",
          "Maximum Likelihood Estimation (MLE)",
          "Cost Functions & Gradient Descent"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Unsupervised Learning & Clustering",
        "topics": [
          "Unsupervised Learning Paradigms",
          "K-Means Clustering",
          "Hierarchical Clustering",
          "Association Rule Mining (Apriori)",
          "Anomaly & Outlier Detection",
          "Dimensionality Reduction (PCA)"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Feature Engineering & AI Process Automation",
        "topics": [
          "Feature Engineering Techniques",
          "Data Transformation & Scaling",
          "Feature Selection Methods",
          "Process Automation with Selenium",
          "ChatGPT / LLM API Automation with Python",
          "Model Evaluation Metrics (Precision, Recall, F1-Score, ROC-AUC)"
        ]
      }
    ]
  },
  {
    "semester": 6,
    "subject": "AI & ML Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Data Preprocessing & EDA",
        "topics": [
          "Data cleaning and missing value imputation",
          "Exploratory Data Analysis (EDA) with visualization",
          "Feature scaling and normalization"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Supervised Learning Models",
        "topics": [
          "Linear Regression implementation",
          "Logistic Regression on classification dataset",
          "K-Nearest Neighbors (KNN) model"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Tree & Ensemble Models",
        "topics": [
          "Decision Tree Classifier and visual tree export",
          "Random Forest Classifier and feature importance",
          "Support Vector Machine (SVM)"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Clustering & Unsupervised Learning",
        "topics": [
          "K-Means clustering and Elbow method",
          "PCA dimensionality reduction on high-dimensional data"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "AI Automation",
        "topics": [
          "ChatGPT/LLM API integration with Python",
          "Automated email generator script",
          "Web scraping and automated Excel report generation"
        ]
      }
    ]
  },
  {
    "semester": 6,
    "subject": "Data Analytics with Python",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Python Basics & Core Structures",
        "topics": [
          "Python Features & Execution",
          "Python Virtual Machine (PVM)",
          "Memory Management & Garbage Collection",
          "Data Types & Operators",
          "Input/Output Formatting",
          "Control Statements",
          "Python Arrays"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Python Collections & Functional Programming",
        "topics": [
          "Python Lists & Methods",
          "Tuples & Immutability",
          "Functions & Scope",
          "Dictionaries & Key-Value Operations",
          "Lambda Functions",
          "List & Dict Comprehensions",
          "Map, Filter, Reduce"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Data Analysis Workflow & Libraries",
        "topics": [
          "Data Analysis Process",
          "Data Extraction & Preparation",
          "Data Cleaning Techniques",
          "Data Visualization Principles",
          "Predictive Modeling Basics",
          "Model Validation",
          "NumPy, Pandas, Matplotlib, SciPy Ecosystem"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "NumPy & Pandas Structures",
        "topics": [
          "NumPy ndarray Object",
          "Array Indexing, Slicing & Iterating",
          "Boolean Indexing",
          "Shape Manipulation & Broadcasting",
          "Pandas Series & DataFrames",
          "Data Mapping, Sorting & Ranking",
          "Correlation & Covariance",
          "Handling Missing Data (NaN)"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Data Transformation & Visualization",
        "topics": [
          "Reading & Writing CSV, Excel & Text Files",
          "Data Preparation & Merging",
          "Concatenation & Pivoting",
          "Matplotlib & Seaborn Visualization",
          "Line, Histogram, Bar, Pie Charts & Scatter Plots",
          "Jupyter Notebook Visualizations"
        ]
      }
    ]
  },
  {
    "semester": 6,
    "subject": "Data Analytics with Python Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Python Basics",
        "topics": [
          "Control statements and loop programs",
          "Custom functions and lambda expressions",
          "List, set, tuple, dictionary manipulations"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "NumPy Operations",
        "topics": [
          "NumPy array creation and indexing",
          "Matrix operations and broadcasting",
          "Statistical operations on NumPy arrays"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Pandas DataFrames",
        "topics": [
          "DataFrame creation from CSV files",
          "Data filtering, grouping and aggregation",
          "Handling missing values and data cleaning"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Statistical Analysis",
        "topics": [
          "Correlation and covariance matrices",
          "Descriptive statistics summary",
          "Normal distribution curves"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Data Visualization",
        "topics": [
          "Matplotlib bar charts and histograms",
          "Seaborn heatmaps and scatter plots",
          "Interactive dashboards in Jupyter"
        ]
      }
    ]
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "OS Overview & System Calls",
        "topics": [
          "Operating System Functions",
          "OS Structures & Architectures",
          "OS Operations & Dual-Mode Execution",
          "Operating System Environments",
          "OS Services",
          "User Interfaces",
          "System Calls & System Programs"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Process Management & CPU Scheduling",
        "topics": [
          "Process Concept & Process Control Block (PCB)",
          "Process Scheduling Queues",
          "Process Operations (Creation, Termination)",
          "Inter-Process Communication (IPC)",
          "CPU Scheduling Concepts",
          "Scheduling Algorithms (FCFS, SJF, Priority, Round Robin, Multilevel Queue)"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Process Synchronization & Deadlocks",
        "topics": [
          "Process Synchronization",
          "Critical Section Problem",
          "Peterson's Solution",
          "Semaphores & Mutexes",
          "Classic Synchronization Problems",
          "Deadlock Definition & Characterization",
          "Deadlock Prevention, Avoidance (Banker's Algorithm), Detection & Recovery"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Memory Management & Virtual Memory",
        "topics": [
          "Memory Management Fundamentals",
          "Swapping",
          "Contiguous Memory Allocation",
          "Paging Architecture",
          "Segmentation",
          "Virtual Memory Concepts",
          "Demand Paging",
          "Page Replacement Algorithms (FIFO, LRU, Optimal)",
          "Allocation of Frames & Thrashing"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "File Systems & OS Security",
        "topics": [
          "File Concepts & Attributes",
          "File Access Methods (Sequential, Direct)",
          "File Allocation Methods (Contiguous, Linked, Indexed)",
          "Free-Space Management",
          "OS Security Goals",
          "Program, System & Network Threats",
          "Protection Mechanisms & Access Control"
        ]
      }
    ]
  },
  {
    "semester": 6,
    "subject": "Data Mining and Warehousing",
    "subjectType": "Theory",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Data Mining Foundations & KDD",
        "topics": [
          "Data Mining Overview",
          "Classification & Regression Concepts",
          "Time Series & Prediction",
          "Clustering & Summarization",
          "Association Rules & Sequence Discovery",
          "Knowledge Discovery in Databases (KDD) Process",
          "Data Mining Issues & Metrics",
          "Social Implications of Data Mining"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Classification Techniques",
        "topics": [
          "Classification & Prediction Tasks",
          "Bayesian Classification (Naive Bayes)",
          "K-Nearest Neighbor (KNN)",
          "Decision Tree Induction: ID3 Algorithm",
          "C4.5 Algorithm",
          "CART Algorithm",
          "Attribute Selection Measures"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Cluster Analysis",
        "topics": [
          "Clustering Concepts & Types",
          "Similarity & Distance Measures",
          "Outlier Analysis",
          "Hierarchical Clustering (Agglomerative, Divisive)",
          "Partitional Clustering (K-Means, K-Medoids)",
          "Minimum Spanning Tree (MST) Clustering"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Association Rule Mining",
        "topics": [
          "Association Rule Mining Concepts",
          "Large Itemsets & Support-Confidence Framework",
          "Apriori Algorithm",
          "Sampling & Partitioning Approaches",
          "Parallel & Distributed Association Algorithms",
          "Incremental Association Rules"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "Advanced Data Mining",
        "topics": [
          "Web Mining (Content, Structure, Usage)",
          "Spatial Data Mining",
          "Spatial Classification & Clustering",
          "Temporal Mining & Time Series Patterns",
          "Temporal Association Rules"
        ]
      }
    ]
  },
  {
    "semester": 6,
    "subject": "Open Source Technology Lab",
    "subjectType": "Lab",
    "units": [
      {
        "unitNumber": 1,
        "unitTitle": "Linux Installation & Environment",
        "topics": [
          "Linux Client OS installation (Ubuntu)",
          "Linux Server OS installation",
          "Dual-boot and VirtualBox setup"
        ]
      },
      {
        "unitNumber": 2,
        "unitTitle": "Linux Commands & Shell Scripting",
        "topics": [
          "Essential Linux file & directory commands",
          "User and permission management (chmod, chown)",
          "Shell scripting with variables, conditionals, loops",
          "Gawk and sed text processing"
        ]
      },
      {
        "unitNumber": 3,
        "unitTitle": "Software & Runtimes Installation",
        "topics": [
          "Package managers (APT, YUM)",
          "Installing Python, GCC, Java on Linux",
          "Environment variables and PATH configuration"
        ]
      },
      {
        "unitNumber": 4,
        "unitTitle": "Web Server & Database Setup",
        "topics": [
          "Apache2 web server installation and virtual hosts",
          "MySQL server installation and security setup",
          "PHP installation and Apache module configuration"
        ]
      },
      {
        "unitNumber": 5,
        "unitTitle": "LAMP Stack Integration",
        "topics": [
          "Connecting PHP with MySQL on Linux",
          "Deploying open source web application",
          "Backup and restore MySQL database in Linux"
        ]
      }
    ]
  }
];

async function seedSyllabus() {
  await Syllabus.deleteMany({});
  const inserted = await Syllabus.insertMany(SYLLABUS_DATA);
  console.log('[Seed] Seeded ' + inserted.length + ' syllabus records for Semesters 1 to 6');
  return inserted;
}

module.exports = { seedSyllabus, SYLLABUS_DATA };
