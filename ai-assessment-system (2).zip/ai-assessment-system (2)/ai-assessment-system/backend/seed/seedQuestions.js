const Question = require('../models/Question');

const QUESTIONS_DATA = [
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 1,
    "top": "Data Types",
    "q": "Define primitive data types in C. Explain their memory sizes and value ranges.",
    "m": 5,
    "d": "Easy",
    "a": "Primitive data types in C include char (1 byte, -128 to 127), int (2/4 bytes), float (4 bytes, 6 decimal digits precision), double (8 bytes, 15 decimal digits), and void. Modifiers like signed, unsigned, short, long alter their range."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 1,
    "top": "Operators",
    "q": "Explain the hierarchy and associativity of operators in C with expressions.",
    "m": 7,
    "d": "Medium",
    "a": "Operator precedence determines the order of evaluation: Postfix ((), [], ->, .), Unary (+, -, !, ++, --, sizeof), Multiplicative (*, /, %), Additive (+, -), Shift (<<, >>), Relational (<, <=, >, >=), Equality (==, !=), Bitwise AND/XOR/OR, Logical AND/OR, Conditional (?:), Assignment (=, +=), Comma (,)."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 1,
    "top": "Input/Output",
    "q": "Explain formatted and unformatted I/O functions in C with examples.",
    "m": 5,
    "d": "Easy",
    "a": "Formatted I/O: printf() and scanf() use format specifiers (%d, %f, %c, %s). Unformatted I/O: getchar(), putchar(), gets(), puts(), getch(), putch() perform character and string I/O without formatting."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 2,
    "top": "Control Statements",
    "q": "Differentiate between while and do-while loops in C.",
    "m": 2,
    "d": "Easy",
    "a": "while loop is an entry-controlled loop where condition is tested before executing the body. do-while is an exit-controlled loop where body executes at least once before condition testing."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 2,
    "top": "Switch",
    "q": "Explain switch-case construct in C with syntax and flow chart.",
    "m": 5,
    "d": "Medium",
    "a": "switch evaluates an integral expression and jumps to matching case label. break prevents fall-through, default executes if no case matches."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 3,
    "top": "Arrays",
    "q": "Explain memory representation of 2D arrays (Row-Major and Column-Major order).",
    "m": 7,
    "d": "Medium",
    "a": "In Row-Major order, elements of row 0 are stored first, followed by row 1: Address(A[i][j]) = Base + (i * N + j) * size. In Column-Major order, elements of column 0 are stored first: Address(A[i][j]) = Base + (j * M + i) * size."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 3,
    "top": "Recursion",
    "q": "What is recursion? Write a recursive C function to solve the Tower of Hanoi problem.",
    "m": 10,
    "d": "Hard",
    "a": "Recursion is a process where a function calls itself directly or indirectly until a base condition is reached. Tower of Hanoi algorithm: void TOH(int n, char src, char aux, char dest) { if(n==1){ printf('Move %c -> %c', src, dest); return; } TOH(n-1, src, dest, aux); printf('Move %c -> %c', src, dest); TOH(n-1, aux, src, dest); } Time complexity is O(2^n)."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 4,
    "top": "Structures",
    "q": "Differentiate between structure and union in C with respect to memory allocation.",
    "m": 5,
    "d": "Medium",
    "a": "In a struct, each member gets its own independent memory allocation, total size = sum of member sizes (+ padding). In a union, all members share the same memory location, total size = size of largest member."
  },
  {
    "sem": 1,
    "sub": "Programming in C",
    "u": 5,
    "top": "Pointers",
    "q": "Explain dynamic memory allocation functions in C (malloc, calloc, realloc, free).",
    "m": 10,
    "d": "Medium",
    "a": "malloc(size) allocates contiguous uninitialized bytes in heap. calloc(n, size) allocates contiguous zero-initialized bytes. realloc(ptr, newsize) resizes allocated block. free(ptr) releases heap memory back to system preventing memory leaks."
  },
  {
    "sem": 3,
    "sub": "Data Structures and Algorithms",
    "u": 1,
    "top": "Asymptotic Analysis",
    "q": "Define Big-O, Omega, and Theta notations with mathematical limits.",
    "m": 7,
    "d": "Medium",
    "a": "Big-O (O): Asymptotic Upper Bound, f(n) <= c*g(n) for n >= n0. Big-Omega (Ω): Asymptotic Lower Bound, f(n) >= c*g(n) for n >= n0. Big-Theta (Θ): Asymptotic Tight Bound, c1*g(n) <= f(n) <= c2*g(n) for n >= n0."
  },
  {
    "sem": 3,
    "sub": "Data Structures and Algorithms",
    "u": 2,
    "top": "Linked Lists",
    "q": "Explain singly, doubly, and circular linked lists with insertion algorithms.",
    "m": 10,
    "d": "Medium",
    "a": "Singly Linked List has data and next pointer. Doubly Linked List has prev, data, and next pointer allowing bidirectional traversal. Circular Linked List has last node pointing to head. Insertion at beginning, middle, and end operates with O(1) or O(n) complexity."
  },
  {
    "sem": 3,
    "sub": "Data Structures and Algorithms",
    "u": 3,
    "top": "Stacks",
    "q": "Explain infix to postfix conversion algorithm using stack with an example.",
    "m": 7,
    "d": "Medium",
    "a": "Algorithm scans expression left to right. Operands output directly. Operators pushed onto stack after popping higher/equal precedence operators. Left parenthesis pushed, right parenthesis causes popping until left parenthesis is discarded."
  },
  {
    "sem": 3,
    "sub": "Data Structures and Algorithms",
    "u": 4,
    "top": "Trees",
    "q": "Explain AVL Tree rotations (LL, RR, LR, RL) with balancing examples.",
    "m": 10,
    "d": "Hard",
    "a": "An AVL tree is a self-balancing BST where balance factor of every node is in {-1, 0, 1}. Rotations: LL (Single Right), RR (Single Left), LR (Left then Right), RL (Right then Left) restore balance in O(1) time after insertion/deletion."
  },
  {
    "sem": 3,
    "sub": "Data Structures and Algorithms",
    "u": 5,
    "top": "Sorting & Graphs",
    "q": "Explain Dijkstra's shortest path algorithm with pseudocode and time complexity.",
    "m": 10,
    "d": "Hard",
    "a": "Dijkstra finds shortest path from single source to all vertices in a weighted graph with non-negative edge weights using a priority queue (min-heap). Time complexity with adjacency list and min-heap is O((V + E) log V)."
  },
  {
    "sem": 3,
    "sub": "RDBMS / DBMS",
    "u": 1,
    "top": "Architecture",
    "q": "Explain 3-tier DBMS architecture and data independence.",
    "m": 7,
    "d": "Medium",
    "a": "3-tier architecture consists of: External Level (User Views), Conceptual Level (Logical Schema & Entities), Internal Level (Physical Storage). Logical data independence isolates conceptual changes from external views; physical data independence isolates physical changes from conceptual schema."
  },
  {
    "sem": 3,
    "sub": "RDBMS / DBMS",
    "u": 2,
    "top": "Normalization",
    "q": "Explain 1NF, 2NF, 3NF, and BCNF with functional dependency examples.",
    "m": 10,
    "d": "Hard",
    "a": "1NF: Atomic attributes, no repeating groups. 2NF: In 1NF and no partial dependencies (every non-key attribute fully dependent on primary key). 3NF: In 2NF and no transitive dependencies. BCNF: For every FD X -> Y, X must be a super key."
  },
  {
    "sem": 3,
    "sub": "RDBMS / DBMS",
    "u": 3,
    "top": "SQL",
    "q": "Explain SQL Joins (Inner, Left, Right, Full Outer) with syntax and Venn diagrams.",
    "m": 7,
    "d": "Medium",
    "a": "Inner Join returns records with matching keys in both tables. Left Outer Join returns all records from left table and matched from right. Right Outer Join returns all from right table. Full Outer Join returns all rows from both tables when match condition is met or null."
  },
  {
    "sem": 3,
    "sub": "RDBMS / DBMS",
    "u": 5,
    "top": "Transactions",
    "q": "Explain ACID properties of database transactions.",
    "m": 5,
    "d": "Easy",
    "a": "Atomicity: All-or-nothing execution. Consistency: Preserves database integrity constraints. Isolation: Concurrent transactions do not interfere. Durability: Committed changes survive system failures."
  },
  {
    "sem": 6,
    "sub": "Operating Systems",
    "u": 2,
    "top": "CPU Scheduling",
    "q": "Compare FCFS, SJF, Priority, and Round Robin scheduling algorithms.",
    "m": 10,
    "d": "Medium",
    "a": "FCFS is non-preemptive with potential convoy effect. SJF gives optimal average waiting time but suffers from starvation. Priority scheduling allocates CPU by priority. Round Robin is preemptive with time quantum suited for time-sharing systems."
  },
  {
    "sem": 6,
    "sub": "Operating Systems",
    "u": 3,
    "top": "Deadlocks",
    "q": "Explain Banker's Algorithm for Deadlock Avoidance with safety algorithm.",
    "m": 10,
    "d": "Hard",
    "a": "Banker's algorithm tests whether allocating resources keeps system in a safe state. Need matrix = Max - Allocation. If Need <= Available, simulate execution, release allocation, and verify safe sequence exists."
  },
  {
    "sem": 6,
    "sub": "Operating Systems",
    "u": 4,
    "top": "Virtual Memory",
    "q": "Explain Demand Paging and Page Replacement Algorithms (FIFO, LRU, Optimal).",
    "m": 10,
    "d": "Medium",
    "a": "Demand paging loads pages into memory only when referenced. FIFO replaces oldest loaded page (exhibits Belady's anomaly). LRU replaces least recently used page. Optimal replaces page not needed for longest future duration."
  },
  {
    "sem": 6,
    "sub": "AI & Machine Learning",
    "u": 1,
    "top": "ML Fundamentals",
    "q": "Differentiate Supervised, Unsupervised, and Reinforcement Learning.",
    "m": 5,
    "d": "Easy",
    "a": "Supervised learning trains on labeled data (classification, regression). Unsupervised learning discovers patterns in unlabeled data (clustering, PCA). Reinforcement learning learns optimal policy via agent rewards/penalties."
  },
  {
    "sem": 6,
    "sub": "AI & Machine Learning",
    "u": 2,
    "top": "Classification",
    "q": "Explain Support Vector Machine (SVM) and Kernel Trick.",
    "m": 10,
    "d": "Hard",
    "a": "SVM finds optimal separating hyperplane maximizing margin between classes using support vectors. Kernel trick (RBF, Polynomial, Sigmoid) maps non-linearly separable inputs into higher-dimensional feature space where linear separation is possible."
  },
  {
    "sem": 6,
    "sub": "AI & Machine Learning",
    "u": 4,
    "top": "Clustering",
    "q": "Explain K-Means clustering algorithm and Elbow method for optimal K.",
    "m": 7,
    "d": "Medium",
    "a": "K-Means initializes K centroids, assigns data points to nearest centroid, and recomputes centroids iteratively until convergence. Elbow method plots Within-Cluster Sum of Squares (WCSS) vs K to identify optimal cluster count at the elbow point."
  }
];

async function seedQuestions() {
  const docs = QUESTIONS_DATA.map(q => ({
    semester: q.sem,
    subject: q.sub,
    unit: q.u,
    topic: q.top,
    question: q.q,
    options: [],
    correctAnswer: '',
    marks: q.m,
    difficulty: q.d,
    answer: q.a,
    questionType: 'Theory'
  }));
  const inserted = await Question.insertMany(docs);
  console.log('[Seed] Seeded ' + inserted.length + ' theory questions');
  return inserted;
}

module.exports = { seedQuestions, QUESTIONS_DATA };
