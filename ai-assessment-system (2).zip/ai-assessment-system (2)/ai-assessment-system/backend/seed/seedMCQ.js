const Question = require('../models/Question');

const MCQ_DATA = [
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the standard size of an integer (int) in modern 32/64-bit C compilers?",
    "options": [
      "1 Byte",
      "2 Bytes",
      "4 Bytes",
      "8 Bytes"
    ],
    "correctAnswer": "4 Bytes",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "On 32-bit and 64-bit systems, standard int is 4 bytes (32 bits), range -2,147,483,648 to 2,147,483,647.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which format specifier is used to print a double precision floating point number in C?",
    "options": [
      "%d",
      "%f",
      "%lf",
      "%c"
    ],
    "correctAnswer": "%lf",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "%lf is used for double, while %f is for standard float in scanf/printf.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the minimum value that can be stored in a signed 8-bit char in C?",
    "options": [
      "0",
      "-128",
      "-255",
      "-127"
    ],
    "correctAnswer": "-128",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Signed 8-bit char ranges from -2^7 (-128) to 2^7 - 1 (127).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which of the following is NOT a fundamental primitive data type in C?",
    "options": [
      "int",
      "char",
      "string",
      "float"
    ],
    "correctAnswer": "string",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "C does not have a built-in 'string' primitive data type; strings are represented as null-terminated character arrays (char[]).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the value of sizeof(void) in standard ANSI C?",
    "options": [
      "0",
      "1",
      "4",
      "Undefined / Compilation Error"
    ],
    "correctAnswer": "Undefined / Compilation Error",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "void is an incomplete type representing absence of value and has no size in standard C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the standard size of an integer (int) in modern 32/64-bit C compilers? [Variant 2]",
    "options": [
      "1 Byte",
      "2 Bytes",
      "4 Bytes",
      "8 Bytes"
    ],
    "correctAnswer": "4 Bytes",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "On 32-bit and 64-bit systems, standard int is 4 bytes (32 bits), range -2,147,483,648 to 2,147,483,647.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which format specifier is used to print a double precision floating point number in C? [Variant 2]",
    "options": [
      "%d",
      "%f",
      "%lf",
      "%c"
    ],
    "correctAnswer": "%lf",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "%lf is used for double, while %f is for standard float in scanf/printf.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the minimum value that can be stored in a signed 8-bit char in C? [Variant 2]",
    "options": [
      "0",
      "-128",
      "-255",
      "-127"
    ],
    "correctAnswer": "-128",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Signed 8-bit char ranges from -2^7 (-128) to 2^7 - 1 (127).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which of the following is NOT a fundamental primitive data type in C? [Variant 2]",
    "options": [
      "int",
      "char",
      "string",
      "float"
    ],
    "correctAnswer": "string",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "C does not have a built-in 'string' primitive data type; strings are represented as null-terminated character arrays (char[]).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the value of sizeof(void) in standard ANSI C? [Variant 2]",
    "options": [
      "0",
      "1",
      "4",
      "Undefined / Compilation Error"
    ],
    "correctAnswer": "Undefined / Compilation Error",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "void is an incomplete type representing absence of value and has no size in standard C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the standard size of an integer (int) in modern 32/64-bit C compilers? [Variant 3]",
    "options": [
      "1 Byte",
      "2 Bytes",
      "4 Bytes",
      "8 Bytes"
    ],
    "correctAnswer": "4 Bytes",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "On 32-bit and 64-bit systems, standard int is 4 bytes (32 bits), range -2,147,483,648 to 2,147,483,647.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which format specifier is used to print a double precision floating point number in C? [Variant 3]",
    "options": [
      "%d",
      "%f",
      "%lf",
      "%c"
    ],
    "correctAnswer": "%lf",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "%lf is used for double, while %f is for standard float in scanf/printf.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the minimum value that can be stored in a signed 8-bit char in C? [Variant 3]",
    "options": [
      "0",
      "-128",
      "-255",
      "-127"
    ],
    "correctAnswer": "-128",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Signed 8-bit char ranges from -2^7 (-128) to 2^7 - 1 (127).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which of the following is NOT a fundamental primitive data type in C? [Variant 3]",
    "options": [
      "int",
      "char",
      "string",
      "float"
    ],
    "correctAnswer": "string",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "C does not have a built-in 'string' primitive data type; strings are represented as null-terminated character arrays (char[]).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the value of sizeof(void) in standard ANSI C? [Variant 3]",
    "options": [
      "0",
      "1",
      "4",
      "Undefined / Compilation Error"
    ],
    "correctAnswer": "Undefined / Compilation Error",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "void is an incomplete type representing absence of value and has no size in standard C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the standard size of an integer (int) in modern 32/64-bit C compilers? [Variant 4]",
    "options": [
      "1 Byte",
      "2 Bytes",
      "4 Bytes",
      "8 Bytes"
    ],
    "correctAnswer": "4 Bytes",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "On 32-bit and 64-bit systems, standard int is 4 bytes (32 bits), range -2,147,483,648 to 2,147,483,647.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which format specifier is used to print a double precision floating point number in C? [Variant 4]",
    "options": [
      "%d",
      "%f",
      "%lf",
      "%c"
    ],
    "correctAnswer": "%lf",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "%lf is used for double, while %f is for standard float in scanf/printf.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the minimum value that can be stored in a signed 8-bit char in C? [Variant 4]",
    "options": [
      "0",
      "-128",
      "-255",
      "-127"
    ],
    "correctAnswer": "-128",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Signed 8-bit char ranges from -2^7 (-128) to 2^7 - 1 (127).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which of the following is NOT a fundamental primitive data type in C? [Variant 4]",
    "options": [
      "int",
      "char",
      "string",
      "float"
    ],
    "correctAnswer": "string",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "C does not have a built-in 'string' primitive data type; strings are represented as null-terminated character arrays (char[]).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the value of sizeof(void) in standard ANSI C? [Variant 4]",
    "options": [
      "0",
      "1",
      "4",
      "Undefined / Compilation Error"
    ],
    "correctAnswer": "Undefined / Compilation Error",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "void is an incomplete type representing absence of value and has no size in standard C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the standard size of an integer (int) in modern 32/64-bit C compilers? [Variant 5]",
    "options": [
      "1 Byte",
      "2 Bytes",
      "4 Bytes",
      "8 Bytes"
    ],
    "correctAnswer": "4 Bytes",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "On 32-bit and 64-bit systems, standard int is 4 bytes (32 bits), range -2,147,483,648 to 2,147,483,647.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which format specifier is used to print a double precision floating point number in C? [Variant 5]",
    "options": [
      "%d",
      "%f",
      "%lf",
      "%c"
    ],
    "correctAnswer": "%lf",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "%lf is used for double, while %f is for standard float in scanf/printf.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the minimum value that can be stored in a signed 8-bit char in C? [Variant 5]",
    "options": [
      "0",
      "-128",
      "-255",
      "-127"
    ],
    "correctAnswer": "-128",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Signed 8-bit char ranges from -2^7 (-128) to 2^7 - 1 (127).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "Which of the following is NOT a fundamental primitive data type in C? [Variant 5]",
    "options": [
      "int",
      "char",
      "string",
      "float"
    ],
    "correctAnswer": "string",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "C does not have a built-in 'string' primitive data type; strings are represented as null-terminated character arrays (char[]).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Data Types",
    "question": "What is the value of sizeof(void) in standard ANSI C? [Variant 5]",
    "options": [
      "0",
      "1",
      "4",
      "Undefined / Compilation Error"
    ],
    "correctAnswer": "Undefined / Compilation Error",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "void is an incomplete type representing absence of value and has no size in standard C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the result of the expression 5 + 3 * 2 in C?",
    "options": [
      "16",
      "11",
      "10",
      "13"
    ],
    "correctAnswer": "11",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Multiplication (*) has higher precedence than addition (+), so 3*2=6 and 5+6=11.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which operator in C is used to access the address of a variable?",
    "options": [
      "*",
      "&",
      "->",
      "."
    ],
    "correctAnswer": "&",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "& is the address-of operator, while * is the dereference operator.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which bitwise operator performs logical XOR in C?",
    "options": [
      "&",
      "|",
      "^",
      "~"
    ],
    "correctAnswer": "^",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "^ is bitwise exclusive OR (XOR), evaluating to 1 only when bits differ.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the associativity of the ternary conditional operator (?:) in C?",
    "options": [
      "Left to Right",
      "Right to Left",
      "Non-associative",
      "Depends on operands"
    ],
    "correctAnswer": "Right to Left",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Conditional operator (?:) associates from right to left.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What will be the output of `int x = 5; printf('%d', ++x + x++);`?",
    "options": [
      "12",
      "13",
      "Undefined Behavior",
      "10"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Modifying a variable multiple times without an intervening sequence point invokes Undefined Behavior in C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the result of the expression 5 + 3 * 2 in C? [Variant 2]",
    "options": [
      "16",
      "11",
      "10",
      "13"
    ],
    "correctAnswer": "11",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Multiplication (*) has higher precedence than addition (+), so 3*2=6 and 5+6=11.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which operator in C is used to access the address of a variable? [Variant 2]",
    "options": [
      "*",
      "&",
      "->",
      "."
    ],
    "correctAnswer": "&",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "& is the address-of operator, while * is the dereference operator.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which bitwise operator performs logical XOR in C? [Variant 2]",
    "options": [
      "&",
      "|",
      "^",
      "~"
    ],
    "correctAnswer": "^",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "^ is bitwise exclusive OR (XOR), evaluating to 1 only when bits differ.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the associativity of the ternary conditional operator (?:) in C? [Variant 2]",
    "options": [
      "Left to Right",
      "Right to Left",
      "Non-associative",
      "Depends on operands"
    ],
    "correctAnswer": "Right to Left",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Conditional operator (?:) associates from right to left.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What will be the output of `int x = 5; printf('%d', ++x + x++);`? [Variant 2]",
    "options": [
      "12",
      "13",
      "Undefined Behavior",
      "10"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Modifying a variable multiple times without an intervening sequence point invokes Undefined Behavior in C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the result of the expression 5 + 3 * 2 in C? [Variant 3]",
    "options": [
      "16",
      "11",
      "10",
      "13"
    ],
    "correctAnswer": "11",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Multiplication (*) has higher precedence than addition (+), so 3*2=6 and 5+6=11.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which operator in C is used to access the address of a variable? [Variant 3]",
    "options": [
      "*",
      "&",
      "->",
      "."
    ],
    "correctAnswer": "&",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "& is the address-of operator, while * is the dereference operator.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which bitwise operator performs logical XOR in C? [Variant 3]",
    "options": [
      "&",
      "|",
      "^",
      "~"
    ],
    "correctAnswer": "^",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "^ is bitwise exclusive OR (XOR), evaluating to 1 only when bits differ.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the associativity of the ternary conditional operator (?:) in C? [Variant 3]",
    "options": [
      "Left to Right",
      "Right to Left",
      "Non-associative",
      "Depends on operands"
    ],
    "correctAnswer": "Right to Left",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Conditional operator (?:) associates from right to left.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What will be the output of `int x = 5; printf('%d', ++x + x++);`? [Variant 3]",
    "options": [
      "12",
      "13",
      "Undefined Behavior",
      "10"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Modifying a variable multiple times without an intervening sequence point invokes Undefined Behavior in C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the result of the expression 5 + 3 * 2 in C? [Variant 4]",
    "options": [
      "16",
      "11",
      "10",
      "13"
    ],
    "correctAnswer": "11",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Multiplication (*) has higher precedence than addition (+), so 3*2=6 and 5+6=11.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which operator in C is used to access the address of a variable? [Variant 4]",
    "options": [
      "*",
      "&",
      "->",
      "."
    ],
    "correctAnswer": "&",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "& is the address-of operator, while * is the dereference operator.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which bitwise operator performs logical XOR in C? [Variant 4]",
    "options": [
      "&",
      "|",
      "^",
      "~"
    ],
    "correctAnswer": "^",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "^ is bitwise exclusive OR (XOR), evaluating to 1 only when bits differ.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the associativity of the ternary conditional operator (?:) in C? [Variant 4]",
    "options": [
      "Left to Right",
      "Right to Left",
      "Non-associative",
      "Depends on operands"
    ],
    "correctAnswer": "Right to Left",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Conditional operator (?:) associates from right to left.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What will be the output of `int x = 5; printf('%d', ++x + x++);`? [Variant 4]",
    "options": [
      "12",
      "13",
      "Undefined Behavior",
      "10"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Modifying a variable multiple times without an intervening sequence point invokes Undefined Behavior in C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the result of the expression 5 + 3 * 2 in C? [Variant 5]",
    "options": [
      "16",
      "11",
      "10",
      "13"
    ],
    "correctAnswer": "11",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Multiplication (*) has higher precedence than addition (+), so 3*2=6 and 5+6=11.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which operator in C is used to access the address of a variable? [Variant 5]",
    "options": [
      "*",
      "&",
      "->",
      "."
    ],
    "correctAnswer": "&",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "& is the address-of operator, while * is the dereference operator.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "Which bitwise operator performs logical XOR in C? [Variant 5]",
    "options": [
      "&",
      "|",
      "^",
      "~"
    ],
    "correctAnswer": "^",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "^ is bitwise exclusive OR (XOR), evaluating to 1 only when bits differ.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What is the associativity of the ternary conditional operator (?:) in C? [Variant 5]",
    "options": [
      "Left to Right",
      "Right to Left",
      "Non-associative",
      "Depends on operands"
    ],
    "correctAnswer": "Right to Left",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Conditional operator (?:) associates from right to left.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Operators",
    "question": "What will be the output of `int x = 5; printf('%d', ++x + x++);`? [Variant 5]",
    "options": [
      "12",
      "13",
      "Undefined Behavior",
      "10"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Modifying a variable multiple times without an intervening sequence point invokes Undefined Behavior in C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which function is used to read a single character from standard input in C?",
    "options": [
      "putchar()",
      "getchar()",
      "scanf_s()",
      "fputs()"
    ],
    "correctAnswer": "getchar()",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "getchar() reads the next available character from standard input (stdin).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does the printf() function return upon successful execution in C?",
    "options": [
      "0",
      "Number of characters printed",
      "1",
      "Void"
    ],
    "correctAnswer": "Number of characters printed",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "printf() returns total number of characters output, or a negative value on failure.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which header file is required to use printf() and scanf() in C?",
    "options": [
      "<conio.h>",
      "<stdlib.h>",
      "<stdio.h>",
      "<string.h>"
    ],
    "correctAnswer": "<stdio.h>",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "<stdio.h> (Standard Input Output) declares standard I/O library functions.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "How do you read a string containing spaces using scanf in C?",
    "options": [
      "scanf('%s', str);",
      "scanf('%[^\\n]s', str);",
      "scanf('%c', str);",
      "scanf('%d', str);"
    ],
    "correctAnswer": "scanf('%[^\\n]s', str);",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Scanset '%[^\\n]' reads all characters until a newline character is encountered.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does fflush(stdin) cause in standard C according to the ISO standard?",
    "options": [
      "Flushes input buffer safely",
      "Undefined Behavior",
      "Clears screen",
      "Returns EOF"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "fflush() is strictly defined for output streams; calling it on stdin is undefined in ISO C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which function is used to read a single character from standard input in C? [Variant 2]",
    "options": [
      "putchar()",
      "getchar()",
      "scanf_s()",
      "fputs()"
    ],
    "correctAnswer": "getchar()",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "getchar() reads the next available character from standard input (stdin).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does the printf() function return upon successful execution in C? [Variant 2]",
    "options": [
      "0",
      "Number of characters printed",
      "1",
      "Void"
    ],
    "correctAnswer": "Number of characters printed",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "printf() returns total number of characters output, or a negative value on failure.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which header file is required to use printf() and scanf() in C? [Variant 2]",
    "options": [
      "<conio.h>",
      "<stdlib.h>",
      "<stdio.h>",
      "<string.h>"
    ],
    "correctAnswer": "<stdio.h>",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "<stdio.h> (Standard Input Output) declares standard I/O library functions.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "How do you read a string containing spaces using scanf in C? [Variant 2]",
    "options": [
      "scanf('%s', str);",
      "scanf('%[^\\n]s', str);",
      "scanf('%c', str);",
      "scanf('%d', str);"
    ],
    "correctAnswer": "scanf('%[^\\n]s', str);",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Scanset '%[^\\n]' reads all characters until a newline character is encountered.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does fflush(stdin) cause in standard C according to the ISO standard? [Variant 2]",
    "options": [
      "Flushes input buffer safely",
      "Undefined Behavior",
      "Clears screen",
      "Returns EOF"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "fflush() is strictly defined for output streams; calling it on stdin is undefined in ISO C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which function is used to read a single character from standard input in C? [Variant 3]",
    "options": [
      "putchar()",
      "getchar()",
      "scanf_s()",
      "fputs()"
    ],
    "correctAnswer": "getchar()",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "getchar() reads the next available character from standard input (stdin).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does the printf() function return upon successful execution in C? [Variant 3]",
    "options": [
      "0",
      "Number of characters printed",
      "1",
      "Void"
    ],
    "correctAnswer": "Number of characters printed",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "printf() returns total number of characters output, or a negative value on failure.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which header file is required to use printf() and scanf() in C? [Variant 3]",
    "options": [
      "<conio.h>",
      "<stdlib.h>",
      "<stdio.h>",
      "<string.h>"
    ],
    "correctAnswer": "<stdio.h>",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "<stdio.h> (Standard Input Output) declares standard I/O library functions.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "How do you read a string containing spaces using scanf in C? [Variant 3]",
    "options": [
      "scanf('%s', str);",
      "scanf('%[^\\n]s', str);",
      "scanf('%c', str);",
      "scanf('%d', str);"
    ],
    "correctAnswer": "scanf('%[^\\n]s', str);",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Scanset '%[^\\n]' reads all characters until a newline character is encountered.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does fflush(stdin) cause in standard C according to the ISO standard? [Variant 3]",
    "options": [
      "Flushes input buffer safely",
      "Undefined Behavior",
      "Clears screen",
      "Returns EOF"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "fflush() is strictly defined for output streams; calling it on stdin is undefined in ISO C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which function is used to read a single character from standard input in C? [Variant 4]",
    "options": [
      "putchar()",
      "getchar()",
      "scanf_s()",
      "fputs()"
    ],
    "correctAnswer": "getchar()",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "getchar() reads the next available character from standard input (stdin).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does the printf() function return upon successful execution in C? [Variant 4]",
    "options": [
      "0",
      "Number of characters printed",
      "1",
      "Void"
    ],
    "correctAnswer": "Number of characters printed",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "printf() returns total number of characters output, or a negative value on failure.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which header file is required to use printf() and scanf() in C? [Variant 4]",
    "options": [
      "<conio.h>",
      "<stdlib.h>",
      "<stdio.h>",
      "<string.h>"
    ],
    "correctAnswer": "<stdio.h>",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "<stdio.h> (Standard Input Output) declares standard I/O library functions.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "How do you read a string containing spaces using scanf in C? [Variant 4]",
    "options": [
      "scanf('%s', str);",
      "scanf('%[^\\n]s', str);",
      "scanf('%c', str);",
      "scanf('%d', str);"
    ],
    "correctAnswer": "scanf('%[^\\n]s', str);",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Scanset '%[^\\n]' reads all characters until a newline character is encountered.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does fflush(stdin) cause in standard C according to the ISO standard? [Variant 4]",
    "options": [
      "Flushes input buffer safely",
      "Undefined Behavior",
      "Clears screen",
      "Returns EOF"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "fflush() is strictly defined for output streams; calling it on stdin is undefined in ISO C.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which function is used to read a single character from standard input in C? [Variant 5]",
    "options": [
      "putchar()",
      "getchar()",
      "scanf_s()",
      "fputs()"
    ],
    "correctAnswer": "getchar()",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "getchar() reads the next available character from standard input (stdin).",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does the printf() function return upon successful execution in C? [Variant 5]",
    "options": [
      "0",
      "Number of characters printed",
      "1",
      "Void"
    ],
    "correctAnswer": "Number of characters printed",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "printf() returns total number of characters output, or a negative value on failure.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "Which header file is required to use printf() and scanf() in C? [Variant 5]",
    "options": [
      "<conio.h>",
      "<stdlib.h>",
      "<stdio.h>",
      "<string.h>"
    ],
    "correctAnswer": "<stdio.h>",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "<stdio.h> (Standard Input Output) declares standard I/O library functions.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "How do you read a string containing spaces using scanf in C? [Variant 5]",
    "options": [
      "scanf('%s', str);",
      "scanf('%[^\\n]s', str);",
      "scanf('%c', str);",
      "scanf('%d', str);"
    ],
    "correctAnswer": "scanf('%[^\\n]s', str);",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Scanset '%[^\\n]' reads all characters until a newline character is encountered.",
    "questionType": "MCQ"
  },
  {
    "semester": 1,
    "subject": "Programming in C",
    "unit": 1,
    "topic": "Input/Output",
    "question": "What does fflush(stdin) cause in standard C according to the ISO standard? [Variant 5]",
    "options": [
      "Flushes input buffer safely",
      "Undefined Behavior",
      "Clears screen",
      "Returns EOF"
    ],
    "correctAnswer": "Undefined Behavior",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "fflush() is strictly defined for output streams; calling it on stdin is undefined in ISO C.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which principle governs the operation of a Stack data structure?",
    "options": [
      "FIFO (First In First Out)",
      "LIFO (Last In First Out)",
      "Priority Based",
      "Random Access"
    ],
    "correctAnswer": "LIFO (Last In First Out)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Stack follows Last In First Out (LIFO), where elements are added and removed from the top.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the time complexity to push an element onto an array-based stack?",
    "options": [
      "O(1)",
      "O(n)",
      "O(log n)",
      "O(n^2)"
    ],
    "correctAnswer": "O(1)",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Push operation accesses top index directly and executes in constant time O(1).",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What data structure is utilized in function call execution and recursion tracking in OS?",
    "options": [
      "Queue",
      "Stack",
      "Binary Tree",
      "Hash Map"
    ],
    "correctAnswer": "Stack",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "The call stack tracks activation records, return addresses, and local variables for recursive function calls.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which queue variation allows insertion and deletion from both ends?",
    "options": [
      "Circular Queue",
      "Priority Queue",
      "Deque (Double Ended Queue)",
      "Linear Queue"
    ],
    "correctAnswer": "Deque (Double Ended Queue)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Deque supports insert/delete operations at both front and rear ends.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the condition for a circular queue of size N to be full?",
    "options": [
      "front == rear",
      "(rear + 1) % N == front",
      "rear == N - 1",
      "front == 0"
    ],
    "correctAnswer": "(rear + 1) % N == front",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "In circular queue, wrap-around full condition is (rear + 1) % N == front.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which principle governs the operation of a Stack data structure? [Variant 2]",
    "options": [
      "FIFO (First In First Out)",
      "LIFO (Last In First Out)",
      "Priority Based",
      "Random Access"
    ],
    "correctAnswer": "LIFO (Last In First Out)",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Stack follows Last In First Out (LIFO), where elements are added and removed from the top.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the time complexity to push an element onto an array-based stack? [Variant 2]",
    "options": [
      "O(1)",
      "O(n)",
      "O(log n)",
      "O(n^2)"
    ],
    "correctAnswer": "O(1)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Push operation accesses top index directly and executes in constant time O(1).",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What data structure is utilized in function call execution and recursion tracking in OS? [Variant 2]",
    "options": [
      "Queue",
      "Stack",
      "Binary Tree",
      "Hash Map"
    ],
    "correctAnswer": "Stack",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "The call stack tracks activation records, return addresses, and local variables for recursive function calls.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which queue variation allows insertion and deletion from both ends? [Variant 2]",
    "options": [
      "Circular Queue",
      "Priority Queue",
      "Deque (Double Ended Queue)",
      "Linear Queue"
    ],
    "correctAnswer": "Deque (Double Ended Queue)",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Deque supports insert/delete operations at both front and rear ends.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the condition for a circular queue of size N to be full? [Variant 2]",
    "options": [
      "front == rear",
      "(rear + 1) % N == front",
      "rear == N - 1",
      "front == 0"
    ],
    "correctAnswer": "(rear + 1) % N == front",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "In circular queue, wrap-around full condition is (rear + 1) % N == front.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which principle governs the operation of a Stack data structure? [Variant 3]",
    "options": [
      "FIFO (First In First Out)",
      "LIFO (Last In First Out)",
      "Priority Based",
      "Random Access"
    ],
    "correctAnswer": "LIFO (Last In First Out)",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Stack follows Last In First Out (LIFO), where elements are added and removed from the top.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the time complexity to push an element onto an array-based stack? [Variant 3]",
    "options": [
      "O(1)",
      "O(n)",
      "O(log n)",
      "O(n^2)"
    ],
    "correctAnswer": "O(1)",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Push operation accesses top index directly and executes in constant time O(1).",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What data structure is utilized in function call execution and recursion tracking in OS? [Variant 3]",
    "options": [
      "Queue",
      "Stack",
      "Binary Tree",
      "Hash Map"
    ],
    "correctAnswer": "Stack",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "The call stack tracks activation records, return addresses, and local variables for recursive function calls.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which queue variation allows insertion and deletion from both ends? [Variant 3]",
    "options": [
      "Circular Queue",
      "Priority Queue",
      "Deque (Double Ended Queue)",
      "Linear Queue"
    ],
    "correctAnswer": "Deque (Double Ended Queue)",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Deque supports insert/delete operations at both front and rear ends.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the condition for a circular queue of size N to be full? [Variant 3]",
    "options": [
      "front == rear",
      "(rear + 1) % N == front",
      "rear == N - 1",
      "front == 0"
    ],
    "correctAnswer": "(rear + 1) % N == front",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "In circular queue, wrap-around full condition is (rear + 1) % N == front.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which principle governs the operation of a Stack data structure? [Variant 4]",
    "options": [
      "FIFO (First In First Out)",
      "LIFO (Last In First Out)",
      "Priority Based",
      "Random Access"
    ],
    "correctAnswer": "LIFO (Last In First Out)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Stack follows Last In First Out (LIFO), where elements are added and removed from the top.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the time complexity to push an element onto an array-based stack? [Variant 4]",
    "options": [
      "O(1)",
      "O(n)",
      "O(log n)",
      "O(n^2)"
    ],
    "correctAnswer": "O(1)",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Push operation accesses top index directly and executes in constant time O(1).",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What data structure is utilized in function call execution and recursion tracking in OS? [Variant 4]",
    "options": [
      "Queue",
      "Stack",
      "Binary Tree",
      "Hash Map"
    ],
    "correctAnswer": "Stack",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "The call stack tracks activation records, return addresses, and local variables for recursive function calls.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which queue variation allows insertion and deletion from both ends? [Variant 4]",
    "options": [
      "Circular Queue",
      "Priority Queue",
      "Deque (Double Ended Queue)",
      "Linear Queue"
    ],
    "correctAnswer": "Deque (Double Ended Queue)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Deque supports insert/delete operations at both front and rear ends.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the condition for a circular queue of size N to be full? [Variant 4]",
    "options": [
      "front == rear",
      "(rear + 1) % N == front",
      "rear == N - 1",
      "front == 0"
    ],
    "correctAnswer": "(rear + 1) % N == front",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "In circular queue, wrap-around full condition is (rear + 1) % N == front.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which principle governs the operation of a Stack data structure? [Variant 5]",
    "options": [
      "FIFO (First In First Out)",
      "LIFO (Last In First Out)",
      "Priority Based",
      "Random Access"
    ],
    "correctAnswer": "LIFO (Last In First Out)",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Stack follows Last In First Out (LIFO), where elements are added and removed from the top.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the time complexity to push an element onto an array-based stack? [Variant 5]",
    "options": [
      "O(1)",
      "O(n)",
      "O(log n)",
      "O(n^2)"
    ],
    "correctAnswer": "O(1)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Push operation accesses top index directly and executes in constant time O(1).",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What data structure is utilized in function call execution and recursion tracking in OS? [Variant 5]",
    "options": [
      "Queue",
      "Stack",
      "Binary Tree",
      "Hash Map"
    ],
    "correctAnswer": "Stack",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "The call stack tracks activation records, return addresses, and local variables for recursive function calls.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "Which queue variation allows insertion and deletion from both ends? [Variant 5]",
    "options": [
      "Circular Queue",
      "Priority Queue",
      "Deque (Double Ended Queue)",
      "Linear Queue"
    ],
    "correctAnswer": "Deque (Double Ended Queue)",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Deque supports insert/delete operations at both front and rear ends.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "Data Structures and Algorithms",
    "unit": 3,
    "topic": "Stacks & Queues",
    "question": "What is the condition for a circular queue of size N to be full? [Variant 5]",
    "options": [
      "front == rear",
      "(rear + 1) % N == front",
      "rear == N - 1",
      "front == 0"
    ],
    "correctAnswer": "(rear + 1) % N == front",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "In circular queue, wrap-around full condition is (rear + 1) % N == front.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL command is classified as Data Definition Language (DDL)?",
    "options": [
      "SELECT",
      "UPDATE",
      "CREATE",
      "INSERT"
    ],
    "correctAnswer": "CREATE",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "CREATE, ALTER, DROP, TRUNCATE are DDL commands that define database schemas.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which clause in SQL is used to filter groups created by GROUP BY?",
    "options": [
      "WHERE",
      "HAVING",
      "ORDER BY",
      "FILTER"
    ],
    "correctAnswer": "HAVING",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "HAVING filters grouped records, whereas WHERE filters individual rows before grouping.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the primary characteristic of a PRIMARY KEY in SQL?",
    "options": [
      "Allows multiple NULLs",
      "Unique and Non-NULL",
      "Can have duplicates",
      "Optional index"
    ],
    "correctAnswer": "Unique and Non-NULL",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "A PRIMARY KEY constraint uniquely identifies each record and strictly forbids NULL values.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL JOIN returns all records from the left table and matching from the right?",
    "options": [
      "INNER JOIN",
      "LEFT OUTER JOIN",
      "RIGHT OUTER JOIN",
      "CROSS JOIN"
    ],
    "correctAnswer": "LEFT OUTER JOIN",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "LEFT JOIN retains all rows from left table and fills non-matching right table columns with NULL.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the result of TRUNCATE TABLE statement in SQL?",
    "options": [
      "Deletes schema and data",
      "Deletes all rows quickly without logging individual row deletions",
      "Deletes only filtered rows",
      "Rolls back automatically"
    ],
    "correctAnswer": "Deletes all rows quickly without logging individual row deletions",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "TRUNCATE is a DDL operation that deallocates data pages rapidly.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL command is classified as Data Definition Language (DDL)? [Variant 2]",
    "options": [
      "SELECT",
      "UPDATE",
      "CREATE",
      "INSERT"
    ],
    "correctAnswer": "CREATE",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "CREATE, ALTER, DROP, TRUNCATE are DDL commands that define database schemas.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which clause in SQL is used to filter groups created by GROUP BY? [Variant 2]",
    "options": [
      "WHERE",
      "HAVING",
      "ORDER BY",
      "FILTER"
    ],
    "correctAnswer": "HAVING",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "HAVING filters grouped records, whereas WHERE filters individual rows before grouping.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the primary characteristic of a PRIMARY KEY in SQL? [Variant 2]",
    "options": [
      "Allows multiple NULLs",
      "Unique and Non-NULL",
      "Can have duplicates",
      "Optional index"
    ],
    "correctAnswer": "Unique and Non-NULL",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "A PRIMARY KEY constraint uniquely identifies each record and strictly forbids NULL values.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL JOIN returns all records from the left table and matching from the right? [Variant 2]",
    "options": [
      "INNER JOIN",
      "LEFT OUTER JOIN",
      "RIGHT OUTER JOIN",
      "CROSS JOIN"
    ],
    "correctAnswer": "LEFT OUTER JOIN",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "LEFT JOIN retains all rows from left table and fills non-matching right table columns with NULL.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the result of TRUNCATE TABLE statement in SQL? [Variant 2]",
    "options": [
      "Deletes schema and data",
      "Deletes all rows quickly without logging individual row deletions",
      "Deletes only filtered rows",
      "Rolls back automatically"
    ],
    "correctAnswer": "Deletes all rows quickly without logging individual row deletions",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "TRUNCATE is a DDL operation that deallocates data pages rapidly.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL command is classified as Data Definition Language (DDL)? [Variant 3]",
    "options": [
      "SELECT",
      "UPDATE",
      "CREATE",
      "INSERT"
    ],
    "correctAnswer": "CREATE",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "CREATE, ALTER, DROP, TRUNCATE are DDL commands that define database schemas.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which clause in SQL is used to filter groups created by GROUP BY? [Variant 3]",
    "options": [
      "WHERE",
      "HAVING",
      "ORDER BY",
      "FILTER"
    ],
    "correctAnswer": "HAVING",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "HAVING filters grouped records, whereas WHERE filters individual rows before grouping.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the primary characteristic of a PRIMARY KEY in SQL? [Variant 3]",
    "options": [
      "Allows multiple NULLs",
      "Unique and Non-NULL",
      "Can have duplicates",
      "Optional index"
    ],
    "correctAnswer": "Unique and Non-NULL",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "A PRIMARY KEY constraint uniquely identifies each record and strictly forbids NULL values.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL JOIN returns all records from the left table and matching from the right? [Variant 3]",
    "options": [
      "INNER JOIN",
      "LEFT OUTER JOIN",
      "RIGHT OUTER JOIN",
      "CROSS JOIN"
    ],
    "correctAnswer": "LEFT OUTER JOIN",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "LEFT JOIN retains all rows from left table and fills non-matching right table columns with NULL.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the result of TRUNCATE TABLE statement in SQL? [Variant 3]",
    "options": [
      "Deletes schema and data",
      "Deletes all rows quickly without logging individual row deletions",
      "Deletes only filtered rows",
      "Rolls back automatically"
    ],
    "correctAnswer": "Deletes all rows quickly without logging individual row deletions",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "TRUNCATE is a DDL operation that deallocates data pages rapidly.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL command is classified as Data Definition Language (DDL)? [Variant 4]",
    "options": [
      "SELECT",
      "UPDATE",
      "CREATE",
      "INSERT"
    ],
    "correctAnswer": "CREATE",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "CREATE, ALTER, DROP, TRUNCATE are DDL commands that define database schemas.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which clause in SQL is used to filter groups created by GROUP BY? [Variant 4]",
    "options": [
      "WHERE",
      "HAVING",
      "ORDER BY",
      "FILTER"
    ],
    "correctAnswer": "HAVING",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "HAVING filters grouped records, whereas WHERE filters individual rows before grouping.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the primary characteristic of a PRIMARY KEY in SQL? [Variant 4]",
    "options": [
      "Allows multiple NULLs",
      "Unique and Non-NULL",
      "Can have duplicates",
      "Optional index"
    ],
    "correctAnswer": "Unique and Non-NULL",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "A PRIMARY KEY constraint uniquely identifies each record and strictly forbids NULL values.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL JOIN returns all records from the left table and matching from the right? [Variant 4]",
    "options": [
      "INNER JOIN",
      "LEFT OUTER JOIN",
      "RIGHT OUTER JOIN",
      "CROSS JOIN"
    ],
    "correctAnswer": "LEFT OUTER JOIN",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "LEFT JOIN retains all rows from left table and fills non-matching right table columns with NULL.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the result of TRUNCATE TABLE statement in SQL? [Variant 4]",
    "options": [
      "Deletes schema and data",
      "Deletes all rows quickly without logging individual row deletions",
      "Deletes only filtered rows",
      "Rolls back automatically"
    ],
    "correctAnswer": "Deletes all rows quickly without logging individual row deletions",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "TRUNCATE is a DDL operation that deallocates data pages rapidly.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL command is classified as Data Definition Language (DDL)? [Variant 5]",
    "options": [
      "SELECT",
      "UPDATE",
      "CREATE",
      "INSERT"
    ],
    "correctAnswer": "CREATE",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "CREATE, ALTER, DROP, TRUNCATE are DDL commands that define database schemas.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which clause in SQL is used to filter groups created by GROUP BY? [Variant 5]",
    "options": [
      "WHERE",
      "HAVING",
      "ORDER BY",
      "FILTER"
    ],
    "correctAnswer": "HAVING",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "HAVING filters grouped records, whereas WHERE filters individual rows before grouping.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the primary characteristic of a PRIMARY KEY in SQL? [Variant 5]",
    "options": [
      "Allows multiple NULLs",
      "Unique and Non-NULL",
      "Can have duplicates",
      "Optional index"
    ],
    "correctAnswer": "Unique and Non-NULL",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "A PRIMARY KEY constraint uniquely identifies each record and strictly forbids NULL values.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "Which SQL JOIN returns all records from the left table and matching from the right? [Variant 5]",
    "options": [
      "INNER JOIN",
      "LEFT OUTER JOIN",
      "RIGHT OUTER JOIN",
      "CROSS JOIN"
    ],
    "correctAnswer": "LEFT OUTER JOIN",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "LEFT JOIN retains all rows from left table and fills non-matching right table columns with NULL.",
    "questionType": "MCQ"
  },
  {
    "semester": 3,
    "subject": "RDBMS / DBMS",
    "unit": 3,
    "topic": "SQL: DDL & DML",
    "question": "What is the result of TRUNCATE TABLE statement in SQL? [Variant 5]",
    "options": [
      "Deletes schema and data",
      "Deletes all rows quickly without logging individual row deletions",
      "Deletes only filtered rows",
      "Rolls back automatically"
    ],
    "correctAnswer": "Deletes all rows quickly without logging individual row deletions",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "TRUNCATE is a DDL operation that deallocates data pages rapidly.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which CPU scheduling algorithm gives the minimum average waiting time for a given set of processes?",
    "options": [
      "FCFS",
      "SJF (Shortest Job First)",
      "Round Robin",
      "Priority Scheduling"
    ],
    "correctAnswer": "SJF (Shortest Job First)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "SJF is provably optimal in terms of minimizing average waiting time.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What is the 'Convoy Effect' in operating systems?",
    "options": [
      "Short processes waiting behind a long CPU-bound process in FCFS",
      "Deadlock condition",
      "Thrashing in paging",
      "Priority inversion"
    ],
    "correctAnswer": "Short processes waiting behind a long CPU-bound process in FCFS",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Convoy effect happens in FCFS when I/O bound processes queue behind CPU-intensive jobs.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which scheduling algorithm is designed specifically for time-sharing operating systems?",
    "options": [
      "FCFS",
      "Round Robin",
      "Multilevel Feedback",
      "Shortest Remaining Time First"
    ],
    "correctAnswer": "Round Robin",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Round Robin assigns a fixed time quantum (slice) to each process in circular order.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which of the following is NOT a necessary condition for deadlock?",
    "options": [
      "Mutual Exclusion",
      "Hold and Wait",
      "No Preemption",
      "Preemptive Multitasking"
    ],
    "correctAnswer": "Preemptive Multitasking",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "The 4 Coffman conditions are Mutual Exclusion, Hold & Wait, No Preemption, and Circular Wait.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What algorithm is used for Deadlock Avoidance in Operating Systems?",
    "options": [
      "Banker's Algorithm",
      "Dijkstra's Algorithm",
      "Round Robin",
      "LRU Algorithm"
    ],
    "correctAnswer": "Banker's Algorithm",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Banker's algorithm ensures resource allocation never leads to an unsafe state.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which CPU scheduling algorithm gives the minimum average waiting time for a given set of processes? [Variant 2]",
    "options": [
      "FCFS",
      "SJF (Shortest Job First)",
      "Round Robin",
      "Priority Scheduling"
    ],
    "correctAnswer": "SJF (Shortest Job First)",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "SJF is provably optimal in terms of minimizing average waiting time.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What is the 'Convoy Effect' in operating systems? [Variant 2]",
    "options": [
      "Short processes waiting behind a long CPU-bound process in FCFS",
      "Deadlock condition",
      "Thrashing in paging",
      "Priority inversion"
    ],
    "correctAnswer": "Short processes waiting behind a long CPU-bound process in FCFS",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Convoy effect happens in FCFS when I/O bound processes queue behind CPU-intensive jobs.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which scheduling algorithm is designed specifically for time-sharing operating systems? [Variant 2]",
    "options": [
      "FCFS",
      "Round Robin",
      "Multilevel Feedback",
      "Shortest Remaining Time First"
    ],
    "correctAnswer": "Round Robin",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Round Robin assigns a fixed time quantum (slice) to each process in circular order.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which of the following is NOT a necessary condition for deadlock? [Variant 2]",
    "options": [
      "Mutual Exclusion",
      "Hold and Wait",
      "No Preemption",
      "Preemptive Multitasking"
    ],
    "correctAnswer": "Preemptive Multitasking",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "The 4 Coffman conditions are Mutual Exclusion, Hold & Wait, No Preemption, and Circular Wait.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What algorithm is used for Deadlock Avoidance in Operating Systems? [Variant 2]",
    "options": [
      "Banker's Algorithm",
      "Dijkstra's Algorithm",
      "Round Robin",
      "LRU Algorithm"
    ],
    "correctAnswer": "Banker's Algorithm",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Banker's algorithm ensures resource allocation never leads to an unsafe state.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which CPU scheduling algorithm gives the minimum average waiting time for a given set of processes? [Variant 3]",
    "options": [
      "FCFS",
      "SJF (Shortest Job First)",
      "Round Robin",
      "Priority Scheduling"
    ],
    "correctAnswer": "SJF (Shortest Job First)",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "SJF is provably optimal in terms of minimizing average waiting time.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What is the 'Convoy Effect' in operating systems? [Variant 3]",
    "options": [
      "Short processes waiting behind a long CPU-bound process in FCFS",
      "Deadlock condition",
      "Thrashing in paging",
      "Priority inversion"
    ],
    "correctAnswer": "Short processes waiting behind a long CPU-bound process in FCFS",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Convoy effect happens in FCFS when I/O bound processes queue behind CPU-intensive jobs.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which scheduling algorithm is designed specifically for time-sharing operating systems? [Variant 3]",
    "options": [
      "FCFS",
      "Round Robin",
      "Multilevel Feedback",
      "Shortest Remaining Time First"
    ],
    "correctAnswer": "Round Robin",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Round Robin assigns a fixed time quantum (slice) to each process in circular order.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which of the following is NOT a necessary condition for deadlock? [Variant 3]",
    "options": [
      "Mutual Exclusion",
      "Hold and Wait",
      "No Preemption",
      "Preemptive Multitasking"
    ],
    "correctAnswer": "Preemptive Multitasking",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "The 4 Coffman conditions are Mutual Exclusion, Hold & Wait, No Preemption, and Circular Wait.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What algorithm is used for Deadlock Avoidance in Operating Systems? [Variant 3]",
    "options": [
      "Banker's Algorithm",
      "Dijkstra's Algorithm",
      "Round Robin",
      "LRU Algorithm"
    ],
    "correctAnswer": "Banker's Algorithm",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Banker's algorithm ensures resource allocation never leads to an unsafe state.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which CPU scheduling algorithm gives the minimum average waiting time for a given set of processes? [Variant 4]",
    "options": [
      "FCFS",
      "SJF (Shortest Job First)",
      "Round Robin",
      "Priority Scheduling"
    ],
    "correctAnswer": "SJF (Shortest Job First)",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "SJF is provably optimal in terms of minimizing average waiting time.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What is the 'Convoy Effect' in operating systems? [Variant 4]",
    "options": [
      "Short processes waiting behind a long CPU-bound process in FCFS",
      "Deadlock condition",
      "Thrashing in paging",
      "Priority inversion"
    ],
    "correctAnswer": "Short processes waiting behind a long CPU-bound process in FCFS",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Convoy effect happens in FCFS when I/O bound processes queue behind CPU-intensive jobs.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which scheduling algorithm is designed specifically for time-sharing operating systems? [Variant 4]",
    "options": [
      "FCFS",
      "Round Robin",
      "Multilevel Feedback",
      "Shortest Remaining Time First"
    ],
    "correctAnswer": "Round Robin",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "Round Robin assigns a fixed time quantum (slice) to each process in circular order.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which of the following is NOT a necessary condition for deadlock? [Variant 4]",
    "options": [
      "Mutual Exclusion",
      "Hold and Wait",
      "No Preemption",
      "Preemptive Multitasking"
    ],
    "correctAnswer": "Preemptive Multitasking",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "The 4 Coffman conditions are Mutual Exclusion, Hold & Wait, No Preemption, and Circular Wait.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What algorithm is used for Deadlock Avoidance in Operating Systems? [Variant 4]",
    "options": [
      "Banker's Algorithm",
      "Dijkstra's Algorithm",
      "Round Robin",
      "LRU Algorithm"
    ],
    "correctAnswer": "Banker's Algorithm",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Banker's algorithm ensures resource allocation never leads to an unsafe state.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which CPU scheduling algorithm gives the minimum average waiting time for a given set of processes? [Variant 5]",
    "options": [
      "FCFS",
      "SJF (Shortest Job First)",
      "Round Robin",
      "Priority Scheduling"
    ],
    "correctAnswer": "SJF (Shortest Job First)",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "SJF is provably optimal in terms of minimizing average waiting time.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What is the 'Convoy Effect' in operating systems? [Variant 5]",
    "options": [
      "Short processes waiting behind a long CPU-bound process in FCFS",
      "Deadlock condition",
      "Thrashing in paging",
      "Priority inversion"
    ],
    "correctAnswer": "Short processes waiting behind a long CPU-bound process in FCFS",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Convoy effect happens in FCFS when I/O bound processes queue behind CPU-intensive jobs.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which scheduling algorithm is designed specifically for time-sharing operating systems? [Variant 5]",
    "options": [
      "FCFS",
      "Round Robin",
      "Multilevel Feedback",
      "Shortest Remaining Time First"
    ],
    "correctAnswer": "Round Robin",
    "marks": 1,
    "difficulty": "Medium",
    "answer": "Round Robin assigns a fixed time quantum (slice) to each process in circular order.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "Which of the following is NOT a necessary condition for deadlock? [Variant 5]",
    "options": [
      "Mutual Exclusion",
      "Hold and Wait",
      "No Preemption",
      "Preemptive Multitasking"
    ],
    "correctAnswer": "Preemptive Multitasking",
    "marks": 1,
    "difficulty": "Hard",
    "answer": "The 4 Coffman conditions are Mutual Exclusion, Hold & Wait, No Preemption, and Circular Wait.",
    "questionType": "MCQ"
  },
  {
    "semester": 6,
    "subject": "Operating Systems",
    "unit": 2,
    "topic": "CPU Scheduling",
    "question": "What algorithm is used for Deadlock Avoidance in Operating Systems? [Variant 5]",
    "options": [
      "Banker's Algorithm",
      "Dijkstra's Algorithm",
      "Round Robin",
      "LRU Algorithm"
    ],
    "correctAnswer": "Banker's Algorithm",
    "marks": 1,
    "difficulty": "Easy",
    "answer": "Banker's algorithm ensures resource allocation never leads to an unsafe state.",
    "questionType": "MCQ"
  }
];

async function seedMCQ() {
  const inserted = await Question.insertMany(MCQ_DATA);
  console.log('[Seed] Seeded ' + inserted.length + ' comprehensive MCQ records (>=25 per topic)');
  return inserted;
}

module.exports = { seedMCQ, MCQ_DATA };
