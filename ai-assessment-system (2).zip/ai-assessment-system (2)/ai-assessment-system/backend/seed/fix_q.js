﻿const fs = require("fs");
const path = require("path");

const qPath = path.join(__dirname, "seedQuestions.js");
let content = fs.readFileSync(qPath, "utf8");
content = content.replace("THEORY_QUESTION_BASE", "QUESTIONS_DATA");
fs.writeFileSync(qPath, content, "utf8");
console.log("Fixed seedQuestions.js export");
