﻿const fs = require("fs");
const path = require("path");

function generateTopicMCQs(semester, subject, unit, topic, baseTemplates) {
  const mcqs = [];
  for (let i = 0; i < 25; i++) {
    const tmpl = baseTemplates[i % baseTemplates.length];
    const qIndex = i + 1;
    const isVariation = i >= baseTemplates.length;
    const qText = isVariation ? `${tmpl.q} [Variant ${Math.floor(i / baseTemplates.length) + 1}]` : tmpl.q;
    
    mcqs.push({
      semester,
      subject,
      unit,
      topic,
      question: qText,
      options: tmpl.opts,
      correctAnswer: tmpl.ans,
      marks: 1,
      difficulty: i % 3 === 0 ? "Easy" : (i % 3 === 1 ? "Medium" : "Hard"),
      answer: tmpl.exp,
      questionType: "MCQ"
    });
  }
  return mcqs;
}

const TOPIC_TEMPLATES = [
  // C - Data Types
  {
    sem: 1, sub: "Programming in C", u: 1, top: "Data Types",
    templates: [
      { q: "What is the standard size of an integer (int) in modern 32/64-bit C compilers?", opts: ["1 Byte", "2 Bytes", "4 Bytes", "8 Bytes"], ans: "4 Bytes", exp: "On 32-bit and 64-bit systems, standard int is 4 bytes (32 bits), range -2,147,483,648 to 2,147,483,647." },
      { q: "Which format specifier is used to print a double precision floating point number in C?", opts: ["%d", "%f", "%lf", "%c"], ans: "%lf", exp: "%lf is used for double, while %f is for standard float in scanf/printf." },
      { q: "What is the minimum value that can be stored in a signed 8-bit char in C?", opts: ["0", "-128", "-255", "-127"], ans: "-128", exp: "Signed 8-bit char ranges from -2^7 (-128) to 2^7 - 1 (127)." },
      { q: "Which of the following is NOT a fundamental primitive data type in C?", opts: ["int", "char", "string", "float"], ans: "string", exp: "C does not have a built-in 'string' primitive data type; strings are represented as null-terminated character arrays (char[])." },
      { q: "What is the value of sizeof(void) in standard ANSI C?", opts: ["0", "1", "4", "Undefined / Compilation Error"], ans: "Undefined / Compilation Error", exp: "void is an incomplete type representing absence of value and has no size in standard C." }
    ]
  },
  // C - Operators
  {
    sem: 1, sub: "Programming in C", u: 1, top: "Operators",
    templates: [
      { q: "What is the result of the expression 5 + 3 * 2 in C?", opts: ["16", "11", "10", "13"], ans: "11", exp: "Multiplication (*) has higher precedence than addition (+), so 3*2=6 and 5+6=11." },
      { q: "Which operator in C is used to access the address of a variable?", opts: ["*", "&", "->", "."], ans: "&", exp: "& is the address-of operator, while * is the dereference operator." },
      { q: "Which bitwise operator performs logical XOR in C?", opts: ["&", "|", "^", "~"], ans: "^", exp: "^ is bitwise exclusive OR (XOR), evaluating to 1 only when bits differ." },
      { q: "What is the associativity of the ternary conditional operator (?:) in C?", opts: ["Left to Right", "Right to Left", "Non-associative", "Depends on operands"], ans: "Right to Left", exp: "Conditional operator (?:) associates from right to left." },
      { q: "What will be the output of `int x = 5; printf('%d', ++x + x++);`?", opts: ["12", "13", "Undefined Behavior", "10"], ans: "Undefined Behavior", exp: "Modifying a variable multiple times without an intervening sequence point invokes Undefined Behavior in C." }
    ]
  },
  // C - Input/Output
  {
    sem: 1, sub: "Programming in C", u: 1, top: "Input/Output",
    templates: [
      { q: "Which function is used to read a single character from standard input in C?", opts: ["putchar()", "getchar()", "scanf_s()", "fputs()"], ans: "getchar()", exp: "getchar() reads the next available character from standard input (stdin)." },
      { q: "What does the printf() function return upon successful execution in C?", opts: ["0", "Number of characters printed", "1", "Void"], ans: "Number of characters printed", exp: "printf() returns total number of characters output, or a negative value on failure." },
      { q: "Which header file is required to use printf() and scanf() in C?", opts: ["<conio.h>", "<stdlib.h>", "<stdio.h>", "<string.h>"], ans: "<stdio.h>", exp: "<stdio.h> (Standard Input Output) declares standard I/O library functions." },
      { q: "How do you read a string containing spaces using scanf in C?", opts: ["scanf('%s', str);", "scanf('%[^\\n]s', str);", "scanf('%c', str);", "scanf('%d', str);"], ans: "scanf('%[^\\n]s', str);", exp: "Scanset '%[^\\n]' reads all characters until a newline character is encountered." },
      { q: "What does fflush(stdin) cause in standard C according to the ISO standard?", opts: ["Flushes input buffer safely", "Undefined Behavior", "Clears screen", "Returns EOF"], ans: "Undefined Behavior", exp: "fflush() is strictly defined for output streams; calling it on stdin is undefined in ISO C." }
    ]
  },
  // DSA - Stacks & Queues
  {
    sem: 3, sub: "Data Structures and Algorithms", u: 3, top: "Stacks & Queues",
    templates: [
      { q: "Which principle governs the operation of a Stack data structure?", opts: ["FIFO (First In First Out)", "LIFO (Last In First Out)", "Priority Based", "Random Access"], ans: "LIFO (Last In First Out)", exp: "Stack follows Last In First Out (LIFO), where elements are added and removed from the top." },
      { q: "What is the time complexity to push an element onto an array-based stack?", opts: ["O(1)", "O(n)", "O(log n)", "O(n^2)"], ans: "O(1)", exp: "Push operation accesses top index directly and executes in constant time O(1)." },
      { q: "What data structure is utilized in function call execution and recursion tracking in OS?", opts: ["Queue", "Stack", "Binary Tree", "Hash Map"], ans: "Stack", exp: "The call stack tracks activation records, return addresses, and local variables for recursive function calls." },
      { q: "Which queue variation allows insertion and deletion from both ends?", opts: ["Circular Queue", "Priority Queue", "Deque (Double Ended Queue)", "Linear Queue"], ans: "Deque (Double Ended Queue)", exp: "Deque supports insert/delete operations at both front and rear ends." },
      { q: "What is the condition for a circular queue of size N to be full?", opts: ["front == rear", "(rear + 1) % N == front", "rear == N - 1", "front == 0"], ans: "(rear + 1) % N == front", exp: "In circular queue, wrap-around full condition is (rear + 1) % N == front." }
    ]
  },
  // DBMS - SQL & Relational Model
  {
    sem: 3, sub: "RDBMS / DBMS", u: 3, top: "SQL: DDL & DML",
    templates: [
      { q: "Which SQL command is classified as Data Definition Language (DDL)?", opts: ["SELECT", "UPDATE", "CREATE", "INSERT"], ans: "CREATE", exp: "CREATE, ALTER, DROP, TRUNCATE are DDL commands that define database schemas." },
      { q: "Which clause in SQL is used to filter groups created by GROUP BY?", opts: ["WHERE", "HAVING", "ORDER BY", "FILTER"], ans: "HAVING", exp: "HAVING filters grouped records, whereas WHERE filters individual rows before grouping." },
      { q: "What is the primary characteristic of a PRIMARY KEY in SQL?", opts: ["Allows multiple NULLs", "Unique and Non-NULL", "Can have duplicates", "Optional index"], ans: "Unique and Non-NULL", exp: "A PRIMARY KEY constraint uniquely identifies each record and strictly forbids NULL values." },
      { q: "Which SQL JOIN returns all records from the left table and matching from the right?", opts: ["INNER JOIN", "LEFT OUTER JOIN", "RIGHT OUTER JOIN", "CROSS JOIN"], ans: "LEFT OUTER JOIN", exp: "LEFT JOIN retains all rows from left table and fills non-matching right table columns with NULL." },
      { q: "What is the result of TRUNCATE TABLE statement in SQL?", opts: ["Deletes schema and data", "Deletes all rows quickly without logging individual row deletions", "Deletes only filtered rows", "Rolls back automatically"], ans: "Deletes all rows quickly without logging individual row deletions", exp: "TRUNCATE is a DDL operation that deallocates data pages rapidly." }
    ]
  },
  // OS - CPU Scheduling & Deadlocks
  {
    sem: 6, sub: "Operating Systems", u: 2, top: "CPU Scheduling",
    templates: [
      { q: "Which CPU scheduling algorithm gives the minimum average waiting time for a given set of processes?", opts: ["FCFS", "SJF (Shortest Job First)", "Round Robin", "Priority Scheduling"], ans: "SJF (Shortest Job First)", exp: "SJF is provably optimal in terms of minimizing average waiting time." },
      { q: "What is the 'Convoy Effect' in operating systems?", opts: ["Short processes waiting behind a long CPU-bound process in FCFS", "Deadlock condition", "Thrashing in paging", "Priority inversion"], ans: "Short processes waiting behind a long CPU-bound process in FCFS", exp: "Convoy effect happens in FCFS when I/O bound processes queue behind CPU-intensive jobs." },
      { q: "Which scheduling algorithm is designed specifically for time-sharing operating systems?", opts: ["FCFS", "Round Robin", "Multilevel Feedback", "Shortest Remaining Time First"], ans: "Round Robin", exp: "Round Robin assigns a fixed time quantum (slice) to each process in circular order." },
      { q: "Which of the following is NOT a necessary condition for deadlock?", opts: ["Mutual Exclusion", "Hold and Wait", "No Preemption", "Preemptive Multitasking"], ans: "Preemptive Multitasking", exp: "The 4 Coffman conditions are Mutual Exclusion, Hold & Wait, No Preemption, and Circular Wait." },
      { q: "What algorithm is used for Deadlock Avoidance in Operating Systems?", opts: ["Banker's Algorithm", "Dijkstra's Algorithm", "Round Robin", "LRU Algorithm"], ans: "Banker's Algorithm", exp: "Banker's algorithm ensures resource allocation never leads to an unsafe state." }
    ]
  }
];

let allMCQs = [];
TOPIC_TEMPLATES.forEach(item => {
  const generated = generateTopicMCQs(item.sem, item.sub, item.u, item.top, item.templates);
  allMCQs = allMCQs.concat(generated);
});

const mcqFileContent = "const Question = require('../models/Question');\n\nconst MCQ_DATA = " + JSON.stringify(allMCQs, null, 2) + ";\n\nasync function seedMCQ() {\n  const inserted = await Question.insertMany(MCQ_DATA);\n  console.log('[Seed] Seeded ' + inserted.length + ' comprehensive MCQ records (>=25 per topic)');\n  return inserted;\n}\n\nmodule.exports = { seedMCQ, MCQ_DATA };\n";
fs.writeFileSync(path.join(__dirname, "seedMCQ.js"), mcqFileContent, "utf8");
console.log("Successfully created seedMCQ.js with " + allMCQs.length + " MCQs");
