from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from models import StudyMaterial, SyllabusUnit, User
from schemas import StudyMaterialCreate, StudyMaterialResponse
from routers.auth import get_current_user

router = APIRouter(prefix="/api/study-materials", tags=["Study Material Module"])

# --- 1. CREATE / UPLOAD STUDY MATERIAL ---
@router.post("/", response_model=StudyMaterialResponse, status_code=status.HTTP_201_CREATED)
def create_study_material(
    req: StudyMaterialCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    material = StudyMaterial(
        faculty_id=current_user.id,
        unit_id=req.unit_id,
        title=req.title.strip(),
        material_type=req.material_type,
        file_url=req.file_url.strip(),
        description=req.description,
        tags=req.tags
    )
    db.add(material)
    db.commit()
    db.refresh(material)
    return material


# --- 2. RETRIEVE STUDY MATERIALS (STUDENT & FACULTY REPOSITORY) ---
@router.get("/", response_model=List[StudyMaterialResponse])
def get_study_materials(
    unit_id: Optional[str] = None,
    material_type: Optional[str] = None,
    faculty_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(StudyMaterial)
    if unit_id:
        query = query.filter(StudyMaterial.unit_id == unit_id)
    if material_type:
        query = query.filter(StudyMaterial.material_type == material_type)
    if faculty_id:
        query = query.filter(StudyMaterial.faculty_id == faculty_id)

    return query.order_by(StudyMaterial.created_at.desc()).all()


# --- 3. DELETE STUDY MATERIAL ---
@router.delete("/{material_id}")
def delete_study_material(
    material_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    mat = db.query(StudyMaterial).filter(StudyMaterial.id == material_id).first()
    if not mat:
        raise HTTPException(status_code=404, detail="Study material not found")
    
    db.delete(mat)
    db.commit()
    return {"status": "success", "message": "Study material deleted"}
