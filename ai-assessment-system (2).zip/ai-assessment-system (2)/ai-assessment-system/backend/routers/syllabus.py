from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from models import SyllabusUnit, SyllabusTopic, User
from schemas import (
    SyllabusUnitCreate, SyllabusUnitUpdate, SyllabusUnitResponse,
    TopicCreate, TopicResponse
)
from routers.auth import get_current_user

router = APIRouter(prefix="/api/syllabus", tags=["Syllabus Management Module"])

# --- 1. CREATE SYLLABUS UNIT (WITH NESTED TOPICS) ---
@router.post("/units", response_model=SyllabusUnitResponse, status_code=status.HTTP_201_CREATED)
def create_syllabus_unit(
    req: SyllabusUnitCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    unit = SyllabusUnit(
        faculty_id=current_user.id,
        subject_code=req.subject_code.upper().strip(),
        subject_name=req.subject_name.strip(),
        unit_number=req.unit_number,
        unit_title=req.unit_title.strip(),
        description=req.description
    )
    db.add(unit)
    db.flush()

    if req.topics:
        for t in req.topics:
            topic = SyllabusTopic(
                unit_id=unit.id,
                topic_name=t.topic_name.strip(),
                learning_objectives=t.learning_objectives,
                bloom_taxonomy_level=t.bloom_taxonomy_level or "Understand",
                weightage_percentage=t.weightage_percentage or 10
            )
            db.add(topic)

    db.commit()
    db.refresh(unit)
    return unit


# --- 2. READ ALL SYLLABUS UNITS (FILTER BY SUBJECT OR FACULTY) ---
@router.get("/units", response_model=List[SyllabusUnitResponse])
def get_syllabus_units(
    subject_code: Optional[str] = None,
    faculty_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(SyllabusUnit)
    if subject_code:
        query = query.filter(SyllabusUnit.subject_code == subject_code.upper().strip())
    if faculty_id:
        query = query.filter(SyllabusUnit.faculty_id == faculty_id)
    
    return query.order_by(SyllabusUnit.unit_number.asc()).all()


# --- 3. READ SINGLE SYLLABUS UNIT ---
@router.get("/units/{unit_id}", response_model=SyllabusUnitResponse)
def get_single_unit(unit_id: str, db: Session = Depends(get_db)):
    unit = db.query(SyllabusUnit).filter(SyllabusUnit.id == unit_id).first()
    if not unit:
        raise HTTPException(status_code=404, detail="Syllabus unit not found")
    return unit


# --- 4. UPDATE SYLLABUS UNIT ---
@router.put("/units/{unit_id}", response_model=SyllabusUnitResponse)
def update_syllabus_unit(
    unit_id: str,
    req: SyllabusUnitUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    unit = db.query(SyllabusUnit).filter(SyllabusUnit.id == unit_id).first()
    if not unit:
        raise HTTPException(status_code=404, detail="Syllabus unit not found")

    if req.subject_code:
        unit.subject_code = req.subject_code.upper().strip()
    if req.subject_name:
        unit.subject_name = req.subject_name.strip()
    if req.unit_number is not None:
        unit.unit_number = req.unit_number
    if req.unit_title:
        unit.unit_title = req.unit_title.strip()
    if req.description is not None:
        unit.description = req.description

    db.commit()
    db.refresh(unit)
    return unit


# --- 5. DELETE SYLLABUS UNIT ---
@router.delete("/units/{unit_id}")
def delete_syllabus_unit(
    unit_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    unit = db.query(SyllabusUnit).filter(SyllabusUnit.id == unit_id).first()
    if not unit:
        raise HTTPException(status_code=404, detail="Syllabus unit not found")
    
    db.delete(unit)
    db.commit()
    return {"status": "success", "message": f"Syllabus unit '{unit.unit_title}' and related topics deleted"}


# --- 6. ADD TOPIC TO UNIT ---
@router.post("/units/{unit_id}/topics", response_model=TopicResponse)
def add_topic_to_unit(
    unit_id: str,
    req: TopicCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    unit = db.query(SyllabusUnit).filter(SyllabusUnit.id == unit_id).first()
    if not unit:
        raise HTTPException(status_code=404, detail="Unit not found")

    topic = SyllabusTopic(
        unit_id=unit.id,
        topic_name=req.topic_name.strip(),
        learning_objectives=req.learning_objectives,
        bloom_taxonomy_level=req.bloom_taxonomy_level or "Understand",
        weightage_percentage=req.weightage_percentage or 10
    )
    db.add(topic)
    db.commit()
    db.refresh(topic)
    return topic


# --- 7. DELETE SINGLE TOPIC ---
@router.delete("/topics/{topic_id}")
def delete_topic(
    topic_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    topic = db.query(SyllabusTopic).filter(SyllabusTopic.id == topic_id).first()
    if not topic:
        raise HTTPException(status_code=404, detail="Topic not found")
    
    db.delete(topic)
    db.commit()
    return {"status": "success", "message": "Topic removed successfully"}
