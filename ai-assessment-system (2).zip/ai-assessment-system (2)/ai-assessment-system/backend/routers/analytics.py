from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import TestAttempt, PerformanceSummary, User, QuestionPaper
from schemas import StudentAnalyticsResponse, TopicMasteryItem, TestAttemptResponse, StudentAnswerResponse
from routers.auth import get_current_user

router = APIRouter(prefix="/api/analytics", tags=["Result & Performance Analysis Module"])

# --- 1. GET STUDENT PERFORMANCE ANALYTICS & TOPIC MASTERY ---
@router.get("/student/{student_id}", response_model=StudentAnalyticsResponse)
def get_student_performance(student_id: str, db: Session = Depends(get_db)):
    student = db.query(User).filter(User.id == student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    attempts = db.query(TestAttempt).filter(
        TestAttempt.student_id == student_id,
        TestAttempt.status == "GRADED"
    ).order_by(TestAttempt.created_at.desc()).all()

    total_tests = len(attempts)
    avg_score = round(sum(a.percentage for a in attempts) / total_tests, 2) if total_tests > 0 else 0.0
    highest_score = max([a.percentage for a in attempts], default=0.0)
    total_time_mins = round(sum(a.time_taken_seconds for a in attempts) / 60.0, 1) if total_tests > 0 else 0.0

    # Topic Mastery from PerformanceSummary
    summaries = db.query(PerformanceSummary).filter(PerformanceSummary.student_id == student_id).all()
    
    strengths = []
    weaknesses = []

    for s in summaries:
        status_label = "Mastered" if s.mastery_percentage >= 75.0 else ("Needs Revision" if s.mastery_percentage >= 50.0 else "Critical")
        item = TopicMasteryItem(
            topic_name=s.topic_name,
            total_questions=s.total_questions_attempted,
            correct_questions=s.total_questions_correct,
            mastery_percentage=s.mastery_percentage,
            status=status_label
        )
        if s.mastery_percentage >= 70.0:
            strengths.append(item)
        else:
            weaknesses.append(item)

    recent_attempts_resp = []
    for att in attempts[:10]: # Return top 10 recent
        ans_list = []
        for a in att.answers:
            ans_list.append(StudentAnswerResponse(
                id=a.id,
                question_id=a.question_id,
                question_text=a.question.question_text if a.question else "",
                selected_option=a.selected_option,
                text_response=a.text_response,
                correct_answer=a.question.correct_answer if a.question else "",
                explanation=a.question.explanation if a.question else "",
                is_correct=a.is_correct,
                awarded_marks=a.awarded_marks,
                faculty_or_ai_feedback=a.faculty_or_ai_feedback
            ))

        recent_attempts_resp.append(TestAttemptResponse(
            id=att.id,
            student_id=att.student_id,
            paper_id=att.paper_id,
            paper_title=att.paper.title if att.paper else "",
            subject_code=att.paper.subject_code if att.paper else "",
            subject_name=att.paper.subject_name if att.paper else "",
            start_time=att.start_time,
            submission_time=att.submission_time,
            status=att.status,
            total_score=att.total_score,
            max_possible_score=att.max_possible_score,
            percentage=att.percentage,
            time_taken_seconds=att.time_taken_seconds,
            created_at=att.created_at,
            answers=ans_list
        ))

    return StudentAnalyticsResponse(
        student_id=student.id,
        student_name=student.name,
        total_tests_taken=total_tests,
        average_score_percentage=avg_score,
        highest_score_percentage=highest_score,
        total_time_spent_mins=total_time_mins,
        topic_strengths=strengths,
        topic_weaknesses=weaknesses,
        recent_attempts=recent_attempts_resp
    )


# --- 2. FACULTY CLASS-WIDE ANALYTICS ---
@router.get("/faculty-overview")
def get_faculty_class_overview(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    total_papers = db.query(QuestionPaper).filter(QuestionPaper.faculty_id == current_user.id).count()
    total_attempts = db.query(TestAttempt).join(QuestionPaper).filter(QuestionPaper.faculty_id == current_user.id).count()
    
    attempts = db.query(TestAttempt).join(QuestionPaper).filter(QuestionPaper.faculty_id == current_user.id).all()
    avg_score = round(sum(a.percentage for a in attempts) / len(attempts), 2) if attempts else 0.0

    return {
        "faculty_id": current_user.id,
        "faculty_name": current_user.name,
        "department": current_user.department,
        "total_generated_papers": total_papers,
        "total_student_assessments": total_attempts,
        "class_average_score": avg_score
    }
