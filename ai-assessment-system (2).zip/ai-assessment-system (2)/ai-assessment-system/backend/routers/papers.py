import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from models import QuestionPaper, Question, SyllabusUnit, User
from schemas import (
    AIPaperGenerateRequest, AIShuffleRequest,
    QuestionPaperCreate, QuestionPaperUpdate, QuestionPaperResponse,
    QuestionCreate, QuestionUpdate, QuestionResponse, OptionItem
)
from routers.auth import get_current_user
from ai_service import generate_ai_question_paper, shuffle_question_paper_set

router = APIRouter(prefix="/api/papers", tags=["Question Paper Generation & Management"])

def _format_paper_response(paper: QuestionPaper) -> QuestionPaperResponse:
    q_responses = []
    for q in paper.questions:
        opts = []
        if q.options:
            if isinstance(q.options, str):
                try:
                    opts_raw = json.loads(q.options)
                    opts = [OptionItem(**o) for o in opts_raw]
                except Exception:
                    opts = []
            elif isinstance(q.options, list):
                opts = [OptionItem(**o) if isinstance(o, dict) else o for o in q.options]

        q_responses.append(QuestionResponse(
            id=q.id,
            paper_id=q.paper_id,
            topic_id=q.topic_id,
            question_order=q.question_order,
            question_type=q.question_type,
            question_text=q.question_text,
            options=opts,
            correct_answer=q.correct_answer,
            explanation=q.explanation,
            marks=q.marks,
            bloom_level=q.bloom_level,
            created_at=q.created_at
        ))

    return QuestionPaperResponse(
        id=paper.id,
        faculty_id=paper.faculty_id,
        subject_code=paper.subject_code,
        subject_name=paper.subject_name,
        title=paper.title,
        paper_set=paper.paper_set,
        exam_duration_mins=paper.exam_duration_mins,
        total_marks=paper.total_marks,
        difficulty_level=paper.difficulty_level,
        instructions=paper.instructions,
        is_published=paper.is_published,
        ai_prompt_meta=paper.ai_prompt_meta,
        created_at=paper.created_at,
        updated_at=paper.updated_at,
        questions=q_responses
    )


# --- 1. AI QUESTION PAPER GENERATION & DATABASE PERSISTENCE ---
@router.post("/generate-ai", response_model=QuestionPaperResponse, status_code=status.HTTP_201_CREATED)
def generate_and_save_ai_paper(
    req: AIPaperGenerateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Step 1: Fetch selected syllabus units & topics from DB
    units = db.query(SyllabusUnit).filter(SyllabusUnit.id.in_(req.unit_ids)).all()
    if not units:
        # Fallback to all units for this subject if specific IDs not found
        units = db.query(SyllabusUnit).filter(SyllabusUnit.subject_code == req.subject_code.upper()).all()

    syllabus_context = []
    for u in units:
        syllabus_context.append({
            "unit_number": u.unit_number,
            "unit_title": u.unit_title,
            "topics": [
                {
                    "topic_name": t.topic_name,
                    "bloom_taxonomy_level": t.bloom_taxonomy_level,
                    "learning_objectives": t.learning_objectives
                } for t in u.topics
            ]
        })

    # Step 2: Send context to AI Model & generate structured output
    ai_output = generate_ai_question_paper(req, syllabus_context)

    # Step 3: Save generated Question Paper record directly into Database
    new_paper = QuestionPaper(
        faculty_id=current_user.id,
        subject_code=req.subject_code.upper().strip(),
        subject_name=req.subject_name.strip(),
        title=req.title.strip(),
        paper_set=req.paper_set or "A",
        exam_duration_mins=req.exam_duration_mins,
        total_marks=ai_output.total_marks,
        difficulty_level=req.difficulty_level,
        instructions=ai_output.instructions,
        is_published=False,
        ai_prompt_meta=json.dumps({
            "unit_ids": req.unit_ids,
            "difficulty": req.difficulty_level,
            "num_mcq": req.num_mcq,
            "num_short": req.num_short,
            "num_long": req.num_long,
            "custom_instructions": req.custom_instructions
        })
    )
    db.add(new_paper)
    db.flush()

    # Step 4: Save individual Question records into Database
    for idx, q in enumerate(ai_output.questions, start=1):
        question_obj = Question(
            paper_id=new_paper.id,
            question_order=idx,
            question_type=q.question_type,
            question_text=q.question_text,
            options=json.dumps(q.options) if q.options else None,
            correct_answer=q.correct_answer,
            explanation=q.explanation,
            marks=q.marks,
            bloom_level=q.bloom_level
        )
        db.add(question_obj)

    db.commit()
    db.refresh(new_paper)
    return _format_paper_response(new_paper)


# --- 2. FETCH QUESTION PAPERS (FACULTY / QUESTION BANK FILTER) ---
@router.get("/", response_model=List[QuestionPaperResponse])
def get_all_papers(
    subject_code: Optional[str] = None,
    is_published: Optional[bool] = None,
    paper_set: Optional[str] = None,
    faculty_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(QuestionPaper)
    if subject_code:
        query = query.filter(QuestionPaper.subject_code == subject_code.upper().strip())
    if is_published is not None:
        query = query.filter(QuestionPaper.is_published == is_published)
    if paper_set:
        query = query.filter(QuestionPaper.paper_set == paper_set)
    if faculty_id:
        query = query.filter(QuestionPaper.faculty_id == faculty_id)

    papers = query.order_by(QuestionPaper.created_at.desc()).all()
    return [_format_paper_response(p) for p in papers]


# --- 3. GET SINGLE QUESTION PAPER DETAILS ---
@router.get("/{paper_id}", response_model=QuestionPaperResponse)
def get_paper_by_id(paper_id: str, db: Session = Depends(get_db)):
    paper = db.query(QuestionPaper).filter(QuestionPaper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Question paper not found")
    return _format_paper_response(paper)


# --- 4. UPDATE QUESTION PAPER METADATA ---
@router.put("/{paper_id}", response_model=QuestionPaperResponse)
def update_paper(
    paper_id: str,
    req: QuestionPaperUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    paper = db.query(QuestionPaper).filter(QuestionPaper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Question paper not found")

    if req.title:
        paper.title = req.title.strip()
    if req.paper_set:
        paper.paper_set = req.paper_set
    if req.exam_duration_mins:
        paper.exam_duration_mins = req.exam_duration_mins
    if req.total_marks is not None:
        paper.total_marks = req.total_marks
    if req.difficulty_level:
        paper.difficulty_level = req.difficulty_level
    if req.instructions is not None:
        paper.instructions = req.instructions
    if req.is_published is not None:
        paper.is_published = req.is_published

    db.commit()
    db.refresh(paper)
    return _format_paper_response(paper)


# --- 5. EDIT / UPDATE AN INDIVIDUAL QUESTION (MANUAL EDIT) ---
@router.put("/questions/{question_id}", response_model=QuestionResponse)
def update_individual_question(
    question_id: str,
    req: QuestionUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    q = db.query(Question).filter(Question.id == question_id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")

    if req.question_order is not None:
        q.question_order = req.question_order
    if req.question_type:
        q.question_type = req.question_type
    if req.question_text:
        q.question_text = req.question_text
    if req.options is not None:
        q.options = json.dumps([o.dict() for o in req.options])
    if req.correct_answer is not None:
        q.correct_answer = req.correct_answer
    if req.explanation is not None:
        q.explanation = req.explanation
    if req.marks is not None:
        q.marks = req.marks
    if req.bloom_level:
        q.bloom_level = req.bloom_level
    if req.topic_id is not None:
        q.topic_id = req.topic_id

    db.commit()
    db.refresh(q)

    opts = []
    if q.options:
        try:
            opts_raw = json.loads(q.options)
            opts = [OptionItem(**o) for o in opts_raw]
        except Exception:
            opts = []

    return QuestionResponse(
        id=q.id,
        paper_id=q.paper_id,
        topic_id=q.topic_id,
        question_order=q.question_order,
        question_type=q.question_type,
        question_text=q.question_text,
        options=opts,
        correct_answer=q.correct_answer,
        explanation=q.explanation,
        marks=q.marks,
        bloom_level=q.bloom_level,
        created_at=q.created_at
    )


# --- 6. AUTO-SHUFFLE & CREATE NEW PAPER SET (SET B, SET C) ---
@router.post("/shuffle", response_model=QuestionPaperResponse, status_code=status.HTTP_201_CREATED)
def shuffle_and_save_new_set(
    req: AIShuffleRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    source_paper = db.query(QuestionPaper).filter(QuestionPaper.id == req.source_paper_id).first()
    if not source_paper:
        raise HTTPException(status_code=404, detail="Source paper not found")

    questions_payload = []
    for q in source_paper.questions:
        questions_payload.append({
            "topic_id": q.topic_id,
            "question_type": q.question_type,
            "question_text": q.question_text,
            "options": q.options,
            "correct_answer": q.correct_answer,
            "explanation": q.explanation,
            "marks": q.marks,
            "bloom_level": q.bloom_level
        })

    # Execute shuffle logic
    shuffled_questions = shuffle_question_paper_set(questions_payload, target_set=req.new_set_name)

    # Create new paper record in DB
    new_set_paper = QuestionPaper(
        faculty_id=current_user.id,
        subject_code=source_paper.subject_code,
        subject_name=source_paper.subject_name,
        title=f"{source_paper.title} ({req.new_set_name})",
        paper_set=req.new_set_name.replace("Set ", "").strip(),
        exam_duration_mins=source_paper.exam_duration_mins,
        total_marks=source_paper.total_marks,
        difficulty_level=source_paper.difficulty_level,
        instructions=source_paper.instructions,
        is_published=source_paper.is_published,
        ai_prompt_meta=json.dumps({"source_paper_id": source_paper.id, "shuffled_at": "auto"})
    )
    db.add(new_set_paper)
    db.flush()

    # Save shuffled questions into DB
    for idx, sq in enumerate(shuffled_questions, start=1):
        db_q = Question(
            paper_id=new_set_paper.id,
            topic_id=sq.get("topic_id"),
            question_order=idx,
            question_type=sq["question_type"],
            question_text=sq["question_text"],
            options=sq["options"] if isinstance(sq["options"], str) else json.dumps(sq["options"]),
            correct_answer=sq["correct_answer"],
            explanation=sq["explanation"],
            marks=sq["marks"],
            bloom_level=sq["bloom_level"]
        )
        db.add(db_q)

    db.commit()
    db.refresh(new_set_paper)
    return _format_paper_response(new_set_paper)


# --- 7. TOGGLE PUBLISH STATUS ---
@router.patch("/{paper_id}/publish", response_model=QuestionPaperResponse)
def toggle_publish(paper_id: str, db: Session = Depends(get_db)):
    paper = db.query(QuestionPaper).filter(QuestionPaper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Question paper not found")
    
    paper.is_published = not paper.is_published
    db.commit()
    db.refresh(paper)
    return _format_paper_response(paper)


# --- 8. DELETE QUESTION PAPER ---
@router.delete("/{paper_id}")
def delete_paper(paper_id: str, db: Session = Depends(get_db)):
    paper = db.query(QuestionPaper).filter(QuestionPaper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Question paper not found")
    
    db.delete(paper)
    db.commit()
    return {"status": "success", "message": f"Question paper '{paper.title}' deleted"}
