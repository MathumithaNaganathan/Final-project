import json
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from models import QuestionPaper, Question, TestAttempt, StudentAnswer, PerformanceSummary, SyllabusTopic, User
from schemas import (
    TestSubmitRequest, TestAttemptResponse, StudentAnswerResponse,
    QuestionPaperResponse, QuestionResponse, OptionItem
)
from routers.auth import get_current_user

router = APIRouter(prefix="/api/tests", tags=["MCQ Online Test Module"])

# --- 1. FETCH ACTIVE TEST FOR STUDENT (WITHOUT LEAKING ANSWERS) ---
@router.get("/active/{paper_id}", response_model=QuestionPaperResponse)
def get_active_test_paper(paper_id: str, db: Session = Depends(get_db)):
    paper = db.query(QuestionPaper).filter(QuestionPaper.id == paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Test paper not found")
    
    if not paper.is_published:
        raise HTTPException(status_code=403, detail="This test is not currently active or published")

    q_responses = []
    for q in paper.questions:
        opts = []
        if q.options:
            try:
                opts_raw = json.loads(q.options) if isinstance(q.options, str) else q.options
                opts = [OptionItem(**o) for o in opts_raw]
            except Exception:
                opts = []

        # Mask correct_answer and explanation while student takes test
        q_responses.append(QuestionResponse(
            id=q.id,
            paper_id=q.paper_id,
            topic_id=q.topic_id,
            question_order=q.question_order,
            question_type=q.question_type,
            question_text=q.question_text,
            options=opts,
            correct_answer=None, # Hidden during test
            explanation=None, # Hidden during test
            marks=q.marks,
            bloom_level=q.bloom_level,
            created_at=q.created_at
        ))

    return QuestionPaperResponse(
        id=paper.id,
        faculty_id=paper.faculty_id,
        subject_code=paper.subject_code,
        subject_name=paper.subject_name,
        title=paper.title,
        paper_set=paper.paper_set,
        exam_duration_mins=paper.exam_duration_mins,
        total_marks=paper.total_marks,
        difficulty_level=paper.difficulty_level,
        instructions=paper.instructions,
        is_published=paper.is_published,
        ai_prompt_meta=None,
        created_at=paper.created_at,
        updated_at=paper.updated_at,
        questions=q_responses
    )


# --- 2. PROCESS STUDENT SUBMISSION & SAVE INDIVIDUAL ANSWERS ---
@router.post("/submit", response_model=TestAttemptResponse, status_code=status.HTTP_201_CREATED)
def submit_test_attempt(
    req: TestSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    paper = db.query(QuestionPaper).filter(QuestionPaper.id == req.paper_id).first()
    if not paper:
        raise HTTPException(status_code=404, detail="Question paper not found")

    # Map question IDs to question objects
    q_map = {q.id: q for q in paper.questions}
    
    total_score = 0.0
    max_possible_score = sum(q.marks for q in paper.questions) if paper.questions else float(paper.total_marks)
    
    attempt = TestAttempt(
        student_id=current_user.id,
        paper_id=paper.id,
        submission_time=datetime.utcnow(),
        status="GRADED",
        time_taken_seconds=req.time_taken_seconds,
        max_possible_score=max_possible_score
    )
    db.add(attempt)
    db.flush()

    answered_responses: List[StudentAnswerResponse] = []
    topic_performance_tracker = {}

    for ans_input in req.answers:
        q_obj = q_map.get(ans_input.question_id)
        if not q_obj:
            continue

        is_correct = False
        awarded_marks = 0.0

        if q_obj.question_type == "MCQ":
            if ans_input.selected_option and q_obj.correct_answer:
                is_correct = (ans_input.selected_option.strip().upper() == q_obj.correct_answer.strip().upper())
                if is_correct:
                    awarded_marks = float(q_obj.marks)
                    total_score += awarded_marks
        else:
            # Text based responses
            if ans_input.text_response and len(ans_input.text_response.strip()) > 10:
                is_correct = True
                awarded_marks = float(q_obj.marks) * 0.8 # Preliminary auto-grade rubric
                total_score += awarded_marks

        # Save individual student answer record to DB
        st_ans = StudentAnswer(
            attempt_id=attempt.id,
            question_id=q_obj.id,
            selected_option=ans_input.selected_option,
            text_response=ans_input.text_response,
            is_correct=is_correct,
            awarded_marks=awarded_marks,
            faculty_or_ai_feedback=q_obj.explanation or "Standard Evaluation Rubric"
        )
        db.add(st_ans)

        # Track topic mastery
        t_name = q_obj.topic.topic_name if q_obj.topic else "General Concepts"
        if t_name not in topic_performance_tracker:
            topic_performance_tracker[t_name] = {"total": 0, "correct": 0}
        topic_performance_tracker[t_name]["total"] += 1
        if is_correct:
            topic_performance_tracker[t_name]["correct"] += 1

        answered_responses.append(StudentAnswerResponse(
            id=st_ans.id,
            question_id=q_obj.id,
            question_text=q_obj.question_text,
            selected_option=st_ans.selected_option,
            text_response=st_ans.text_response,
            correct_answer=q_obj.correct_answer,
            explanation=q_obj.explanation,
            is_correct=is_correct,
            awarded_marks=awarded_marks,
            faculty_or_ai_feedback=st_ans.faculty_or_ai_feedback
        ))

    attempt.total_score = total_score
    attempt.percentage = round((total_score / max_possible_score * 100), 2) if max_possible_score > 0 else 0.0

    # Update or insert PerformanceSummary records
    for t_name, stats in topic_performance_tracker.items():
        perf = db.query(PerformanceSummary).filter(
            PerformanceSummary.student_id == current_user.id,
            PerformanceSummary.subject_code == paper.subject_code,
            PerformanceSummary.topic_name == t_name
        ).first()

        if not perf:
            perf = PerformanceSummary(
                student_id=current_user.id,
                subject_code=paper.subject_code,
                topic_name=t_name,
                total_questions_attempted=stats["total"],
                total_questions_correct=stats["correct"],
                mastery_percentage=round((stats["correct"] / stats["total"] * 100), 2)
            )
            db.add(perf)
        else:
            perf.total_questions_attempted += stats["total"]
            perf.total_questions_correct += stats["correct"]
            perf.mastery_percentage = round(
                (perf.total_questions_correct / perf.total_questions_attempted * 100), 2
            )
            perf.last_evaluated_at = datetime.utcnow()

    db.commit()
    db.refresh(attempt)

    return TestAttemptResponse(
        id=attempt.id,
        student_id=attempt.student_id,
        paper_id=attempt.paper_id,
        paper_title=paper.title,
        subject_code=paper.subject_code,
        subject_name=paper.subject_name,
        start_time=attempt.start_time,
        submission_time=attempt.submission_time,
        status=attempt.status,
        total_score=attempt.total_score,
        max_possible_score=attempt.max_possible_score,
        percentage=attempt.percentage,
        time_taken_seconds=attempt.time_taken_seconds,
        created_at=attempt.created_at,
        answers=answered_responses
    )


# --- 3. GET ATTEMPT DETAILS WITH FULL REVIEW ---
@router.get("/attempts/{attempt_id}", response_model=TestAttemptResponse)
def get_test_attempt_review(attempt_id: str, db: Session = Depends(get_db)):
    attempt = db.query(TestAttempt).filter(TestAttempt.id == attempt_id).first()
    if not attempt:
        raise HTTPException(status_code=404, detail="Attempt not found")

    ans_list = []
    for a in attempt.answers:
        ans_list.append(StudentAnswerResponse(
            id=a.id,
            question_id=a.question_id,
            question_text=a.question.question_text if a.question else "",
            selected_option=a.selected_option,
            text_response=a.text_response,
            correct_answer=a.question.correct_answer if a.question else "",
            explanation=a.question.explanation if a.question else "",
            is_correct=a.is_correct,
            awarded_marks=a.awarded_marks,
            faculty_or_ai_feedback=a.faculty_or_ai_feedback
        ))

    return TestAttemptResponse(
        id=attempt.id,
        student_id=attempt.student_id,
        paper_id=attempt.paper_id,
        paper_title=attempt.paper.title if attempt.paper else "",
        subject_code=attempt.paper.subject_code if attempt.paper else "",
        subject_name=attempt.paper.subject_name if attempt.paper else "",
        start_time=attempt.start_time,
        submission_time=attempt.submission_time,
        status=attempt.status,
        total_score=attempt.total_score,
        max_possible_score=attempt.max_possible_score,
        percentage=attempt.percentage,
        time_taken_seconds=attempt.time_taken_seconds,
        created_at=attempt.created_at,
        answers=ans_list
    )
