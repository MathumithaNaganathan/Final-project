const mongoose = require("mongoose");
let mongod = null;

const connectDB = async () => {
  const uri = process.env.MONGO_URI || "mongodb://localhost:27017/bsc_cs_assessment";
  
  try {
    // Attempt standard MongoDB connection with a 2.5-second timeout
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2500
    });
    console.log(`[Database] Successfully connected to MongoDB at ${uri}`);
    return true;
  } catch (err) {
    console.warn(`[Database] Local MongoDB at ${uri} not reachable (${err.message}).`);
    try {
      console.log(`[Database] Initializing embedded in-memory MongoDB engine...`);
      const { MongoMemoryServer } = require("mongodb-memory-server");
      mongod = await MongoMemoryServer.create();
      const memoryUri = mongod.getUri();
      await mongoose.connect(memoryUri);
      console.log(`[Database] Embedded In-Memory MongoDB connected at ${memoryUri}`);
      return true;
    } catch (memErr) {
      console.warn("[Database] Notice: In-memory MongoDB initialization skipped:", memErr.message);
      return false;
    }
  }
};

const disconnectDB = async () => {
  try {
    await mongoose.disconnect();
    if (mongod) {
      await mongod.stop();
    }
  } catch (err) {
    console.error("[Database] Error disconnecting:", err.message);
  }
};

module.exports = { connectDB, disconnectDB };
