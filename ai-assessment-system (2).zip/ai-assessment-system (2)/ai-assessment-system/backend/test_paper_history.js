const assert = require("assert");

const API_BASE = "http://localhost:5000";

async function runTests() {
  console.log("=================================================");
  console.log("TEST SUITE: MONGODB GENERATED QUESTION PAPER HISTORY");
  console.log("=================================================");

  // 1. Initial History Check
  const getInitialRes = await fetch(`${API_BASE}/api/papers`);
  const initialData = await getInitialRes.json();
  assert.strictEqual(initialData.success, true, "Initial fetch should succeed");
  console.log(`✓ 1. Initial paper history fetched successfully: ${initialData.count} paper(s) found`);

  // 2. Test AI Paper Generation with Automatic MongoDB Persistence
  console.log("\nTesting AI Paper Generation & Automatic MongoDB Persistence...");
  const genPayload = {
    semester: 3,
    subject: "Data Structures and Algorithms",
    selectedUnits: ["1", "2", "3"],
    examType: "Summative Examination",
    duration: "3 Hours",
    totalMarks: 75,
    difficulty: "Medium"
  };

  const genRes = await fetch(`${API_BASE}/api/ai/generate-paper`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(genPayload)
  });
  const genJson = await genRes.json();
  assert.strictEqual(genJson.success, true, "Paper generation should succeed");
  assert.ok(genJson.data._id, "Generated paper must have a valid MongoDB _id");
  assert.strictEqual(genJson.data.subject, "Data Structures and Algorithms");
  assert.strictEqual(genJson.data.semester, 3);
  assert.ok(Array.isArray(genJson.data.sections), "Generated paper must have sections array in schema");
  assert.ok(genJson.data.sections.length > 0, "Sections array must not be empty");
  console.log(`✓ 2. AI Question paper generated and saved to MongoDB with _id: ${genJson.data._id}`);

  const paperId = genJson.data._id;

  // 3. Test Paper Persistence via GET /api/papers and GET /api/papers/history
  console.log("\nTesting GET /api/papers and /api/papers/history...");
  const historyRes = await fetch(`${API_BASE}/api/papers/history`);
  const historyJson = await historyRes.json();
  assert.strictEqual(historyJson.success, true);
  const foundPaper = historyJson.data.find(p => p._id === paperId);
  assert.ok(foundPaper, "Newly generated paper must be present in history retrieved from MongoDB");
  assert.strictEqual(foundPaper.subject, "Data Structures and Algorithms");
  assert.strictEqual(foundPaper.totalMarks, 75);
  console.log(`✓ 3. Verified generated paper persisted in MongoDB history list (${historyJson.count} total papers)`);

  // 4. Test GET /api/papers/:id
  console.log("\nTesting GET /api/papers/:id...");
  const getByIdRes = await fetch(`${API_BASE}/api/papers/${paperId}`);
  const getByIdJson = await getByIdRes.json();
  assert.strictEqual(getByIdJson.success, true);
  assert.strictEqual(getByIdJson.data._id, paperId);
  assert.ok(getByIdJson.data.sections.length > 0);
  console.log(`✓ 4. Retrieved paper by ID with ${getByIdJson.data.sections.length} sections and ${getByIdJson.data.totalMarks} total marks`);

  // 5. Test PDF Generation from MongoDB Document
  console.log("\nTesting GET /api/papers/:id/pdf...");
  const pdfRes = await fetch(`${API_BASE}/api/papers/${paperId}/pdf`);
  assert.strictEqual(pdfRes.status, 200, "PDF endpoint should return 200 OK");
  assert.strictEqual(pdfRes.headers.get("content-type"), "application/pdf", "Should return PDF content-type");
  const pdfBuffer = await pdfRes.arrayBuffer();
  assert.ok(pdfBuffer.byteLength > 1000, "PDF should contain valid binary stream");
  console.log(`✓ 5. University examination PDF successfully generated from MongoDB paper (${pdfBuffer.byteLength} bytes)`);

  // 6. Test PUT /api/papers/:id (Editing paper in MongoDB)
  console.log("\nTesting PUT /api/papers/:id...");
  const updateRes = await fetch(`${API_BASE}/api/papers/${paperId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      examType: "End Semester Autonomous Examination",
      difficulty: "Hard"
    })
  });
  const updateJson = await updateRes.json();
  assert.strictEqual(updateJson.success, true);
  assert.strictEqual(updateJson.data.examType, "End Semester Autonomous Examination");
  assert.strictEqual(updateJson.data.difficulty, "Hard");
  console.log(`✓ 6. Paper successfully updated in MongoDB with new examType: "${updateJson.data.examType}"`);

  // 7. Test Direct POST /api/papers
  console.log("\nTesting direct manual save via POST /api/papers...");
  const directSaveRes = await fetch(`${API_BASE}/api/papers`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      semester: 4,
      subject: "Operating Systems",
      examType: "Continuous Internal Assessment",
      duration: "2 Hours",
      totalMarks: 30,
      difficulty: "Medium",
      selectedUnits: ["1", "2"],
      sections: [
        {
          sectionTitle: "SECTION A",
          instructions: "Answer all questions",
          totalQuestions: 5,
          marksPerQuestion: 2,
          questions: [
            {
              questionText: "What is an Operating System?",
              marks: 2,
              difficulty: "Easy",
              unit: "1"
            }
          ]
        }
      ]
    })
  });
  const directSaveJson = await directSaveRes.json();
  assert.strictEqual(directSaveJson.success, true);
  assert.ok(directSaveJson.data._id);
  console.log(`✓ 7. Manual paper save created document with _id: ${directSaveJson.data._id}`);

  // 8. Test DELETE /api/papers/:id
  console.log("\nTesting DELETE /api/papers/:id...");
  const delRes = await fetch(`${API_BASE}/api/papers/${directSaveJson.data._id}`, {
    method: "DELETE"
  });
  const delJson = await delRes.json();
  assert.strictEqual(delJson.success, true);
  console.log(`✓ 8. Deleted paper successfully from MongoDB`);

  // 9. Check Auth Stats Total Papers
  console.log("\nTesting /api/auth/stats totalPapers count...");
  const statsRes = await fetch(`${API_BASE}/api/auth/stats`);
  const statsJson = await statsRes.json();
  assert.strictEqual(statsJson.success, true);
  assert.ok(statsJson.stats.totalPapers >= 1, "Stats totalPapers should reflect papers in MongoDB");
  console.log(`✓ 9. Faculty stats successfully reports totalPapers: ${statsJson.stats.totalPapers}`);

  console.log("\n=================================================");
  console.log("ALL TESTS PASSED! MONGO PAPER HISTORY FULLY OPERATIONAL");
  console.log("=================================================");
}

runTests().catch(err => {
  console.error("Test failure:", err);
  process.exit(1);
});
