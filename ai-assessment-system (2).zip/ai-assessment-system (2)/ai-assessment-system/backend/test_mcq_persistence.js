const http = require("http");

function request(options, body = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve({ status: res.statusCode, headers: res.headers, data: JSON.parse(data) });
        } catch (e) {
          resolve({ status: res.statusCode, headers: res.headers, data });
        }
      });
    });
    req.on("error", reject);
    if (body) {
      req.write(typeof body === "string" ? body : JSON.stringify(body));
    }
    req.end();
  });
}

async function runTests() {
  console.log("=== MCQ PERSISTENCE & ANALYTICS TEST SUITE ===\n");

  // 1. Student Login
  console.log("1. Logging in as student (username: student, pass: student123)...");
  const loginRes = await request({
    hostname: "localhost",
    port: 5000,
    path: "/api/auth/login",
    method: "POST",
    headers: { "Content-Type": "application/json" }
  }, {
    username: "student",
    password: "student123",
    role: "Student"
  });

  if (loginRes.status !== 200 || !loginRes.data.token) {
    console.error("Login failed:", loginRes);
    process.exit(1);
  }
  const token = loginRes.data.token;
  const user = loginRes.data.user;
  console.log(`✓ Logged in successfully as: ${user.name} (${user.email}), ID: ${user._id}\n`);

  // 2. Fetch Questions
  console.log("2. Fetching questions for Semester 1, Subject: Python Programming...");
  const questionsRes = await request({
    hostname: "localhost",
    port: 5000,
    path: "/api/tests/questions?semester=1&subject=Python+Programming&count=3",
    method: "GET"
  });

  const questions = questionsRes.data.data;
  console.log(`✓ Fetched ${questions.length} questions for testing.\n`);

  // 3. Submit Test with mixed answers (1 correct, 1 wrong, 1 unanswered)
  console.log("3. Submitting MCQ test with mixed responses (1 correct, 1 wrong, 1 unanswered)...");
  const q1 = questions[0];
  const q2 = questions[1];
  const q3 = questions[2];

  const answersPayload = [
    {
      questionId: q1._id,
      questionText: q1.question,
      options: q1.options,
      studentAnswer: q1.options[0] // Might be correct or wrong
    },
    {
      questionId: q2._id,
      questionText: q2.question,
      options: q2.options,
      studentAnswer: "Definitely Wrong Answer 12345"
    },
    {
      questionId: q3._id,
      questionText: q3.question,
      options: q3.options,
      studentAnswer: "Unanswered"
    }
  ];

  const submitPayload = {
    studentId: String(user._id),
    studentName: user.name,
    studentEmail: user.email,
    semester: 1,
    subject: "Python Programming",
    unit: "Unit 1",
    difficulty: "Medium",
    timeTaken: "03:45",
    answers: answersPayload
  };

  const submitRes = await request({
    hostname: "localhost",
    port: 5000,
    path: "/api/tests/submit",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    }
  }, submitPayload);

  console.log("Submit Response Status:", submitRes.status);
  const result = submitRes.data.data;

  // Schema validations
  console.log("\n4. Validating MongoDB document structure against required schema:");
  const checks = [
    ["studentId is string and matches", typeof result.studentId === "string" && result.studentId === String(user._id)],
    ["studentName is string and matches", typeof result.studentName === "string" && result.studentName === user.name],
    ["studentEmail is string and matches", typeof result.studentEmail === "string" && result.studentEmail === user.email],
    ["semester is number and matches", typeof result.semester === "number" && result.semester === 1],
    ["subject is string and matches", typeof result.subject === "string" && result.subject === "Python Programming"],
    ["unit is string and matches", typeof result.unit === "string" && result.unit === "Unit 1"],
    ["difficulty is string and matches", typeof result.difficulty === "string" && result.difficulty === "Medium"],
    ["totalQuestions is number (3)", typeof result.totalQuestions === "number" && result.totalQuestions === 3],
    ["attemptedQuestions is number (2)", typeof result.attemptedQuestions === "number" && result.attemptedQuestions === 2],
    ["correctAnswers is number", typeof result.correctAnswers === "number"],
    ["wrongAnswers is number", typeof result.wrongAnswers === "number"],
    ["score is number", typeof result.score === "number"],
    ["totalMarks is number", typeof result.totalMarks === "number"],
    ["percentage is number", typeof result.percentage === "number"],
    ["timeTaken is string ('03:45')", typeof result.timeTaken === "string" && result.timeTaken === "03:45"],
    ["submittedAt is valid date", !isNaN(new Date(result.submittedAt).getTime())],
    ["questions array length is 3", Array.isArray(result.questions) && result.questions.length === 3]
  ];

  let allPassed = true;
  for (const [desc, passed] of checks) {
    if (passed) {
      console.log(`  ✓ ${desc}`);
    } else {
      console.error(`  ✗ FAIL: ${desc}`);
      allPassed = false;
    }
  }

  // Validate nested question objects
  console.log("\n5. Validating nested question structures:");
  result.questions.forEach((q, idx) => {
    const valid = (
      typeof q.questionText === "string" &&
      Array.isArray(q.options) &&
      typeof q.studentAnswer === "string" &&
      typeof q.correctAnswer === "string" &&
      typeof q.isCorrect === "boolean" &&
      ["Correct", "Wrong", "Unanswered"].includes(q.status)
    );
    if (valid) {
      console.log(`  ✓ Question ${idx + 1}: status="${q.status}", isCorrect=${q.isCorrect}, studentAnswer="${q.studentAnswer}"`);
    } else {
      console.error(`  ✗ FAIL: Question ${idx + 1} structure invalid:`, q);
      allPassed = false;
    }
  });

  // 6. Test Persistence and Retrieval via GET /api/tests/student/:studentId
  console.log("\n6. Testing retrieval via GET /api/tests/student/:studentId...");
  const fetchRes = await request({
    hostname: "localhost",
    port: 5000,
    path: `/api/tests/student/${user._id}`,
    method: "GET",
    headers: { "Authorization": `Bearer ${token}` }
  });

  console.log(`Fetch Status: ${fetchRes.status}, Count: ${fetchRes.data.count}`);
  const found = fetchRes.data.data.find(d => String(d._id) === String(result._id));
  if (found) {
    console.log(`✓ Test record successfully retrieved from MongoDB by studentId!`);
    console.log(`  Document ID: ${found._id}, Score: ${found.score}/${found.totalMarks}, Percentage: ${found.percentage}%, Time: ${found.timeTaken}`);
  } else {
    console.error(`✗ FAIL: Submitted test ID ${result._id} not found in retrieved results:`, fetchRes.data.data);
    allPassed = false;
  }

  // 7. Submit a second test to verify multiple test persistence (history)
  console.log("\n7. Submitting second test (Data Structures) to verify multiple document persistence...");
  const submitRes2 = await request({
    hostname: "localhost",
    port: 5000,
    path: "/api/tests/submit",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    }
  }, {
    studentId: String(user._id),
    studentName: user.name,
    studentEmail: user.email,
    semester: 2,
    subject: "Data Structures",
    unit: "Unit 2",
    difficulty: "Hard",
    timeTaken: "07:12",
    answers: answersPayload
  });

  const result2 = submitRes2.data.data;
  console.log(`✓ Second test submitted, ID: ${result2._id}`);

  // Fetch updated history
  const fetchRes2 = await request({
    hostname: "localhost",
    port: 5000,
    path: `/api/tests/student/${user._id}`,
    method: "GET",
    headers: { "Authorization": `Bearer ${token}` }
  });

  console.log(`✓ Total persistent attempts in MongoDB: ${fetchRes2.data.count}`);
  if (fetchRes2.data.count >= 2) {
    console.log(`✓ All attempts properly persisted across submissions!`);
  } else {
    console.error(`✗ FAIL: Expected at least 2 attempts, got ${fetchRes2.data.count}`);
    allPassed = false;
  }

  // 8. Test Scorecard PDF endpoint
  console.log("\n8. Testing Scorecard PDF generation endpoint GET /api/tests/results/:id/pdf...");
  const pdfRes = await request({
    hostname: "localhost",
    port: 5000,
    path: `/api/tests/results/${result._id}/pdf`,
    method: "GET"
  });

  console.log(`PDF Status: ${pdfRes.status}, Content-Type: ${pdfRes.headers["content-type"]}`);
  if (pdfRes.status === 200 && pdfRes.headers["content-type"] === "application/pdf") {
    console.log("✓ Scorecard PDF generated and streamed successfully!");
  } else {
    console.error("✗ FAIL: PDF generation failed:", pdfRes.status, pdfRes.headers);
    allPassed = false;
  }

  console.log("\n==============================================");
  if (allPassed) {
    console.log("ALL MCQ PERSISTENCE & ANALYTICS TESTS PASSED! ✓");
  } else {
    console.log("SOME CHECKS FAILED. See logs above. ✗");
    process.exit(1);
  }
}

runTests().catch(err => {
  console.error("Unhandled error:", err);
  process.exit(1);
});
