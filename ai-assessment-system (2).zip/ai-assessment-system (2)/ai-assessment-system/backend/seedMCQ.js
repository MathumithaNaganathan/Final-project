module.exports = require('./seed/seedMCQ');
