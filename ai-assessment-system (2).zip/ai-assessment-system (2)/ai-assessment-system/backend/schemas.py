from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional, Any, Dict
from datetime import datetime

# ----------------- AUTH & USER SCHEMAS -----------------
class UserRegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(..., min_length=6)
    role: str = Field(default="FACULTY", pattern="^(FACULTY|STUDENT|ADMIN)$")
    department: Optional[str] = "Computer Science"

class UserLoginRequest(BaseModel):
    email: EmailStr
    password: str

class UserProfileResponse(BaseModel):
    id: str
    name: str
    email: str
    role: str
    department: Optional[str]
    profile_bio: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

class UserProfileUpdate(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    profile_bio: Optional[str] = None
    password: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserProfileResponse

# ----------------- SYLLABUS SCHEMAS -----------------
class TopicBase(BaseModel):
    topic_name: str
    learning_objectives: Optional[str] = None
    bloom_taxonomy_level: Optional[str] = "Understand"
    weightage_percentage: Optional[int] = 10

class TopicCreate(TopicBase):
    pass

class TopicResponse(TopicBase):
    id: str
    unit_id: str
    created_at: datetime

    class Config:
        from_attributes = True

class SyllabusUnitCreate(BaseModel):
    subject_code: str
    subject_name: str
    unit_number: int
    unit_title: str
    description: Optional[str] = None
    topics: Optional[List[TopicCreate]] = []

class SyllabusUnitUpdate(BaseModel):
    subject_code: Optional[str] = None
    subject_name: Optional[str] = None
    unit_number: Optional[int] = None
    unit_title: Optional[str] = None
    description: Optional[str] = None

class SyllabusUnitResponse(BaseModel):
    id: str
    faculty_id: str
    subject_code: str
    subject_name: str
    unit_number: int
    unit_title: str
    description: Optional[str]
    topics: List[TopicResponse] = []
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# ----------------- QUESTION & PAPER SCHEMAS -----------------
class OptionItem(BaseModel):
    id: str # "A", "B", "C", "D"
    text: str

class QuestionBase(BaseModel):
    question_type: str = "MCQ" # MCQ, SHORT_ANSWER, LONG_ANSWER, NUMERICAL, CASE_STUDY
    question_text: str
    options: Optional[List[OptionItem]] = None
    correct_answer: Optional[str] = None
    explanation: Optional[str] = None
    marks: int = 1
    bloom_level: Optional[str] = "Understand"
    topic_id: Optional[str] = None

class QuestionCreate(QuestionBase):
    question_order: Optional[int] = 1

class QuestionUpdate(BaseModel):
    question_order: Optional[int] = None
    question_type: Optional[str] = None
    question_text: Optional[str] = None
    options: Optional[List[OptionItem]] = None
    correct_answer: Optional[str] = None
    explanation: Optional[str] = None
    marks: Optional[int] = None
    bloom_level: Optional[str] = None
    topic_id: Optional[str] = None

class QuestionResponse(BaseModel):
    id: str
    paper_id: str
    topic_id: Optional[str]
    question_order: int
    question_type: str
    question_text: str
    options: Optional[List[OptionItem]] = None
    correct_answer: Optional[str]
    explanation: Optional[str]
    marks: int
    bloom_level: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

class QuestionPaperCreate(BaseModel):
    subject_code: str
    subject_name: str
    title: str
    paper_set: str = "A"
    exam_duration_mins: int = 60
    total_marks: int = 100
    difficulty_level: str = "Medium"
    instructions: Optional[str] = "Answer all questions. Each MCQ has only 1 correct answer."
    is_published: bool = False

class QuestionPaperUpdate(BaseModel):
    title: Optional[str] = None
    paper_set: Optional[str] = None
    exam_duration_mins: Optional[int] = None
    total_marks: Optional[int] = None
    difficulty_level: Optional[str] = None
    instructions: Optional[str] = None
    is_published: Optional[bool] = None

class QuestionPaperResponse(BaseModel):
    id: str
    faculty_id: str
    subject_code: str
    subject_name: str
    title: str
    paper_set: str
    exam_duration_mins: int
    total_marks: int
    difficulty_level: str
    instructions: Optional[str]
    is_published: bool
    ai_prompt_meta: Optional[str]
    created_at: datetime
    updated_at: datetime
    questions: List[QuestionResponse] = []

    class Config:
        from_attributes = True

# ----------------- AI GENERATION SCHEMAS -----------------
class AIPaperGenerateRequest(BaseModel):
    subject_code: str
    subject_name: str
    title: str
    unit_ids: List[str]
    num_mcq: int = 5
    num_short: int = 3
    num_long: int = 2
    difficulty_level: str = "Medium" # Easy, Medium, Hard, Balanced
    exam_duration_mins: int = 60
    custom_instructions: Optional[str] = None
    paper_set: str = "A"

class AIShuffleRequest(BaseModel):
    source_paper_id: str
    new_set_name: str = "Set B" # 'Set B', 'Set C'
    shuffle_options: bool = True # randomize ABCD options
    shuffle_question_order: bool = True # randomize order of questions

# AI Structured Output models
class AIQuestionItem(BaseModel):
    topic_name: Optional[str] = None
    question_type: str # MCQ, SHORT_ANSWER, LONG_ANSWER
    question_text: str
    options: Optional[List[Dict[str, str]]] = None # [{"id": "A", "text": "..."}]
    correct_answer: str # "A" or model answer text
    explanation: str
    marks: int
    bloom_level: str # Remember, Understand, Apply, Analyze, Evaluate

class AIPaperGenerationOutput(BaseModel):
    paper_title: str
    subject_code: str
    subject_name: str
    instructions: str
    total_marks: int
    questions: List[AIQuestionItem]

# ----------------- STUDY MATERIAL SCHEMAS -----------------
class StudyMaterialCreate(BaseModel):
    unit_id: Optional[str] = None
    title: str
    material_type: str = "PDF_NOTE" # PDF_NOTE, REFERENCE_LINK, SLIDES, SAMPLE_PAPER
    file_url: str
    description: Optional[str] = None
    tags: Optional[str] = None

class StudyMaterialResponse(BaseModel):
    id: str
    faculty_id: str
    unit_id: Optional[str]
    title: str
    material_type: str
    file_url: str
    description: Optional[str]
    tags: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

# ----------------- TEST ATTEMPT & SUBMISSION SCHEMAS -----------------
class StudentAnswerSubmission(BaseModel):
    question_id: str
    selected_option: Optional[str] = None # e.g. "A"
    text_response: Optional[str] = None

class TestSubmitRequest(BaseModel):
    paper_id: str
    time_taken_seconds: int
    answers: List[StudentAnswerSubmission]

class StudentAnswerResponse(BaseModel):
    id: str
    question_id: str
    question_text: Optional[str] = None
    selected_option: Optional[str]
    text_response: Optional[str]
    correct_answer: Optional[str] = None
    explanation: Optional[str] = None
    is_correct: bool
    awarded_marks: float
    faculty_or_ai_feedback: Optional[str]

    class Config:
        from_attributes = True

class TestAttemptResponse(BaseModel):
    id: str
    student_id: str
    paper_id: str
    paper_title: Optional[str] = None
    subject_code: Optional[str] = None
    subject_name: Optional[str] = None
    start_time: datetime
    submission_time: Optional[datetime]
    status: str
    total_score: float
    max_possible_score: float
    percentage: float
    time_taken_seconds: int
    created_at: datetime
    answers: List[StudentAnswerResponse] = []

    class Config:
        from_attributes = True

# ----------------- PERFORMANCE & ANALYTICS SCHEMAS -----------------
class TopicMasteryItem(BaseModel):
    topic_name: str
    total_questions: int
    correct_questions: int
    mastery_percentage: float
    status: str # "Mastered", "Needs Revision", "Critical"

class StudentAnalyticsResponse(BaseModel):
    student_id: str
    student_name: str
    total_tests_taken: int
    average_score_percentage: float
    highest_score_percentage: float
    total_time_spent_mins: float
    topic_strengths: List[TopicMasteryItem]
    topic_weaknesses: List[TopicMasteryItem]
    recent_attempts: List[TestAttemptResponse]
