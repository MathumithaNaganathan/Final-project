const mongoose = require("mongoose");

const COURSE_CODE_MAP = {
  // Semester 1
  "Programming in C": "UCS23CT11",
  "Programming in C Lab": "UCS23CP11",
  "Discrete Mathematics": "UCS23AT11",
  "Digital Principles and Computer Organisation": "UCS23CT12",
  // Semester 2
  "Java Programming": "UCS23CT21",
  "Java Programming Lab": "UCS23CP21",
  "Basic Statistics": "UCS23AT21",
  "Web Technology Lab": "UCS23CP22",
  // Semester 3
  "Data Structures and Algorithms": "UCS23CT31",
  "Data Structures and Algorithm Lab": "UCS23CP31",
  "RDBMS / DBMS": "UCS23CT32",
  "RDBMS Lab / DBMS Lab": "UCS23CP32",
  "Computational Methods": "UCS23AT31",
  // Semester 4
  "Advanced Java Programming": "UCS23CT41",
  "Advanced Java Programming Lab": "UCS23CP41",
  "Computer Networks": "UCS23CT42",
  "PHP Programming Lab": "UCS23CP42",
  "Operations Research": "UCS23AT41",
  // Semester 5
  "Advanced Computer Networks": "UCS23CT51",
  "Advanced Computer Networks Lab": "UCS23CP51",
  "Cloud Computing": "UCS23CT52",
  "Cloud Computing Lab": "UCS23CP52",
  "Linear Algebra": "UCS23AT51",
  // Semester 6
  "AI & Machine Learning": "UCS23CT61",
  "AI & ML Lab": "UCS23CP61",
  "Data Analytics with Python": "UCS23CT62",
  "Data Analytics with Python Lab": "UCS23CP62",
  "Operating Systems": "UCS23CT63",
  "Data Mining and Warehousing": "UCS23CT64",
  "Open Source Technology Lab": "UCS23CP63"
};

const unitSchema = new mongoose.Schema({
  unitNumber: { type: Number, required: true },
  unitTitle: { type: String, required: true },
  topics: [{ type: String }]
}, { _id: false });

const syllabusSchema = new mongoose.Schema({
  department: { type: String, default: "Department of Computer Science" },
  semester: { type: Number, required: true, min: 1, max: 6 },
  subject: { type: String, required: true, trim: true },
  courseCode: {
    type: String,
    trim: true,
    default: function() {
      return COURSE_CODE_MAP[this.subject] || `UCS23CT${this.semester || 1}0`;
    }
  },
  subjectType: { type: String, enum: ["Theory", "Lab"], default: "Theory" },
  units: [unitSchema],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Syllabus", syllabusSchema);
module.exports.COURSE_CODE_MAP = COURSE_CODE_MAP;
