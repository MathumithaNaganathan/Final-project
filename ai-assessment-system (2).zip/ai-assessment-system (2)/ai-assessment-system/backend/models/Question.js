const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
  semester: { type: Number, required: true, min: 1, max: 6 },
  subject: { type: String, required: true, trim: true },
  unit: { type: Number, required: true, min: 1, max: 5 },
  topic: { type: String, trim: true, default: "Core Concept" },
  question: { type: String, required: true, trim: true },
  options: [{ type: String }],
  correctAnswer: { type: String, trim: true, default: "" },
  marks: { type: Number, required: true, default: 2 },
  difficulty: { type: String, enum: ["Easy", "Medium", "Hard"], default: "Medium" },
  answer: { type: String, trim: true, default: "" },
  questionType: { type: String, enum: ["Theory", "MCQ"], default: "Theory" },
  createdAt: { type: Date, default: Date.now }
});

questionSchema.index({ semester: 1, subject: 1, unit: 1, marks: 1, questionType: 1 });

module.exports = mongoose.model("Question", questionSchema);
