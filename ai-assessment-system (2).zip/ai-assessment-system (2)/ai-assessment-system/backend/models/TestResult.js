const mongoose = require("mongoose");

const testQuestionResultSchema = new mongoose.Schema({
  questionId: { type: String },
  questionText: { type: String, required: true },
  question: { type: String }, // Backwards compatibility alias
  options: [{ type: String }],
  studentAnswer: { type: String, default: "" },
  correctAnswer: { type: String, default: "" },
  isCorrect: { type: Boolean, default: false },
  status: { type: String, enum: ["Correct", "Wrong", "Unanswered"], default: "Unanswered" },
  marks: { type: Number, default: 1 },
  explanation: { type: String, default: "" }
}, { _id: false });

const testResultSchema = new mongoose.Schema({
  studentId: { type: String, required: true },
  studentName: { type: String, required: true },
  studentEmail: { type: String, required: true },
  semester: { type: Number, required: true },
  subject: { type: String, required: true },
  unit: { type: String, required: true },
  difficulty: { type: String, default: "Medium" },
  totalQuestions: { type: Number, required: true },
  attemptedQuestions: { type: Number, required: true },
  correctAnswers: { type: Number, required: true },
  wrongAnswers: { type: Number, required: true },
  score: { type: Number, required: true },
  totalMarks: { type: Number, required: true },
  percentage: { type: Number, required: true },
  timeTaken: { type: String, default: "00:00" },
  questions: [testQuestionResultSchema],
  submittedAt: { type: Date, default: Date.now },

  // Compatibility fields for legacy references and PDF generation
  obtainedMarks: { type: Number },
  correctCount: { type: Number },
  wrongCount: { type: Number },
  unansweredCount: { type: Number },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("TestResult", testResultSchema);

