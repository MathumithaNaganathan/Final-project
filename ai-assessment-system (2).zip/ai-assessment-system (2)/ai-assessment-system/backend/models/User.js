const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  username: { type: String, lowercase: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["Faculty", "Student"], default: "Student" },
  department: { type: String, default: "B.Sc Computer Science" },
  semester: { type: Number, min: 1, max: 6, default: 1 },
  phone: { type: String, default: "" },
  dob: { type: String, default: "" },
  gender: { type: String, default: "" },
  address: { type: String, default: "" },
  profilePhoto: { type: String, default: "" },
  designation: { type: String, default: "" },
  qualification: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now }
});

userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model("User", userSchema);
