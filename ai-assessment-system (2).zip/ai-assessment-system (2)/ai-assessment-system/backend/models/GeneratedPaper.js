const mongoose = require('mongoose');

const generatedPaperSchema = new mongoose.Schema({
  faculty: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false
  },
  semester: { type: Number, required: true },
  subject: { type: String, required: true },
  examType: { type: String, required: true },
  duration: { type: String, default: '3 Hours' },
  totalMarks: { type: Number, required: true },
  difficulty: { type: String, default: 'Medium' },
  selectedUnits: [{ type: String }],
  generatedDate: { 
    type: String, 
    default: () => new Date().toISOString().split('T')[0] 
  },
  sections: [
    {
      sectionTitle: { type: String, required: true }, // SECTION A, SECTION B, SECTION C
      instructions: String,
      totalQuestions: Number,
      marksPerQuestion: Number,
      questions: [
        {
          questionText: { type: String, required: true },
          options: [String],
          correctAnswer: String,
          marks: Number,
          difficulty: String,
          unit: String,
          isOrPair: { type: Boolean, default: false },
          orQuestion: {
            questionText: String,
            options: [String],
            correctAnswer: String,
            unit: String
          }
        }
      ]
    }
  ]
}, { 
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for title (e.g., "ADVANCED JAVA PROGRAMMING - Summative Examination")
generatedPaperSchema.virtual('title').get(function () {
  return `${this.subject} - ${this.examType}`;
});

// Virtual for parts to provide 100% seamless backward compatibility with parts-based UI & PDF rendering
generatedPaperSchema.virtual('parts').get(function () {
  if (!this.sections) return [];
  return this.sections.map((sec, idx) => {
    const partLetter = String.fromCharCode(65 + idx);
    return {
      part: partLetter,
      name: sec.sectionTitle || `SECTION ${partLetter}`,
      instructions: sec.instructions || 'Answer ALL questions:',
      marksPerQuestion: sec.marksPerQuestion,
      count: sec.totalQuestions,
      questions: (sec.questions || []).map(q => ({
        question: q.questionText,
        questionText: q.questionText,
        options: q.options || [],
        correctAnswer: q.correctAnswer || '',
        marks: q.marks,
        difficulty: q.difficulty || 'Medium',
        unit: q.unit || '1',
        questionType: (q.options && q.options.length >= 2) ? 'MCQ' : 'Theory',
        isOrPair: q.isOrPair || false,
        orQuestion: q.orQuestion ? (q.orQuestion.questionText || '') : '',
        orTopic: q.orQuestion ? (q.orQuestion.unit ? `Unit ${q.orQuestion.unit}` : '') : '',
        orUnit: q.orQuestion && q.orQuestion.unit ? Number(q.orQuestion.unit) : undefined
      }))
    };
  });
});

module.exports = mongoose.model('GeneratedPaper', generatedPaperSchema);
