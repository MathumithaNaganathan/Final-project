﻿const mongoose = require("mongoose");

const studyMaterialSchema = new mongoose.Schema({
  semester: { type: Number, required: true, min: 1, max: 6 },
  subject: { type: String, required: true, trim: true },
  unit: { type: Number, required: true, min: 1, max: 5 },
  topic: { type: String, required: true, trim: true },
  title: { type: String, required: true, trim: true },
  content: { type: String, required: true },
  author: { type: String, default: "CS Department Faculty" },
  createdAt: { type: Date, default: Date.now }
});

studyMaterialSchema.index({ semester: 1, subject: 1, unit: 1 });

module.exports = mongoose.model("StudyMaterial", studyMaterialSchema);
