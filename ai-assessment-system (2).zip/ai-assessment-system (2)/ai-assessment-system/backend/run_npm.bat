@echo off
"C:\Program Files\nodejs\npm.cmd" install --save express mongoose dotenv cors morgan bcryptjs jsonwebtoken pdfkit
