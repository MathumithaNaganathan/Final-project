const mongoose = require("mongoose");
const Question = require("../models/Question");
const TestResult = require("../models/TestResult");
const { createMCQQuestionsOnlyPDF, createTestResultPDF } = require("../services/pdfService");
const Syllabus = require("../models/Syllabus");

// Helper to generate dynamic MCQs if none in database for that subject/unit
async function generateDynamicMCQs(semester, subject, unit, count) {
  const semMatch = String(semester).match(/\d+/);
  const semNum = semMatch ? Number(semMatch[0]) : (Number(semester) || 1);
  const escapedSub = String(subject || "").trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const syllabus = await Syllabus.findOne({
    semester: semNum,
    subject: { $regex: new RegExp(`^${escapedSub}$`, "i") }
  });
  let topics = ["Core Principles", "Architecture", "Operations", "Implementation", "Applications"];
  if (syllabus && syllabus.units) {
    const targetUnit = syllabus.units.find(u => u.unitNumber === Number(unit)) || syllabus.units[0];
    if (targetUnit && targetUnit.topics && targetUnit.topics.length > 0) {
      topics = targetUnit.topics;
    }
  }

  const generated = [];
  const needed = Number(count) || 10;
  for (let i = 0; i < needed; i++) {
    const topic = topics[i % topics.length];
    const mcqStems = [
      {
        q: `What is the primary operational role of ${topic} in ${subject}?`,
        opts: [
          `Optimizing execution performance and resource usage`,
          `Secondary auxiliary data processing`,
          `Hardware peripheral driver emulation`,
          `Legacy backward compatibility protocol`
        ],
        ans: `Optimizing execution performance and resource usage`,
        exp: `${topic} serves a central function in ${subject} to guarantee efficient resource utilization and architectural stability.`
      },
      {
        q: `Which characteristic uniquely distinguishes ${topic} within ${subject}?`,
        opts: [
          `Deterministic throughput and strict algorithmic bounds`,
          `Uncontrolled asynchronous interrupt handling`,
          `Volatile intermediate storage buffer loss`,
          `External dependency requirement`
        ],
        ans: `Deterministic throughput and strict algorithmic bounds`,
        exp: `${topic} enforces formal mathematical and operational invariants within the ${subject} curriculum.`
      },
      {
        q: `In the context of ${subject}, when is ${topic} typically utilized?`,
        opts: [
          `During systematic design and execution workflows`,
          `Only during system termination sequence`,
          `Strictly for legacy 16-bit emulation`,
          `Exclusively in offline batch compilation`
        ],
        ans: `During systematic design and execution workflows`,
        exp: `Academic specifications for ${subject} highlight ${topic} as a standard design and deployment pattern.`
      },
      {
        q: `What is the time complexity or standard protocol associated with ${topic}?`,
        opts: [
          `Logarithmic O(log n) or linear O(n) standard runtime`,
          `Exponential O(2^n) unbounded runtime`,
          `Undefined dynamic oscillation`,
          `Polynomial O(n^5) latency`
        ],
        ans: `Logarithmic O(log n) or linear O(n) standard runtime`,
        exp: `Standard efficient implementation of ${topic} achieves bounded linear or logarithmic computational complexity.`
      }
    ];

    const template = mcqStems[i % mcqStems.length];
    generated.push({
      semester: Number(semester),
      subject,
      unit: Number(unit) || 1,
      topic,
      question: template.q,
      options: template.opts,
      correctAnswer: template.ans,
      answer: template.exp,
      marks: 1,
      difficulty: i % 3 === 0 ? "Easy" : (i % 3 === 1 ? "Medium" : "Hard"),
      questionType: "MCQ"
    });
  }

  // Save to DB in background for future calls
  try {
    await Question.insertMany(generated);
  } catch (err) {
    // Ignore duplicate keys
  }

  return generated;
}

// @desc    Get questions for student MCQ test
// @route   GET /api/tests/questions
const getTestQuestions = async (req, res, next) => {
  try {
    const { semester, subject, unit, count } = req.query;

    const filter = { questionType: "MCQ" };
    let semNum = null;
    if (semester !== undefined && semester !== "") {
      const semMatch = String(semester).match(/\d+/);
      if (semMatch) {
        semNum = Number(semMatch[0]);
        filter.semester = semNum;
      }
    }
    if (subject) {
      const escapedSub = subject.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filter.subject = { $regex: new RegExp(`^${escapedSub}$`, "i") };
    }
    if (unit && Number(unit) !== 0) filter.unit = Number(unit);

    let questions = await Question.find(filter);

    if (questions.length === 0) {
      // Fallback 1: Fetch across the subject
      delete filter.unit;
      questions = await Question.find(filter);
    }

    if (questions.length === 0 && subject) {
      // Fallback 2: Generate dynamic MCQs so student is never blocked
      questions = await generateDynamicMCQs(semester || 1, subject, unit || 1, count || 10);
    }

    // Shuffle questions
    const shuffled = [...questions].sort(() => 0.5 - Math.random());
    const limit = count === "all" ? shuffled.length : (Number(count) || 10);
    const selected = shuffled.slice(0, limit);

    // Return questions with IDs and options, but hide correctAnswer during test delivery
    const clientQuestions = selected.map(q => ({
      _id: q._id,
      question: q.question,
      options: q.options,
      marks: q.marks || 1,
      difficulty: q.difficulty,
      unit: q.unit,
      topic: q.topic
    }));

    res.json({
      success: true,
      count: clientQuestions.length,
      data: clientQuestions
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Submit test and compute result
// @route   POST /api/tests/submit
const submitTest = async (req, res, next) => {
  try {
    const {
      semester,
      subject,
      unit,
      answers,
      difficulty,
      timeTaken,
      studentName: explicitName,
      studentId: explicitStudentId,
      studentEmail: explicitEmail
    } = req.body;

    if (!semester || !subject || !answers || !Array.isArray(answers)) {
      return res.status(400).json({ success: false, message: "Missing test submission data" });
    }

    const studentId = String(req.user ? req.user._id : (explicitStudentId || req.body.studentId || "student_default_id"));
    const studentName = String((req.user && req.user.name) ? req.user.name : (explicitName || "Student Candidate"));
    const studentEmail = String((req.user && req.user.email) ? req.user.email : (explicitEmail || req.body.studentEmail || "student@college.edu"));
    const finalDifficulty = String(difficulty || "Medium");
    const finalTimeTaken = String(timeTaken || "00:00");
    const finalUnit = (unit === 0 || unit === "0" || unit === "All Units") ? "All Units" : String(unit || "1");

    let totalMarks = 0;
    let obtainedMarks = 0;
    let correctCount = 0;
    let wrongCount = 0;
    let unansweredCount = 0;
    let attemptedCount = 0;
    const evaluatedQuestions = [];

    for (const item of answers) {
      let qDoc = null;
      if (item.questionId && String(item.questionId).match(/^[0-9a-fA-F]{24}$/)) {
        qDoc = await Question.findById(item.questionId);
      }

      const qMarks = (qDoc && qDoc.marks) ? qDoc.marks : (Number(item.marks) || 1);
      totalMarks += qMarks;

      const rawAns = item.studentAnswer !== undefined && item.studentAnswer !== null ? String(item.studentAnswer).trim() : "";
      const isUnanswered = !rawAns || rawAns.toLowerCase() === "unanswered";

      // Resolve correct answer from MongoDB Question document or provided item fallbacks
      let trueCorrect = "";
      if (qDoc) {
        trueCorrect = (qDoc.correctAnswer || qDoc.answer || "").trim();
      }
      if (!trueCorrect && item.correctAnswer) {
        trueCorrect = String(item.correctAnswer).trim();
      }
      if (!trueCorrect && item.answer) {
        trueCorrect = String(item.answer).trim();
      }
      if (!trueCorrect && item.options && Array.isArray(item.options) && item.options.length > 0) {
        trueCorrect = String(item.options[0]).trim();
      }

      const qExplanation = (qDoc ? (qDoc.answer || qDoc.explanation || "") : (item.explanation || "")).trim();
      const questionText = qDoc ? qDoc.question : (item.questionText || item.question || "MCQ Item");
      const options = (qDoc && qDoc.options && qDoc.options.length > 0) ? qDoc.options : (item.options || []);

      let status = "Unanswered";
      let isCorrect = false;

      if (isUnanswered) {
        unansweredCount++;
        status = "Unanswered";
        isCorrect = false;
      } else {
        attemptedCount++;
        const isMatch = Boolean(trueCorrect && rawAns.toLowerCase() === trueCorrect.toLowerCase());
        if (isMatch) {
          correctCount++;
          obtainedMarks += qMarks;
          status = "Correct";
          isCorrect = true;
        } else {
          wrongCount++;
          status = "Wrong";
          isCorrect = false;
        }
      }

      evaluatedQuestions.push({
        questionId: String(item.questionId || ""),
        questionText,
        question: questionText,
        options,
        studentAnswer: isUnanswered ? "Unanswered" : rawAns,
        correctAnswer: trueCorrect || "",
        isCorrect,
        status,
        marks: isCorrect ? qMarks : 0,
        explanation: qExplanation
      });
    }

    const percentage = totalMarks > 0 ? Number(((obtainedMarks / totalMarks) * 100).toFixed(2)) : 0;
    const now = new Date();

    const testResult = await TestResult.create({
      studentId,
      studentName,
      studentEmail,
      semester: Number(semester),
      subject: String(subject),
      unit: finalUnit,
      difficulty: finalDifficulty,
      totalQuestions: answers.length,
      attemptedQuestions: attemptedCount,
      correctAnswers: correctCount,
      wrongAnswers: wrongCount,
      score: obtainedMarks,
      totalMarks,
      percentage,
      timeTaken: finalTimeTaken,
      questions: evaluatedQuestions,
      submittedAt: now,

      // Compatibility fields
      obtainedMarks,
      correctCount,
      wrongCount,
      unansweredCount,
      createdAt: now
    });

    res.status(201).json({
      success: true,
      message: "Test submitted and evaluated successfully",
      data: testResult
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get test results for student
// @route   GET /api/results/student/:studentId
const getStudentResults = async (req, res, next) => {
  try {
    const studentIdParam = req.params.studentId;
    let filter = {};

    if (studentIdParam && studentIdParam !== "all" && studentIdParam !== "current") {
      const possibleIds = [String(studentIdParam)];
      if (mongoose.Types.ObjectId.isValid(studentIdParam)) {
        possibleIds.push(new mongoose.Types.ObjectId(studentIdParam));
      }
      filter = {
        $or: [
          { studentId: { $in: possibleIds } },
          { studentEmail: studentIdParam }
        ]
      };
      if (req.user) {
        if (req.user.email) filter.$or.push({ studentEmail: req.user.email });
        if (req.user._id) {
          filter.$or.push({ studentId: String(req.user._id) });
          if (mongoose.Types.ObjectId.isValid(req.user._id)) {
            filter.$or.push({ studentId: new mongoose.Types.ObjectId(req.user._id) });
          }
        }
      }
    } else if (req.user) {
      const possibleIds = [String(req.user._id)];
      if (mongoose.Types.ObjectId.isValid(req.user._id)) {
        possibleIds.push(new mongoose.Types.ObjectId(req.user._id));
      }
      filter = {
        $or: [
          { studentId: { $in: possibleIds } },
          { studentEmail: req.user.email }
        ]
      };
    }

    const results = await TestResult.find(filter).sort({ submittedAt: -1, createdAt: -1 });
    res.json({ success: true, count: results.length, data: results });
  } catch (error) {
    next(error);
  }
};

// @desc    Get result by ID
// @route   GET /api/results/:id
const getResultById = async (req, res, next) => {
  try {
    const result = await TestResult.findById(req.params.id);
    if (!result) {
      return res.status(404).json({ success: false, message: "Test result record not found" });
    }
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
};

// @desc    Export Questions Only PDF (Before / During Test)
// @route   POST /api/tests/export-questions-pdf
const exportTestQuestionsPDF = async (req, res, next) => {
  try {
    const { semester, subject, unit, courseCode, questions } = req.body;
    if (!questions || !Array.isArray(questions)) {
      return res.status(400).json({ success: false, message: "Missing questions list for PDF export" });
    }

    const safeTitle = (subject || "Assessment").replace(/[^a-zA-Z0-9_-]/g, "_");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${safeTitle}_Questions_Only.pdf"`);

    await createMCQQuestionsOnlyPDF({
      semester: Number(semester),
      subject,
      unit,
      courseCode,
      questions
    }, res);
  } catch (error) {
    next(error);
  }
};

// @desc    Export Test Result PDF (After Test Submission)
// @route   POST /api/tests/export-result-pdf
const exportTestResultPDF = async (req, res, next) => {
  try {
    const resultData = req.body;
    if (!resultData || !resultData.questions) {
      return res.status(400).json({ success: false, message: "Missing result data for PDF export" });
    }

    const safeTitle = (resultData.subject || "Assessment_Result").replace(/[^a-zA-Z0-9_-]/g, "_");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${safeTitle}_Result_Scorecard.pdf"`);

    await createTestResultPDF(resultData, res);
  } catch (error) {
    next(error);
  }
};

// @desc    Download Result PDF by Test ID
// @route   GET /api/tests/results/:id/pdf
const downloadResultPDFById = async (req, res, next) => {
  try {
    const result = await TestResult.findById(req.params.id);
    if (!result) {
      return res.status(404).json({ success: false, message: "Test result record not found" });
    }

    const safeTitle = (result.subject || "Assessment_Result").replace(/[^a-zA-Z0-9_-]/g, "_");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${safeTitle}_Result_Scorecard.pdf"`);

    await createTestResultPDF(result, res);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getTestQuestions,
  submitTest,
  getStudentResults,
  getResultById,
  exportTestQuestionsPDF,
  exportTestResultPDF,
  downloadResultPDFById
};
