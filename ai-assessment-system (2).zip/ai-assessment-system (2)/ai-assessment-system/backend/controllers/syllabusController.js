const Syllabus = require("../models/Syllabus");
const { COURSE_CODE_MAP } = require("../models/Syllabus");
const { SYLLABUS_DATA } = require("../seed/seedSyllabus");

// @desc    Get all syllabus
// @route   GET /api/syllabus
const getAllSyllabus = async (req, res, next) => {
  try {
    let syllabusList = await Syllabus.find().sort({ semester: 1, subject: 1 });

    // Ensure database contains all master syllabus subjects
    if (SYLLABUS_DATA && Array.isArray(SYLLABUS_DATA) && syllabusList.length < SYLLABUS_DATA.length) {
      const existingKeys = new Set(syllabusList.map(s => `${s.semester}_${(s.subject || "").toLowerCase().trim()}`));
      const missing = SYLLABUS_DATA.filter(
        s => !existingKeys.has(`${s.semester}_${(s.subject || "").toLowerCase().trim()}`)
      );
      if (missing.length > 0) {
        try {
          const inserted = await Syllabus.insertMany(missing, { ordered: false });
          syllabusList.push(...inserted);
        } catch (e) {
          syllabusList = await Syllabus.find().sort({ semester: 1, subject: 1 });
        }
      }
    }

    // Deduplicate any repeated entries
    const seen = new Set();
    const unique = [];
    for (const item of syllabusList) {
      const key = `${item.semester}_${(item.subject || "").toLowerCase().trim()}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(item);
      }
    }

    unique.sort((a, b) => a.semester - b.semester || a.subject.localeCompare(b.subject));
    res.json({ success: true, count: unique.length, data: unique });
  } catch (error) {
    next(error);
  }
};

// @desc    Get syllabus by semester
// @route   GET /api/syllabus/:semester
const getSyllabusBySemester = async (req, res, next) => {
  try {
    const rawSem = req.params.semester;
    const semMatch = String(rawSem).match(/\d+/);
    const semester = semMatch ? Number(semMatch[0]) : Number(rawSem);
    if (!semester || semester < 1 || semester > 6) {
      return res.status(400).json({ success: false, message: "Invalid semester number (must be 1-6)" });
    }

    let subjects = await Syllabus.find({ semester }).sort({ subject: 1 });

    // If MongoDB is missing subjects for this semester that exist in master data, insert them
    if (SYLLABUS_DATA && Array.isArray(SYLLABUS_DATA)) {
      const existingNames = new Set(subjects.map(s => (s.subject || "").toLowerCase().trim()));
      const missing = SYLLABUS_DATA.filter(
        s => s.semester === semester && !existingNames.has((s.subject || "").toLowerCase().trim())
      );
      if (missing.length > 0) {
        try {
          const inserted = await Syllabus.insertMany(missing, { ordered: false });
          subjects.push(...inserted);
        } catch (seedErr) {
          subjects = await Syllabus.find({ semester }).sort({ subject: 1 });
        }
      }
    }

    // Deduplicate subjects by name
    const seen = new Set();
    const uniqueSubjects = [];
    for (const item of subjects) {
      const subName = (item.subject || "").trim();
      if (subName && !seen.has(subName.toLowerCase())) {
        seen.add(subName.toLowerCase());
        uniqueSubjects.push(item);
      }
    }

    uniqueSubjects.sort((a, b) => a.subject.localeCompare(b.subject));

    res.json({ success: true, count: uniqueSubjects.length, data: uniqueSubjects });
  } catch (error) {
    next(error);
  }
};

// @desc    Get units for a subject in a semester
// @route   GET /api/syllabus/:semester/:subject
const getSubjectUnits = async (req, res, next) => {
  try {
    const rawSem = req.params.semester;
    const semMatch = String(rawSem).match(/\d+/);
    const semester = semMatch ? Number(semMatch[0]) : Number(rawSem);
    const rawSubject = decodeURIComponent(req.params.subject).trim();
    const escapedSubject = rawSubject.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    let syllabus = await Syllabus.findOne({
      semester,
      subject: { $regex: new RegExp(`^${escapedSubject}$`, "i") }
    });

    if (!syllabus && SYLLABUS_DATA) {
      const fallback = SYLLABUS_DATA.find(
        s => s.semester === semester && s.subject.toLowerCase().trim() === rawSubject.toLowerCase()
      );
      if (fallback) {
        try {
          syllabus = await Syllabus.create(fallback);
        } catch (e) {
          syllabus = await Syllabus.findOne({
            semester,
            subject: { $regex: new RegExp(`^${escapedSubject}$`, "i") }
          });
        }
      }
    }

    if (!syllabus) {
      return res.status(404).json({ success: false, message: `Syllabus not found for ${rawSubject} (Semester ${semester})` });
    }
    res.json({ success: true, data: syllabus });
  } catch (error) {
    next(error);
  }
};

// @desc    Create new subject syllabus
// @route   POST /api/syllabus
const createSyllabus = async (req, res, next) => {
  try {
    const { semester, subject, courseCode, subjectType, units, department } = req.body;
    if (!semester || !subject) {
      return res.status(400).json({ success: false, message: "Semester and subject name are required" });
    }

    const defaultCode = COURSE_CODE_MAP[subject] || `UCS23CT${semester}0`;

    // Ensure 5 units exist if units not provided or incomplete
    let defaultUnits = units;
    if (!defaultUnits || !Array.isArray(defaultUnits) || defaultUnits.length === 0) {
      defaultUnits = [1, 2, 3, 4, 5].map(num => ({
        unitNumber: num,
        unitTitle: `Unit ${num}: Core Topics`,
        topics: [`Fundamental Principles of ${subject}`]
      }));
    }

    const created = await Syllabus.create({
      department: department || "Department of Computer Science",
      semester: Number(semester),
      subject: subject.trim(),
      courseCode: (courseCode || defaultCode).trim(),
      subjectType: subjectType || "Theory",
      units: defaultUnits
    });

    res.status(201).json({ success: true, data: created, message: "Subject syllabus created successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Update entire syllabus record
// @route   PUT /api/syllabus/:id
const updateSyllabus = async (req, res, next) => {
  try {
    const { semester, subject, courseCode, subjectType, units, department } = req.body;
    const syllabus = await Syllabus.findById(req.params.id);
    if (!syllabus) {
      return res.status(404).json({ success: false, message: "Syllabus record not found" });
    }

    if (semester !== undefined) syllabus.semester = Number(semester);
    if (subject) syllabus.subject = subject.trim();
    if (courseCode) syllabus.courseCode = courseCode.trim();
    if (subjectType) syllabus.subjectType = subjectType;
    if (department) syllabus.department = department.trim();
    if (units && Array.isArray(units)) syllabus.units = units;

    const updated = await syllabus.save();
    res.json({ success: true, data: updated, message: "Syllabus updated successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete syllabus
// @route   DELETE /api/syllabus/:id
const deleteSyllabus = async (req, res, next) => {
  try {
    const syllabus = await Syllabus.findById(req.params.id);
    if (!syllabus) {
      return res.status(404).json({ success: false, message: "Syllabus record not found" });
    }
    await Syllabus.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Syllabus record deleted successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Add topic to a unit with instant database sync
// @route   POST /api/syllabus/:id/units/:unitNumber/topics
const addUnitTopic = async (req, res, next) => {
  try {
    const { topic } = req.body;
    const unitNumber = Number(req.params.unitNumber);

    if (!topic || !topic.trim()) {
      return res.status(400).json({ success: false, message: "Topic name cannot be empty" });
    }

    const syllabus = await Syllabus.findById(req.params.id);
    if (!syllabus) {
      return res.status(404).json({ success: false, message: "Syllabus record not found" });
    }

    let unit = syllabus.units.find(u => u.unitNumber === unitNumber);
    if (!unit) {
      // Create unit if not present
      unit = { unitNumber, unitTitle: `Unit ${unitNumber}`, topics: [] };
      syllabus.units.push(unit);
    }

    const cleanTopic = topic.trim();
    if (!unit.topics.includes(cleanTopic)) {
      unit.topics.push(cleanTopic);
    }

    await syllabus.save();
    res.json({
      success: true,
      data: syllabus,
      message: `Topic '${cleanTopic}' added to Unit ${unitNumber} with instant sync`
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update a specific topic in a unit
// @route   PUT /api/syllabus/:id/units/:unitNumber/topics/:topicIndex
const updateUnitTopic = async (req, res, next) => {
  try {
    const { newTopic } = req.body;
    const unitNumber = Number(req.params.unitNumber);
    const topicIndex = Number(req.params.topicIndex);

    if (!newTopic || !newTopic.trim()) {
      return res.status(400).json({ success: false, message: "Topic name cannot be empty" });
    }

    const syllabus = await Syllabus.findById(req.params.id);
    if (!syllabus) {
      return res.status(404).json({ success: false, message: "Syllabus record not found" });
    }

    const unit = syllabus.units.find(u => u.unitNumber === unitNumber);
    if (!unit || !unit.topics || unit.topics[topicIndex] === undefined) {
      return res.status(404).json({ success: false, message: "Specified topic or unit not found" });
    }

    const oldTopic = unit.topics[topicIndex];
    unit.topics[topicIndex] = newTopic.trim();

    await syllabus.save();
    res.json({
      success: true,
      data: syllabus,
      message: `Updated topic from '${oldTopic}' to '${newTopic.trim()}' with instant sync`
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a specific topic from a unit
// @route   DELETE /api/syllabus/:id/units/:unitNumber/topics/:topicIndex
const deleteUnitTopic = async (req, res, next) => {
  try {
    const unitNumber = Number(req.params.unitNumber);
    const topicIndex = Number(req.params.topicIndex);

    const syllabus = await Syllabus.findById(req.params.id);
    if (!syllabus) {
      return res.status(404).json({ success: false, message: "Syllabus record not found" });
    }

    const unit = syllabus.units.find(u => u.unitNumber === unitNumber);
    if (!unit || !unit.topics || unit.topics[topicIndex] === undefined) {
      return res.status(404).json({ success: false, message: "Specified topic or unit not found" });
    }

    const removedTopic = unit.topics.splice(topicIndex, 1)[0];
    await syllabus.save();

    res.json({
      success: true,
      data: syllabus,
      message: `Deleted topic '${removedTopic}' from Unit ${unitNumber} with instant sync`
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update unit title
// @route   PUT /api/syllabus/:id/units/:unitNumber/title
const updateUnitTitle = async (req, res, next) => {
  try {
    const { unitTitle } = req.body;
    const unitNumber = Number(req.params.unitNumber);

    if (!unitTitle || !unitTitle.trim()) {
      return res.status(400).json({ success: false, message: "Unit title cannot be empty" });
    }

    const syllabus = await Syllabus.findById(req.params.id);
    if (!syllabus) {
      return res.status(404).json({ success: false, message: "Syllabus record not found" });
    }

    const unit = syllabus.units.find(u => u.unitNumber === unitNumber);
    if (!unit) {
      return res.status(404).json({ success: false, message: "Unit not found" });
    }

    unit.unitTitle = unitTitle.trim();
    await syllabus.save();

    res.json({
      success: true,
      data: syllabus,
      message: `Updated Unit ${unitNumber} title with instant sync`
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllSyllabus,
  getSyllabusBySemester,
  getSubjectUnits,
  createSyllabus,
  updateSyllabus,
  deleteSyllabus,
  addUnitTopic,
  updateUnitTopic,
  deleteUnitTopic,
  updateUnitTitle
};
