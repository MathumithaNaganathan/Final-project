const StudyMaterial = require("../models/StudyMaterial");
const Syllabus = require("../models/Syllabus");

// Helper function to synthesize academic study material for any syllabus topic
function synthesizeStudyContent(subject, unitNum, topic) {
  return `<h3>1. Executive Overview & Core Concepts</h3>
<p>In <strong>${subject}</strong> (Unit ${unitNum}), <em>${topic}</em> is a fundamental academic concept. It governs core computational mechanisms, architectural patterns, and practical software design paradigms.</p>

<h3>2. Key Definitions</h3>
<ul>
  <li><strong>${topic}:</strong> A foundational construct in ${subject} providing systematic execution guarantees, state management, and algorithmic correctness.</li>
  <li><strong>Specification Standard:</strong> Adheres to standard academic curriculum guidelines for B.Sc Computer Science degree programs.</li>
</ul>

<h3>3. Important Points & Theoretical Principles</h3>
<ul>
  <li><strong>Architectural Role:</strong> Encapsulates modular operations and simplifies complexity through well-defined interfaces.</li>
  <li><strong>Execution Complexity:</strong> Standard operations typically perform within optimized time and space complexity bounds ($O(1)$, $O(\log n)$, or $O(n)$ depending on data scale).</li>
  <li><strong>Error Handling & Boundary Conditions:</strong> Robust implementations must account for edge-case constraints, memory safety, and invalid state transitions.</li>
</ul>

<h3>4. Illustrative Example / Implementation</h3>
<pre style="background: #1e293b; color: #f8fafc; padding: 12px; border-radius: 8px; font-family: monospace; font-size: 13px;"><code>/* Example Demonstration of ${topic} in ${subject} */
// Key procedural / architectural workflow
1. Initialize parameters and environment context.
2. Execute core ${topic} operations with validation.
3. Handle outcomes, release resources, and verify post-conditions.</code></pre>

<h3>5. Reference Notes & Viva Questions</h3>
<p><strong>Key Revision Question:</strong> Explain the architectural lifecycle, working principles, and performance trade-offs of <em>${topic}</em> in modern computing environments.</p>`;
}

// @desc    Get study materials with filters
// @route   GET /api/study-materials
const getStudyMaterials = async (req, res, next) => {
  try {
    const { semester, subject, unit, topic } = req.query;
    const filter = {};

    let semNum = null;
    if (semester !== undefined && semester !== "") {
      const semMatch = String(semester).match(/\d+/);
      if (semMatch) {
        semNum = Number(semMatch[0]);
        filter.semester = semNum;
      }
    }
    if (subject) {
      const escapedSub = subject.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filter.subject = { $regex: new RegExp(`^${escapedSub}$`, "i") };
    }
    if (unit && Number(unit) !== 0) filter.unit = Number(unit);
    if (topic) filter.topic = { $regex: topic, $options: "i" };

    let materials = await StudyMaterial.find(filter).sort({ semester: 1, subject: 1, unit: 1 });

    // If no custom materials exist and semester+subject requested, synthesize from Syllabus topics
    if (materials.length === 0 && (semester || semNum) && subject) {
      const targetSem = semNum || 1;
      const escapedSub = subject.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const syllabusDoc = await Syllabus.findOne({
        semester: targetSem,
        subject: { $regex: new RegExp(`^${escapedSub}$`, "i") }
      });
      if (syllabusDoc && syllabusDoc.units) {
        let targetUnits = syllabusDoc.units;
        if (unit && Number(unit) !== 0) {
          targetUnits = targetUnits.filter(u => u.unitNumber === Number(unit));
        }

        const generatedList = [];
        targetUnits.forEach(u => {
          (u.topics || []).forEach((top, idx) => {
            if (!topic || top.toLowerCase().includes(topic.toLowerCase())) {
              generatedList.push({
                _id: `synth-${syllabusDoc._id}-${u.unitNumber}-${idx}`,
                semester: Number(semester),
                subject,
                unit: u.unitNumber,
                topic: top,
                title: `${top} - Core Revision & Lecture Notes`,
                content: synthesizeStudyContent(subject, u.unitNumber, top),
                author: "B.Sc CS Academic Faculty",
                createdAt: new Date()
              });
            }
          });
        });

        if (generatedList.length > 0) {
          return res.json({ success: true, count: generatedList.length, data: generatedList });
        }
      }
    }

    res.json({ success: true, count: materials.length, data: materials });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single study material
// @route   GET /api/study-materials/:id
const getMaterialById = async (req, res, next) => {
  try {
    const material = await StudyMaterial.findById(req.params.id);
    if (!material) {
      return res.status(404).json({ success: false, message: "Study material not found" });
    }
    res.json({ success: true, data: material });
  } catch (error) {
    next(error);
  }
};

// @desc    Create study material
// @route   POST /api/study-materials
const createStudyMaterial = async (req, res, next) => {
  try {
    const { semester, subject, unit, topic, title, content } = req.body;

    if (!semester || !subject || !unit || !topic || !title || !content) {
      return res.status(400).json({ success: false, message: "All study material fields are required" });
    }

    const material = await StudyMaterial.create({
      semester: Number(semester),
      subject,
      unit: Number(unit),
      topic,
      title,
      content,
      author: req.user ? req.user.name : "CS Department Faculty"
    });

    res.status(201).json({ success: true, data: material, message: "Study material added successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Update study material
// @route   PUT /api/study-materials/:id
const updateStudyMaterial = async (req, res, next) => {
  try {
    const material = await StudyMaterial.findById(req.params.id);
    if (!material) {
      return res.status(404).json({ success: false, message: "Study material not found" });
    }

    const { semester, subject, unit, topic, title, content } = req.body;
    if (semester) material.semester = Number(semester);
    if (subject) material.subject = subject;
    if (unit) material.unit = Number(unit);
    if (topic) material.topic = topic;
    if (title) material.title = title;
    if (content) material.content = content;

    const updated = await material.save();
    res.json({ success: true, data: updated, message: "Study material updated successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete study material
// @route   DELETE /api/study-materials/:id
const deleteStudyMaterial = async (req, res, next) => {
  try {
    const material = await StudyMaterial.findById(req.params.id);
    if (!material) {
      return res.status(404).json({ success: false, message: "Study material not found" });
    }
    await StudyMaterial.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Study material deleted successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getStudyMaterials,
  getMaterialById,
  createStudyMaterial,
  updateStudyMaterial,
  deleteStudyMaterial
};
