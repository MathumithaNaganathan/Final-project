const mongoose = require("mongoose");
const GeneratedPaper = require("../models/GeneratedPaper");
const User = require("../models/User");
const { createQuestionPaperPDF } = require("../services/pdfService");
const { normalizeToSections, calculatePaperMarks } = require("../utils/paperFormatter");

// Helper to safely get ObjectId for faculty
async function resolveFacultyId(req) {
  if (!req.user) return null;
  if (req.user._id && mongoose.Types.ObjectId.isValid(req.user._id)) {
    return req.user._id;
  }
  // Try resolving from DB if mock/default ID was passed
  try {
    const facUser = await User.findOne({ role: "Faculty" });
    if (facUser) return facUser._id;
  } catch (err) {
    // ignore
  }
  return null;
}

// @desc    Save generated paper permanently to MongoDB
// @route   POST /api/papers
const savePaper = async (req, res, next) => {
  try {
    const {
      semester,
      subject,
      examType,
      duration,
      totalMarks,
      difficulty,
      selectedUnits,
      unitsCovered,
      generatedDate,
      sections,
      parts
    } = req.body;

    if (!semester || !subject) {
      return res.status(400).json({ success: false, message: "Missing required paper fields: semester and subject" });
    }

    const normalizedSections = normalizeToSections({ sections, parts });
    if (!normalizedSections || normalizedSections.length === 0) {
      return res.status(400).json({ success: false, message: "Paper must contain at least one section with questions" });
    }

    const facultyId = await resolveFacultyId(req);
    const calculatedSum = calculatePaperMarks(normalizedSections);

    let unitsList = [];
    if (Array.isArray(selectedUnits) && selectedUnits.length > 0) {
      unitsList = selectedUnits.map(String);
    } else if (Array.isArray(unitsCovered) && unitsCovered.length > 0) {
      unitsList = unitsCovered.map(String);
    }

    const newPaper = await GeneratedPaper.create({
      faculty: facultyId,
      semester: Number(semester),
      subject: subject.trim(),
      examType: examType || "Summative Examination",
      duration: duration || "3 Hours",
      totalMarks: calculatedSum || Number(totalMarks) || 75,
      difficulty: difficulty || "Medium",
      selectedUnits: unitsList,
      generatedDate: generatedDate || new Date().toISOString().split("T")[0],
      sections: normalizedSections
    });

    res.status(201).json({
      success: true,
      data: newPaper,
      message: "Question paper permanently saved to MongoDB"
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all saved papers (Question Paper History)
// @route   GET /api/papers and GET /api/papers/history
const getAllPapers = async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.semester) {
      const semMatch = String(req.query.semester).match(/\d+/);
      if (semMatch) filter.semester = Number(semMatch[0]);
    }
    if (req.query.subject) {
      filter.subject = new RegExp(req.query.subject, "i");
    }

    const papers = await GeneratedPaper.find(filter)
      .populate("faculty", "name email department")
      .sort({ createdAt: -1 });

    res.json({ success: true, count: papers.length, data: papers });
  } catch (error) {
    next(error);
  }
};

// @desc    Get paper by ID
// @route   GET /api/papers/:id
const getPaperById = async (req, res, next) => {
  try {
    const paper = await GeneratedPaper.findById(req.params.id)
      .populate("faculty", "name email department");

    if (!paper) {
      return res.status(404).json({ success: false, message: "Paper not found" });
    }
    res.json({ success: true, data: paper });
  } catch (error) {
    next(error);
  }
};

// @desc    Update paper
// @route   PUT /api/papers/:id
const updatePaper = async (req, res, next) => {
  try {
    const paper = await GeneratedPaper.findById(req.params.id);
    if (!paper) {
      return res.status(404).json({ success: false, message: "Paper not found" });
    }

    const {
      semester,
      subject,
      examType,
      duration,
      totalMarks,
      difficulty,
      selectedUnits,
      sections,
      parts
    } = req.body;

    if (semester) paper.semester = Number(semester);
    if (subject) paper.subject = subject.trim();
    if (examType) paper.examType = examType;
    if (duration) paper.duration = duration;
    if (difficulty) paper.difficulty = difficulty;
    if (Array.isArray(selectedUnits)) paper.selectedUnits = selectedUnits.map(String);

    if (sections || parts) {
      const normalized = normalizeToSections({ sections, parts });
      if (normalized.length > 0) {
        paper.sections = normalized;
        paper.totalMarks = calculatePaperMarks(normalized);
      }
    } else if (totalMarks) {
      paper.totalMarks = Number(totalMarks);
    }

    const updated = await paper.save();
    res.json({ success: true, data: updated, message: "Paper updated successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete paper
// @route   DELETE /api/papers/:id
const deletePaper = async (req, res, next) => {
  try {
    const paper = await GeneratedPaper.findById(req.params.id);
    if (!paper) {
      return res.status(404).json({ success: false, message: "Paper not found" });
    }
    await GeneratedPaper.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Question paper deleted successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Download paper as PDF
// @route   GET /api/papers/:id/pdf
const downloadPaperPDF = async (req, res, next) => {
  try {
    const paper = await GeneratedPaper.findById(req.params.id);
    if (!paper) {
      return res.status(404).json({ success: false, message: "Paper not found" });
    }

    const safeTitle = (paper.title || paper.subject || "Question_Paper").replace(/[^a-zA-Z0-9_-]/g, "_");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${safeTitle}.pdf"`);

    await createQuestionPaperPDF(paper, res);
  } catch (error) {
    next(error);
  }
};

// @desc    Stream PDF directly from request body (with download guardrail validation)
// @route   POST /api/papers/export-pdf
const exportDirectPDF = async (req, res, next) => {
  try {
    const paperData = req.body;
    if (!paperData || (!paperData.parts && !paperData.sections)) {
      return res.status(400).json({ success: false, message: "Invalid paper data" });
    }

    // Download Guardrail: Recalculate marks from sections or parts
    const normalizedSections = normalizeToSections(paperData);
    const calculatedMarks = calculatePaperMarks(normalizedSections);
    const targetMarks = Number(paperData.targetTotalMarks || paperData.totalMarks || calculatedMarks);

    if (paperData.targetTotalMarks && calculatedMarks !== targetMarks) {
      return res.status(400).json({
        success: false,
        message: `Download Guardrail: Total marks (${calculatedMarks}) do not match Target Total Marks (${targetMarks}). Adjust question marks before downloading.`
      });
    }

    paperData.totalMarks = calculatedMarks || targetMarks || 75;

    const safeTitle = (paperData.subject || "Question_Paper").replace(/[^a-zA-Z0-9_-]/g, "_");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${safeTitle}_Exam.pdf"`);

    await createQuestionPaperPDF(paperData, res);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  savePaper,
  getAllPapers,
  getPaperById,
  updatePaper,
  deletePaper,
  downloadPaperPDF,
  exportDirectPDF
};
