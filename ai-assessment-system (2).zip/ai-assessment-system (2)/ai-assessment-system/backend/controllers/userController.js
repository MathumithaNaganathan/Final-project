const User = require("../models/User");

// @desc    Get current user profile
// @route   GET /api/users/profile or GET /api/profile
// @access  Private
const getUserProfile = async (req, res, next) => {
  try {
    let user = null;
    const isDefaultId = req.user && req.user._id && req.user._id.toString().includes("default_id");
    if (!isDefaultId) {
      try {
        user = await User.findById(req.user._id).select("-password");
      } catch (err) {
        console.warn("[UserController] findById error:", err.message);
      }
    }
    if (!user && req.user) {
      try {
        if (req.user.username) {
          user = await User.findOne({ username: req.user.username.toLowerCase() }).select("-password");
        }
        if (!user && req.user.email) {
          user = await User.findOne({ email: req.user.email.toLowerCase() }).select("-password");
        }
        if (!user && req.user.role) {
          user = await User.findOne({ role: req.user.role }).select("-password");
        }
      } catch (err) {
        console.warn("[UserController] fallback lookup error:", err.message);
      }
    }

    const u = user || req.user;
    if (!u) {
      return res.status(404).json({ success: false, message: "User account not found" });
    }

    const isFaculty = (u.role || "").toLowerCase() === "faculty";
    const resolvedUsername = u.username || (isFaculty ? "faculty" : "student");
    return res.json({
      success: true,
      user: {
        _id: u._id,
        name: u.name,
        fullName: u.name,
        username: resolvedUsername,
        registerNo: resolvedUsername,
        facultyId: resolvedUsername,
        email: u.email,
        phone: u.phone || "",
        dob: u.dob || "",
        gender: u.gender || "",
        address: u.address || "",
        profilePhoto: u.profilePhoto || "",
        role: u.role,
        department: u.department || "B.Sc Computer Science",
        semester: u.semester || 1,
        designation: u.designation || (isFaculty ? "Associate Professor" : ""),
        qualification: u.qualification || (isFaculty ? "M.Sc., M.Phil., Ph.D." : "Higher Secondary")
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update current user profile (Full Name, Email, Phone, DoB, Gender, Dept, Semester/Designation, Address, Photo)
// @route   PUT /api/users/profile or PUT /api/user/profile or PUT /api/faculty/profile or PUT /api/student/profile
// @access  Private
// @desc    Update current user profile (Full Name, Email, Username)
// @route   PUT /api/users/profile or PUT /api/user/profile or PUT /api/faculty/profile or PUT /api/student/profile
// @access  Private
const updateUserProfile = async (req, res, next) => {
  try {
    const role = (req.user && req.user.role) ? req.user.role : "Student";
    const isFaculty = role.toLowerCase() === "faculty";

    // Strict role-based URL authorization
    if (req.originalUrl.includes("/faculty") && !isFaculty) {
      return res.status(403).json({ success: false, message: "Forbidden: Only faculty can update faculty profile" });
    }
    if (req.originalUrl.includes("/student") && isFaculty) {
      return res.status(403).json({ success: false, message: "Forbidden: Only students can update student profile" });
    }

    // Extract fields (Full Name, Email, Username)
    const name = req.body.fullName !== undefined ? req.body.fullName : req.body.name;
    const email = req.body.email;
    const username = req.body.username !== undefined ? req.body.username : req.body.registerNo;

    // Optional legacy fields preserved if provided
    const phone = req.body.phone !== undefined ? req.body.phone : "";
    const dob = req.body.dob !== undefined ? req.body.dob : "";
    const gender = req.body.gender !== undefined ? req.body.gender : "";
    const address = req.body.address !== undefined ? req.body.address : "";
    const department = req.body.department !== undefined ? req.body.department : "B.Sc Computer Science";
    const semester = req.body.semester !== undefined ? Number(req.body.semester) : 1;
    const designation = req.body.designation !== undefined ? req.body.designation : "";
    const qualification = req.body.qualification !== undefined ? req.body.qualification : "";

    // 1. Validate Full Name
    if (!name || typeof name !== "string" || !name.trim()) {
      return res.status(400).json({ success: false, message: "Full Name is required", field: "fullName" });
    }

    // 2. Validate Email Address
    if (!email || typeof email !== "string" || !email.trim()) {
      return res.status(400).json({ success: false, message: "Email Address is required", field: "email" });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({ success: false, message: "Please provide a valid email address", field: "email" });
    }

    // 3. Validate Username
    if (!username || typeof username !== "string" || !username.trim()) {
      return res.status(400).json({ success: false, message: "Username is required", field: "username" });
    }

    const cleanUsername = username.trim().toLowerCase();
    if (cleanUsername.length < 3) {
      return res.status(400).json({ success: false, message: "Username must be at least 3 characters long", field: "username" });
    }
    if (!/^[a-zA-Z0-9_.-]+$/.test(cleanUsername)) {
      return res.status(400).json({ success: false, message: "Username can only contain letters, numbers, hyphens, underscores and dots", field: "username" });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();

    let user = null;
    const isDefaultId = req.user && req.user._id && req.user._id.toString().includes("default_id");
    if (!isDefaultId) {
      try {
        user = await User.findById(req.user._id);
      } catch (err) {
        console.warn("[UserController] findById error:", err.message);
      }
    }
    if (!user && req.user) {
      try {
        if (req.user.username) {
          user = await User.findOne({ username: req.user.username.toLowerCase() });
        }
        if (!user && req.user.email) {
          user = await User.findOne({ email: req.user.email.toLowerCase() });
        }
        if (!user && req.user.role) {
          user = await User.findOne({ role: req.user.role });
        }
      } catch (err) {
        console.warn("[UserController] fallback lookup error:", err.message);
      }
    }

    if (user) {
      // Check if email changed and if already taken by another user -> 409 Conflict
      if (cleanEmail !== (user.email || "").toLowerCase()) {
        const emailExists = await User.findOne({ email: cleanEmail, _id: { $ne: user._id } });
        if (emailExists) {
          return res.status(409).json({ success: false, message: "Email address is already in use by another account", field: "email" });
        }
        user.email = cleanEmail;
      }

      // Check if username changed and if already taken by another user -> 409 Conflict
      if (cleanUsername !== (user.username || "").toLowerCase()) {
        const usernameExists = await User.findOne({ username: cleanUsername, _id: { $ne: user._id } });
        if (usernameExists) {
          return res.status(409).json({ success: false, message: "Username is already in use by another account", field: "username" });
        }
        user.username = cleanUsername;
      }

      user.name = cleanName;
      if (phone) user.phone = phone.trim();
      if (dob) user.dob = dob.trim();
      if (gender) user.gender = gender.trim();
      if (address) user.address = address.trim();
      if (department) user.department = department.trim();

      if (isFaculty) {
        if (designation) user.designation = designation.trim();
        if (qualification) user.qualification = qualification.trim();
      } else {
        if (semester >= 1 && semester <= 6) {
          user.semester = semester;
        }
      }
      console.log("PROFILE SAVE START");
      console.log("USER:", user._id);
      console.log("NAME:", cleanName);
      console.log("EMAIL:", cleanEmail);
      console.log("USERNAME:", cleanUsername);

      await user.save();
      console.log("PROFILE SAVE SUCCESS");

      return res.json({
        success: true,
        message: "Profile updated successfully.",
        user: {
          _id: user._id,
          name: user.name,
          fullName: user.name,
          username: user.username,
          registerNo: user.username,
          facultyId: user.username,
          email: user.email,
          role: user.role,
          department: user.department || "B.Sc Computer Science",
          semester: user.semester || 1,
          designation: user.designation || (isFaculty ? "Associate Professor" : ""),
          qualification: user.qualification || (isFaculty ? "M.Sc., M.Phil., Ph.D." : "")
        }
      });
    }

    // If user document was not found, persist it to MongoDB now so changes are permanently saved
    let createdUser = null;
    try {
      createdUser = await User.create({
        name: cleanName,
        email: cleanEmail,
        username: cleanUsername,
        password: isFaculty ? "faculty123" : "student123",
        role: (req.user && req.user.role) ? req.user.role : (isFaculty ? "Faculty" : "Student"),
        department: department || "B.Sc Computer Science",
        semester: (!isFaculty && semester) ? semester : 1,
        phone: phone || "",
        dob: dob || "",
        gender: gender || "",
        address: address || "",
        designation: isFaculty ? (designation || "Associate Professor") : "",
        qualification: isFaculty ? (qualification || "M.Sc., M.Phil., Ph.D.") : "Higher Secondary",
        profilePhoto: ""
      });
    } catch (createErr) {
      console.warn("[UserController] Upsert failed:", createErr.message);
    }

    const finalUser = createdUser || req.user || {};
    return res.json({
      success: true,
      message: "Profile updated successfully.",
      user: {
        _id: finalUser._id || req.user._id,
        name: cleanName,
        fullName: cleanName,
        username: cleanUsername,
        registerNo: cleanUsername,
        facultyId: cleanUsername,
        email: cleanEmail,
        role: (req.user && req.user.role) || (isFaculty ? "Faculty" : "Student"),
        department: department || "B.Sc Computer Science",
        semester: (!isFaculty && semester) ? semester : ((req.user && req.user.semester) || 1),
        designation: isFaculty ? (designation || "Associate Professor") : "",
        qualification: isFaculty ? (qualification || "M.Sc., M.Phil., Ph.D.") : ""
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Change user password
// @route   PUT /api/users/change-password
// @access  Private
const changeUserPassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword, confirmPassword, confirmNewPassword } = req.body;
    const confirmed = confirmPassword !== undefined ? confirmPassword : confirmNewPassword;

    if (!currentPassword) {
      return res.status(400).json({ success: false, message: "Current password is required" });
    }

    if (!newPassword) {
      return res.status(400).json({ success: false, message: "New password is required" });
    }

    if (!confirmed) {
      return res.status(400).json({ success: false, message: "Please confirm your new password" });
    }

    if (newPassword !== confirmed) {
      return res.status(400).json({ success: false, message: "New Password and Confirm New Password must match" });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ success: false, message: "New password must be at least 6 characters long" });
    }

    let user = null;
    const isDefaultId = req.user && req.user._id && req.user._id.toString().includes("default_id");
    if (!isDefaultId) {
      try {
        user = await User.findById(req.user._id);
      } catch (err) {
        console.warn("[UserController] findById error:", err.message);
      }
    }

    if (!user && req.user) {
      try {
        if (req.user.username) {
          user = await User.findOne({ username: req.user.username.toLowerCase() });
        }
        if (!user && req.user.email) {
          user = await User.findOne({ email: req.user.email.toLowerCase() });
        }
      } catch (err) {
        console.warn("[UserController] fallback lookup error:", err.message);
      }
    }

    if (!user) {
      // Standalone demo user password check
      const defaultPass = (req.user && req.user.role === "Faculty") ? "faculty123" : "student123";
      if (currentPassword !== defaultPass) {
        return res.status(400).json({ success: false, message: "Current password is incorrect" });
      }
      return res.json({
        success: true,
        message: "Password updated successfully"
      });
    }

    const isMatch = await user.matchPassword(currentPassword);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: "Current password is incorrect" });
    }

    user.password = newPassword;
    await user.save();

    return res.json({
      success: true,
      message: "Password updated successfully"
    });
  } catch (error) {
    console.error("PROFILE UPDATE ERROR:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Server error updating profile"
    });
  }
};

module.exports = {
  getUserProfile,
  updateUserProfile,
  changeUserPassword
};
