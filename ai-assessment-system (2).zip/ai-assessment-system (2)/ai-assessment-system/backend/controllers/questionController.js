const Question = require("../models/Question");
const { getCategorizedQuestionsForUnit } = require("../services/aiService");
const { QUESTIONS_DATA } = require("../seed/seedQuestions");
const { MCQ_DATA } = require("../seed/seedMCQ");

// @desc    Get questions with filters
// @route   GET /api/questions
const getQuestions = async (req, res, next) => {
  try {
    const { semester, subject, unit, units, selectedUnits, marks, difficulty, questionType, search } = req.query;
    const filter = {};

    if (semester !== undefined && semester !== "") {
      const semMatch = String(semester).match(/\d+/);
      if (semMatch) filter.semester = Number(semMatch[0]);
    }
    if (subject) {
      const escapedSub = subject.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      filter.subject = { $regex: new RegExp(`^${escapedSub}$`, "i") };
    }
    const unitsList = selectedUnits || units;
    if (unitsList) {
      const arr = (Array.isArray(unitsList) ? unitsList : String(unitsList).split(",")).map(Number).filter(n => n > 0);
      if (arr.length > 0) {
        filter.unit = { $in: arr };
      }
    } else if (unit !== undefined && unit !== "" && Number(unit) !== 0) {
      filter.unit = Number(unit);
    }
    if (marks !== undefined && marks !== "" && Number(marks) !== 0) filter.marks = Number(marks);
    if (difficulty && difficulty !== "All") filter.difficulty = difficulty;
    if (questionType && questionType !== "All") filter.questionType = questionType;
    if (search) {
      filter.question = { $regex: search, $options: "i" };
    }

    // Auto-seed questions into MongoDB if collection is uninitialized
    const totalCount = await Question.countDocuments();
    if (totalCount === 0) {
      const initialDocs = [];
      if (QUESTIONS_DATA && Array.isArray(QUESTIONS_DATA)) {
        QUESTIONS_DATA.forEach(q => {
          initialDocs.push({
            semester: Number(q.sem),
            subject: q.sub,
            unit: Number(q.u),
            topic: q.top || "Core Concept",
            question: q.q,
            options: [],
            correctAnswer: "",
            marks: Number(q.m) || 2,
            difficulty: q.d || "Medium",
            answer: q.a || "",
            questionType: "Theory"
          });
        });
      }
      if (MCQ_DATA && Array.isArray(MCQ_DATA)) {
        MCQ_DATA.forEach(m => {
          initialDocs.push({
            semester: Number(m.semester),
            subject: m.subject,
            unit: Number(m.unit),
            topic: m.topic || "Core Concept",
            question: m.question,
            options: Array.isArray(m.options) ? m.options : [],
            correctAnswer: m.correctAnswer || "",
            marks: 1,
            difficulty: m.difficulty || "Easy",
            answer: m.answer || "",
            questionType: "MCQ"
          });
        });
      }
      if (initialDocs.length > 0) {
        try {
          await Question.insertMany(initialDocs, { ordered: false });
        } catch (e) {}
      }
    }

    let questions = await Question.find(filter).sort({ marks: 1, createdAt: -1 });

    // Fallback: If filtered by semester and subject, but no questions found in MongoDB matching the query,
    // synthesize categorized questions (1M, 2M, 4M, 5M, 7M, 10M) with detailed model answers and persist to MongoDB
    if (questions.length === 0 && semester && subject) {
      const unitNum = (unit && Number(unit) !== 0) ? Number(unit) : 1;
      const generated = await getCategorizedQuestionsForUnit(Number(semester), subject, unitNum);
      const allGen = Object.values(generated).flat();
      if (allGen.length > 0) {
        try {
          await Question.insertMany(allGen, { ordered: false });
        } catch (e) {}
      }
      questions = await Question.find(filter).sort({ marks: 1, createdAt: -1 });
    }

    res.json({ success: true, count: questions.length, data: questions });
  } catch (error) {
    next(error);
  }
};

// @desc    Get categorized questions (1M, 2M, 4M, 5M, 7M, 10M) with detailed answers
// @route   GET /api/questions/categorized/:semester/:subject/:unit
const getCategorizedQuestions = async (req, res, next) => {
  try {
    const rawSem = req.params.semester;
    const semMatch = String(rawSem).match(/\d+/);
    const semester = semMatch ? Number(semMatch[0]) : (Number(rawSem) || 1);
    const subject = decodeURIComponent(req.params.subject);
    const unit = Number(req.params.unit) || 1;

    // Fetch existing questions from MongoDB
    const existing = await Question.find({ semester, subject, unit });

    const markTiers = [1, 2, 3, 4, 5, 7, 10];
    const categorized = { 1: [], 2: [], 3: [], 4: [], 5: [], 7: [], 10: [] };

    existing.forEach(q => {
      const m = Number(q.marks);
      if (categorized[m]) {
        categorized[m].push(q);
      }
    });

    // Check if any mark tier is missing questions
    let needsGeneration = false;
    for (const m of markTiers) {
      if (categorized[m].length === 0) {
        needsGeneration = true;
        break;
      }
    }

    if (needsGeneration) {
      const generated = await getCategorizedQuestionsForUnit(semester, subject, unit);
      const toSave = [];

      for (const m of markTiers) {
        if (categorized[m].length === 0 && generated[m]) {
          categorized[m] = generated[m];
          toSave.push(...generated[m]);
        }
      }

      if (toSave.length > 0) {
        try {
          await Question.insertMany(toSave);
        } catch (saveErr) {}
      }
    }

    res.json({
      success: true,
      semester,
      subject,
      unit,
      data: categorized
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get questions by semester and subject
// @route   GET /api/questions/:semester/:subject
const getQuestionsBySubject = async (req, res, next) => {
  try {
    const rawSem = req.params.semester;
    const semMatch = String(rawSem).match(/\d+/);
    const semester = semMatch ? Number(semMatch[0]) : Number(rawSem);
    if (isNaN(semester)) {
      if (req.params.semester && req.params.semester.match(/^[0-9a-fA-F]{24}$/)) {
        const question = await Question.findById(req.params.semester);
        if (question) {
          return res.json({ success: true, data: question });
        }
      }
    }
    const subject = decodeURIComponent(req.params.subject);
    const questions = await Question.find({ semester, subject }).sort({ unit: 1, marks: 1 });
    res.json({ success: true, count: questions.length, data: questions });
  } catch (error) {
    next(error);
  }
};

// @desc    Get questions by semester, subject, and unit
// @route   GET /api/questions/:semester/:subject/:unit
const getQuestionsByUnit = async (req, res, next) => {
  try {
    const rawSem = req.params.semester;
    const semMatch = String(rawSem).match(/\d+/);
    const semester = semMatch ? Number(semMatch[0]) : Number(rawSem);
    const subject = decodeURIComponent(req.params.subject);
    const unit = Number(req.params.unit);
    const questions = await Question.find({ semester, subject, unit }).sort({ marks: 1 });
    res.json({ success: true, count: questions.length, data: questions });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single question
// @route   GET /api/questions/:id
const getQuestionById = async (req, res, next) => {
  try {
    const question = await Question.findById(req.params.id);
    if (!question) {
      return res.status(404).json({ success: false, message: "Question not found" });
    }
    res.json({ success: true, data: question });
  } catch (error) {
    next(error);
  }
};

// @desc    Create question
// @route   POST /api/questions
const createQuestion = async (req, res, next) => {
  try {
    const { semester, subject, unit, topic, question, options, correctAnswer, marks, difficulty, answer, questionType } = req.body;

    if (!semester || !subject || !unit || !question || marks === undefined) {
      return res.status(400).json({ success: false, message: "Missing required question fields" });
    }

    const qMarks = Number(marks);
    const qType = questionType || (qMarks === 1 ? "MCQ" : "Theory");

    const created = await Question.create({
      semester: Number(semester),
      subject: subject.trim(),
      unit: Number(unit),
      topic: topic || "General",
      question: question.trim(),
      options: (qType === "MCQ" && Array.isArray(options)) ? options : [],
      correctAnswer: qType === "MCQ" ? (correctAnswer || "").trim() : "",
      marks: qMarks,
      difficulty: difficulty || "Medium",
      answer: (answer || "").trim(),
      questionType: qType
    });

    res.status(201).json({ success: true, data: created, message: "Question added successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Update question
// @route   PUT /api/questions/:id
const updateQuestion = async (req, res, next) => {
  try {
    const question = await Question.findById(req.params.id);
    if (!question) {
      return res.status(404).json({ success: false, message: "Question not found" });
    }

    const { question: text, options, correctAnswer, marks, difficulty, answer, topic } = req.body;
    if (text) question.question = text.trim();
    if (options) question.options = options;
    if (correctAnswer !== undefined) question.correctAnswer = correctAnswer;
    if (marks) question.marks = Number(marks);
    if (difficulty) question.difficulty = difficulty;
    if (answer !== undefined) question.answer = answer;
    if (topic) question.topic = topic;

    const updated = await question.save();
    res.json({ success: true, data: updated, message: "Question updated successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete question
// @route   DELETE /api/questions/:id
const deleteQuestion = async (req, res, next) => {
  try {
    const question = await Question.findById(req.params.id);
    if (!question) {
      return res.status(404).json({ success: false, message: "Question not found" });
    }
    await Question.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Question deleted successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getQuestions,
  getCategorizedQuestions,
  getQuestionsBySubject,
  getQuestionsByUnit,
  getQuestionById,
  createQuestion,
  updateQuestion,
  deleteQuestion
};
