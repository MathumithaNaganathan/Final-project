const mongoose = require("mongoose");
const aiService = require("../services/aiService");
const Question = require("../models/Question");
const GeneratedPaper = require("../models/GeneratedPaper");
const User = require("../models/User");
const { normalizeToSections, calculatePaperMarks } = require("../utils/paperFormatter");

// @desc    Generate AI Question Paper with strict syllabus binding, Thiagarajar layout, and semantic deduplication
// @route   POST /api/ai/generate-paper
const generatePaper = async (req, res, next) => {
  try {
    const {
      semester,
      subject,
      courseCode,
      units,
      selectedUnits,
      examType,
      monthYear,
      duration,
      totalMarks,
      difficulty,
      sections,
      sectionA,
      sectionB,
      sectionC
    } = req.body;

    if (!semester || !subject) {
      return res.status(400).json({ success: false, message: "Semester and subject are required" });
    }

    const resolvedUnits = Array.isArray(selectedUnits) && selectedUnits.length > 0
      ? selectedUnits.map(Number)
      : (Array.isArray(units) && units.length > 0 ? units.map(Number) : []);

    const paper = await aiService.generateQuestionPaper({
      semester: Number(semester),
      subject,
      courseCode,
      selectedUnits: resolvedUnits,
      examType: examType || "Summative Examination",
      monthYear: monthYear || "APRIL 2026",
      duration: duration || "3 Hours",
      totalMarks: Number(totalMarks) || 75,
      difficulty: difficulty || "Medium",
      sections: Array.isArray(sections) ? sections : undefined,
      sectionA,
      sectionB,
      sectionC
    });

    // Automatically persist the generated question paper into MongoDB!
    let facultyId = null;
    if (req.user) {
      if (mongoose.Types.ObjectId.isValid(req.user._id)) {
        facultyId = req.user._id;
      } else {
        try {
          const facUser = await User.findOne({ role: "Faculty" });
          if (facUser) facultyId = facUser._id;
        } catch (e) {}
      }
    }

    const normalizedSections = normalizeToSections(paper);
    const calculatedSum = calculatePaperMarks(normalizedSections);

    const savedPaper = await GeneratedPaper.create({
      faculty: facultyId,
      semester: Number(semester),
      subject: paper.subject || subject,
      examType: paper.examType || examType || "Summative Examination",
      duration: paper.duration || duration || "3 Hours",
      totalMarks: calculatedSum || Number(paper.totalMarks || totalMarks) || 75,
      difficulty: paper.difficulty || difficulty || "Medium",
      selectedUnits: resolvedUnits.map(String),
      generatedDate: new Date().toISOString().split("T")[0],
      sections: normalizedSections
    });

    const responseData = {
      ...paper,
      _id: savedPaper._id,
      id: savedPaper._id,
      generatedDate: savedPaper.generatedDate,
      createdAt: savedPaper.createdAt,
      sections: savedPaper.sections,
      parts: savedPaper.parts || paper.parts
    };

    res.json({
      success: true,
      data: responseData,
      message: "Question paper generated and permanently saved to history"
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Regenerate single question with duplicate prevention and Either/OR counterpart avoidance
// @route   POST /api/ai/regenerate-question
const regenerateQuestion = async (req, res, next) => {
  try {
    const {
      semester,
      subject,
      unit,
      topic,
      marks,
      difficulty,
      currentQuestion,
      counterpartQuestion,
      excludeQuestions,
      isOrQuestion
    } = req.body;

    if (!semester || !subject) {
      return res.status(400).json({ success: false, message: "Semester and subject are required" });
    }

    const replacement = await aiService.regenerateIndividualQuestion({
      semester: Number(semester),
      subject,
      unit: Number(unit) || 1,
      topic: topic || "Core Topic",
      marks: Number(marks) || 5,
      difficulty: difficulty || "Medium",
      currentQuestion: currentQuestion || "",
      counterpartQuestion: counterpartQuestion || "",
      excludeQuestions: Array.isArray(excludeQuestions) ? excludeQuestions : [],
      isOrQuestion: Boolean(isOrQuestion)
    });

    res.json({ success: true, data: replacement, message: "Question regenerated successfully" });
  } catch (error) {
    next(error);
  }
};

// @desc    Check paper or question list for semantic duplicates
// @route   POST /api/ai/check-duplicates
const checkPaperDuplicates = async (req, res, next) => {
  try {
    const { paper, questions } = req.body;
    const targetPaper = paper || { parts: [{ questions: Array.isArray(questions) ? questions : [] }] };
    const audit = aiService.checkDuplicatesInPaper(targetPaper);
    res.json({ success: true, data: audit });
  } catch (error) {
    next(error);
  }
};

// @desc    Get categorized questions (1M, 2M, 4M, 5M, 7M, 10M) with detailed answers
// @route   GET /api/ai/categorized-questions
const getCategorizedQuestions = async (req, res, next) => {
  try {
    const { semester, subject, unit } = req.query;

    if (!semester || !subject) {
      return res.status(400).json({ success: false, message: "Semester and subject are required" });
    }

    const data = await aiService.getCategorizedQuestionsForUnit(
      Number(semester),
      subject,
      Number(unit) || 1
    );

    res.json({ success: true, data, message: "Categorized questions fetched successfully" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  generatePaper,
  regenerateQuestion,
  checkPaperDuplicates,
  getCategorizedQuestions
};
