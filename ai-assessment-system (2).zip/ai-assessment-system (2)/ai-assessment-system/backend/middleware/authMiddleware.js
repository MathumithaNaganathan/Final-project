const jwt = require("jsonwebtoken");
const User = require("../models/User");

const JWT_SECRET = process.env.JWT_SECRET || "bsc_cs_ai_exam_secret_key_2026_jwt_token";

const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    token = req.headers.authorization.split(" ")[1];
  }

  if (!token) {
    return res.status(401).json({ success: false, message: "Not authorized, token missing" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    if (decoded.id === "faculty_default_id") {
      req.user = {
        _id: "faculty_default_id",
        name: "Dr. Rajesh Sharma",
        username: "faculty",
        email: "faculty@college.edu",
        role: "Faculty",
        department: "B.Sc Computer Science",
        semester: 1
      };
      return next();
    }
    if (decoded.id === "student_default_id") {
      req.user = {
        _id: "student_default_id",
        name: "Anand Kumar",
        username: "student",
        email: "student@college.edu",
        role: "Student",
        department: "B.Sc Computer Science",
        semester: 1
      };
      return next();
    }

    req.user = await User.findById(decoded.id).select("-password");
    if (!req.user) {
      return res.status(401).json({ success: false, message: "User account no longer exists" });
    }
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Invalid or expired authorization token" });
  }
};

const optionalProtect = async (req, res, next) => {
  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    const token = req.headers.authorization.split(" ")[1];
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (decoded.id === "faculty_default_id") {
        req.user = {
          _id: "faculty_default_id",
          name: "Dr. Rajesh Sharma",
          username: "faculty",
          email: "faculty@college.edu",
          role: "Faculty",
          department: "B.Sc Computer Science",
          semester: 1
        };
      } else if (decoded.id === "student_default_id") {
        req.user = {
          _id: "student_default_id",
          name: "Anand Kumar",
          username: "student",
          email: "student@college.edu",
          role: "Student",
          department: "B.Sc Computer Science",
          semester: 1
        };
      } else {
        req.user = await User.findById(decoded.id).select("-password");
      }
    } catch (err) {
      // Proceed without user
    }
  }
  next();
};

const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    const userRole = (req.user.role || "").toLowerCase();
    const allowed = roles.map(r => r.toLowerCase());
    if (!allowed.includes(userRole)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: Access restricted to [${roles.join(", ")}] roles. Your role is '${req.user.role}'`
      });
    }
    next();
  };
};

module.exports = { protect, optionalProtect, requireRole };
