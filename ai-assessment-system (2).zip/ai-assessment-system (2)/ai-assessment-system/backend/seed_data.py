import json
import hashlib
from datetime import datetime, timedelta
from database import engine, SessionLocal, Base
from models import (
    User, SyllabusUnit, SyllabusTopic, QuestionPaper, Question,
    StudyMaterial, TestAttempt, StudentAnswer, PerformanceSummary
)

def hash_pw(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # Check if already seeded
    if db.query(User).first():
        print("Database already contains data. Skipping seed.")
        db.close()
        return

    print("Seeding initial database records...")

    # 1. Faculty User
    faculty = User(
        name="Dr. Rajesh Sharma",
        email="faculty@university.edu",
        password_hash=hash_pw("faculty123"),
        role="FACULTY",
        department="Computer Science & Engineering",
        profile_bio="Professor of Database Systems & AI Architecture. 15+ years academic & research experience."
    )
    db.add(faculty)
    db.flush()

    # 2. Student User
    student = User(
        name="Aarav Patel",
        email="student@university.edu",
        password_hash=hash_pw("student123"),
        role="STUDENT",
        department="Computer Science & Engineering",
        profile_bio="3rd Year Computer Science Undergrad | Passionate about distributed databases and cloud systems."
    )
    db.add(student)
    db.flush()

    # 3. Syllabus Units & Topics (CS301 - Advanced Database Systems)
    unit1 = SyllabusUnit(
        faculty_id=faculty.id,
        subject_code="CS301",
        subject_name="Database Management Systems",
        unit_number=1,
        unit_title="Relational Algebra & Normalization",
        description="Core principles of relational algebra, functional dependencies, 1NF to BCNF decomposition."
    )
    db.add(unit1)
    db.flush()

    t1_1 = SyllabusTopic(
        unit_id=unit1.id,
        topic_name="Functional Dependencies & 3NF/BCNF",
        learning_objectives="Identify lossy vs lossless joins, compute minimal covers, decompose tables to BCNF.",
        bloom_taxonomy_level="Analyze",
        weightage_percentage=15
    )
    t1_2 = SyllabusTopic(
        unit_id=unit1.id,
        topic_name="Relational Algebra Operators",
        learning_objectives="Formulate select, project, join, division, and aggregate relational queries.",
        bloom_taxonomy_level="Apply",
        weightage_percentage=10
    )
    db.add_all([t1_1, t1_2])

    unit2 = SyllabusUnit(
        faculty_id=faculty.id,
        subject_code="CS301",
        subject_name="Database Management Systems",
        unit_number=2,
        unit_title="Indexing & Query Optimization",
        description="Physical database storage, B+ Trees, Hashing, Query Parsing, and Cost-based Optimizer rules."
    )
    db.add(unit2)
    db.flush()

    t2_1 = SyllabusTopic(
        unit_id=unit2.id,
        topic_name="B+ Tree Index Structures",
        learning_objectives="Analyze search, insert, and split operations in dense and sparse B+ Trees.",
        bloom_taxonomy_level="Evaluate",
        weightage_percentage=20
    )
    t2_2 = SyllabusTopic(
        unit_id=unit2.id,
        topic_name="Query Execution Plans & Cost Estimation",
        learning_objectives="Calculate I/O block transfer costs for Nested-Loop Join vs Hash Join.",
        bloom_taxonomy_level="Analyze",
        weightage_percentage=15
    )
    db.add_all([t2_1, t2_2])

    unit3 = SyllabusUnit(
        faculty_id=faculty.id,
        subject_code="CS301",
        subject_name="Database Management Systems",
        unit_number=3,
        unit_title="Transaction Management & Concurrency Control",
        description="ACID properties, Serializability, 2PL protocol, Deadlock detection, and WAL recovery."
    )
    db.add(unit3)
    db.flush()

    t3_1 = SyllabusTopic(
        unit_id=unit3.id,
        topic_name="ACID Properties & Conflict Serializability",
        learning_objectives="Construct precedence graphs and test schedules for conflict serializability.",
        bloom_taxonomy_level="Evaluate",
        weightage_percentage=20
    )
    t3_2 = SyllabusTopic(
        unit_id=unit3.id,
        topic_name="Two-Phase Locking (2PL) & Deadlock Recovery",
        learning_objectives="Differentiate Strict 2PL vs Rigorous 2PL; apply Wait-Die and Wound-Wait algorithms.",
        bloom_taxonomy_level="Apply",
        weightage_percentage=20
    )
    db.add_all([t3_1, t3_2])

    # 4. Question Paper (Set A - Midterm Assessment)
    paper1 = QuestionPaper(
        faculty_id=faculty.id,
        subject_code="CS301",
        subject_name="Database Management Systems",
        title="DBMS Mid-Term Comprehensive Assessment (Set A)",
        paper_set="A",
        exam_duration_mins=45,
        total_marks=20,
        difficulty_level="Medium",
        instructions="1. All questions are compulsory. 2. Each MCQ carries 2 marks. 3. No negative marking.",
        is_published=True,
        ai_prompt_meta=json.dumps({"model": "gemini-1.5-flash", "units": [1, 2, 3]})
    )
    db.add(paper1)
    db.flush()

    # Questions for Paper 1
    q1 = Question(
        paper_id=paper1.id,
        topic_id=t1_1.id,
        question_order=1,
        question_type="MCQ",
        question_text="A relation R(A, B, C, D) has functional dependencies: A -> B, B -> C, C -> D, D -> A. What is the highest normal form of relation R?",
        options=json.dumps([
            {"id": "A", "text": "1NF only"},
            {"id": "B", "text": "2NF but not 3NF"},
            {"id": "C", "text": "3NF but not BCNF"},
            {"id": "D", "text": "BCNF"}
        ]),
        correct_answer="D",
        explanation="Every attribute is a prime attribute since all single attributes are candidate keys. Every determinant is a superkey, thus R satisfies BCNF.",
        marks=2,
        bloom_level="Analyze"
    )

    q2 = Question(
        paper_id=paper1.id,
        topic_id=t2_1.id,
        question_order=2,
        question_type="MCQ",
        question_text="In a B+ Tree of order m (maximum m pointers in internal nodes), what is the minimum number of child pointers an internal node (except root) must contain?",
        options=json.dumps([
            {"id": "A", "text": "ceil(m / 2)"},
            {"id": "B", "text": "floor(m / 2)"},
            {"id": "C", "text": "m / 2 - 1"},
            {"id": "D", "text": "2"}
        ]),
        correct_answer="A",
        explanation="By definition of B+ tree invariants, any non-root internal node must be at least half full, holding at least ceil(m/2) pointers.",
        marks=2,
        bloom_level="Remember"
    )

    q3 = Question(
        paper_id=paper1.id,
        topic_id=t3_1.id,
        question_order=3,
        question_type="MCQ",
        question_text="Which of the following schedules is guaranteed to be conflict serializable without creating cascading aborts?",
        options=json.dumps([
            {"id": "A", "text": "Any schedule following Basic Two-Phase Locking (2PL)"},
            {"id": "B", "text": "Any schedule following Strict Two-Phase Locking (Strict 2PL)"},
            {"id": "C", "text": "Conservative 2PL without lock acquisition phases"},
            {"id": "D", "text": "Any schedule with acyclic precedence graph allowing dirty reads"}
        ]),
        correct_answer="B",
        explanation="Strict 2PL holds all exclusive locks until transaction commit or abort, eliminating cascading rollbacks and guaranteeing conflict serializability.",
        marks=2,
        bloom_level="Evaluate"
    )

    q4 = Question(
        paper_id=paper1.id,
        topic_id=t2_2.id,
        question_order=4,
        question_type="MCQ",
        question_text="When executing an equality join on two relations R (10,000 blocks) and S (500 blocks) using Block Nested Loop Join with buffer capacity B = 52 blocks, which relation should be the outer loop to minimize disk I/O?",
        options=json.dumps([
            {"id": "A", "text": "Relation R (larger relation)"},
            {"id": "B", "text": "Relation S (smaller relation)"},
            {"id": "C", "text": "Either relation yields identical I/O cost"},
            {"id": "D", "text": "Sort-merge join must be used instead"}
        ]),
        correct_answer="B",
        explanation="In Block Nested Loop join, placing the smaller relation S as outer minimizes outer chunk iterations: ceil(500/50) * 10000 + 500 = 100,500 I/Os vs ~200,000 I/Os.",
        marks=2,
        bloom_level="Analyze"
    )

    q5 = Question(
        paper_id=paper1.id,
        topic_id=t3_2.id,
        question_order=5,
        question_type="MCQ",
        question_text="In the Wait-Die deadlock prevention scheme based on transaction timestamps (where older transaction T_old has smaller timestamp than younger T_young), what happens when T_young requests a lock held by T_old?",
        options=json.dumps([
            {"id": "A", "text": "T_young is allowed to wait"},
            {"id": "B", "text": "T_young dies (rolls back and restarts)"},
            {"id": "C", "text": "T_old dies immediately"},
            {"id": "D", "text": "T_old is preempted and wounded"}
        ]),
        correct_answer="B",
        explanation="In Wait-Die: If older requests lock held by younger, older waits. If younger requests lock held by older, younger dies (aborts).",
        marks=2,
        bloom_level="Understand"
    )

    db.add_all([q1, q2, q3, q4, q5])

    # 5. Study Materials
    m1 = StudyMaterial(
        faculty_id=faculty.id,
        unit_id=unit1.id,
        title="DBMS Unit 1: Normalization & Relational Calculus Full Notes",
        material_type="PDF_NOTE",
        file_url="https://www.cs.stanford.edu/people/widom/cs145/normalization.pdf",
        description="Comprehensive lecture notes covering functional dependency proofs, Armstrong axioms, and 3NF vs BCNF algorithms.",
        tags="Normalization, BCNF, Functional Dependencies"
    )
    m2 = StudyMaterial(
        faculty_id=faculty.id,
        unit_id=unit2.id,
        title="B+ Tree Visualization & Query Cost Cheat Sheet",
        material_type="REFERENCE_LINK",
        file_url="https://www.cs.usfca.edu/~galles/visualization/BPlusTree.html",
        description="Interactive simulator for B+ Tree node insertions, deletions, and root splits.",
        tags="Indexing, B+ Tree, Query Optimizer"
    )
    m3 = StudyMaterial(
        faculty_id=faculty.id,
        unit_id=unit3.id,
        title="Transaction Management & Strict 2PL Protocol Slides",
        material_type="SLIDES",
        file_url="https://inst.eecs.berkeley.edu/~cs186/sp23/assets/lecture/lec19-transactions.pdf",
        description="Berkeley CS186 slides on Serializability graphs, Strict 2PL, and Write-Ahead Logging (WAL/ARIES).",
        tags="Transactions, 2PL, ACID, Concurrency"
    )
    db.add_all([m1, m2, m3])

    # 6. Past Test Attempt for Student
    attempt = TestAttempt(
        student_id=student.id,
        paper_id=paper1.id,
        start_time=datetime.utcnow() - timedelta(hours=2),
        submission_time=datetime.utcnow() - timedelta(hours=1, minutes=35),
        status="GRADED",
        total_score=8.0,
        max_possible_score=10.0,
        percentage=80.0,
        time_taken_seconds=1500
    )
    db.add(attempt)
    db.flush()

    ans1 = StudentAnswer(
        attempt_id=attempt.id,
        question_id=q1.id,
        selected_option="D",
        is_correct=True,
        awarded_marks=2.0,
        faculty_or_ai_feedback="Accurate analysis of candidate keys."
    )
    ans2 = StudentAnswer(
        attempt_id=attempt.id,
        question_id=q2.id,
        selected_option="A",
        is_correct=True,
        awarded_marks=2.0,
        faculty_or_ai_feedback="Correct B+ tree branch bound identified."
    )
    ans3 = StudentAnswer(
        attempt_id=attempt.id,
        question_id=q3.id,
        selected_option="B",
        is_correct=True,
        awarded_marks=2.0,
        faculty_or_ai_feedback="Strict 2PL prevents cascading rollbacks."
    )
    ans4 = StudentAnswer(
        attempt_id=attempt.id,
        question_id=q4.id,
        selected_option="A", # incorrect
        is_correct=False,
        awarded_marks=0.0,
        faculty_or_ai_feedback="Incorrect. Smaller relation must be in the outer loop to minimize I/O block transfers."
    )
    ans5 = StudentAnswer(
        attempt_id=attempt.id,
        question_id=q5.id,
        selected_option="B",
        is_correct=True,
        awarded_marks=2.0,
        faculty_or_ai_feedback="Wait-Die younger transaction abort condition accurately applied."
    )
    db.add_all([ans1, ans2, ans3, ans4, ans5])

    # 7. Topic Mastery Summaries
    perf1 = PerformanceSummary(
        student_id=student.id,
        subject_code="CS301",
        topic_name="Functional Dependencies & 3NF/BCNF",
        total_questions_attempted=4,
        total_questions_correct=4,
        mastery_percentage=100.0
    )
    perf2 = PerformanceSummary(
        student_id=student.id,
        subject_code="CS301",
        topic_name="ACID Properties & Conflict Serializability",
        total_questions_attempted=5,
        total_questions_correct=4,
        mastery_percentage=80.0
    )
    perf3 = PerformanceSummary(
        student_id=student.id,
        subject_code="CS301",
        topic_name="Query Execution Plans & Cost Estimation",
        total_questions_attempted=3,
        total_questions_correct=1,
        mastery_percentage=33.33
    )
    db.add_all([perf1, perf2, perf3])

    db.commit()
    db.close()
    print("Seed data successfully inserted into database!")

if __name__ == "__main__":
    seed_database()
