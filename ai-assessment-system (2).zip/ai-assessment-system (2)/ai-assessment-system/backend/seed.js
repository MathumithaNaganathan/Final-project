module.exports = require('./seed/seed'); if (require.main === module) { require('./seed/seed'); }
