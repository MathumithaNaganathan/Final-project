-- ==============================================================================
-- AI QUESTION PAPER GENERATOR & STUDENT ASSESSMENT SYSTEM - DATABASE SCHEMA (SQL)
-- Engine: PostgreSQL 14+ / SQLite 3 Compatible DDL
-- ==============================================================================

-- 1. USERS & ROLES TABLE
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('FACULTY', 'STUDENT', 'ADMIN')),
    department VARCHAR(100) DEFAULT 'Computer Science',
    profile_bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- 2. SYLLABUS MANAGEMENT (UNITS & TOPICS)
CREATE TABLE IF NOT EXISTS syllabus_units (
    id VARCHAR(36) PRIMARY KEY,
    faculty_id VARCHAR(36) NOT NULL,
    subject_code VARCHAR(50) NOT NULL,
    subject_name VARCHAR(150) NOT NULL,
    unit_number INT NOT NULL,
    unit_title VARCHAR(200) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (faculty_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS syllabus_topics (
    id VARCHAR(36) PRIMARY KEY,
    unit_id VARCHAR(36) NOT NULL,
    topic_name VARCHAR(200) NOT NULL,
    learning_objectives TEXT,
    bloom_taxonomy_level VARCHAR(50) DEFAULT 'Understand', -- Remember, Understand, Apply, Analyze, Evaluate, Create
    weightage_percentage INT DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (unit_id) REFERENCES syllabus_units(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_syllabus_subject ON syllabus_units(subject_code);
CREATE INDEX IF NOT EXISTS idx_topics_unit ON syllabus_topics(unit_id);

-- 3. QUESTION PAPERS TABLE
CREATE TABLE IF NOT EXISTS question_papers (
    id VARCHAR(36) PRIMARY KEY,
    faculty_id VARCHAR(36) NOT NULL,
    subject_code VARCHAR(50) NOT NULL,
    subject_name VARCHAR(150) NOT NULL,
    title VARCHAR(255) NOT NULL,
    paper_set VARCHAR(10) DEFAULT 'A', -- 'A', 'B', 'C'
    exam_duration_mins INT NOT NULL DEFAULT 60,
    total_marks INT NOT NULL DEFAULT 100,
    difficulty_level VARCHAR(30) DEFAULT 'Medium', -- Easy, Medium, Hard, Balanced
    instructions TEXT,
    is_published BOOLEAN DEFAULT 0,
    ai_prompt_meta TEXT, -- Stores generation parameters, temperature, prompt metadata as JSON
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (faculty_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_papers_subject ON question_papers(subject_code);
CREATE INDEX IF NOT EXISTS idx_papers_published ON question_papers(is_published);

-- 4. QUESTIONS TABLE (Linked to Paper & Topic)
CREATE TABLE IF NOT EXISTS questions (
    id VARCHAR(36) PRIMARY KEY,
    paper_id VARCHAR(36) NOT NULL,
    topic_id VARCHAR(36),
    question_order INT NOT NULL DEFAULT 1,
    question_type VARCHAR(30) NOT NULL CHECK (question_type IN ('MCQ', 'SHORT_ANSWER', 'LONG_ANSWER', 'NUMERICAL', 'CASE_STUDY')),
    question_text TEXT NOT NULL,
    options TEXT, -- JSON string of array e.g. [{"id": "A", "text": "..."}, {"id": "B", "text": "..."}] for MCQs
    correct_answer TEXT, -- Option ID (e.g. 'A') or model answer / rubric
    explanation TEXT, -- Detailed explanation / step-by-step resolution
    marks INT NOT NULL DEFAULT 1,
    bloom_level VARCHAR(50) DEFAULT 'Understand',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (paper_id) REFERENCES question_papers(id) ON DELETE CASCADE,
    FOREIGN KEY (topic_id) REFERENCES syllabus_topics(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_questions_paper ON questions(paper_id);
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(question_type);

-- 5. STUDY MATERIALS REPOSITORY
CREATE TABLE IF NOT EXISTS study_materials (
    id VARCHAR(36) PRIMARY KEY,
    faculty_id VARCHAR(36) NOT NULL,
    unit_id VARCHAR(36),
    title VARCHAR(255) NOT NULL,
    material_type VARCHAR(50) NOT NULL CHECK (material_type IN ('PDF_NOTE', 'REFERENCE_LINK', 'SLIDES', 'SAMPLE_PAPER')),
    file_url TEXT NOT NULL,
    description TEXT,
    tags VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (faculty_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (unit_id) REFERENCES syllabus_units(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_study_materials_faculty ON study_materials(faculty_id);
CREATE INDEX IF NOT EXISTS idx_study_materials_unit ON study_materials(unit_id);

-- 6. STUDENT TEST ATTEMPTS
CREATE TABLE IF NOT EXISTS test_attempts (
    id VARCHAR(36) PRIMARY KEY,
    student_id VARCHAR(36) NOT NULL,
    paper_id VARCHAR(36) NOT NULL,
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    submission_time TIMESTAMP,
    status VARCHAR(30) DEFAULT 'IN_PROGRESS' CHECK (status IN ('IN_PROGRESS', 'SUBMITTED', 'GRADED', 'TIMED_OUT')),
    total_score REAL DEFAULT 0.00,
    max_possible_score REAL DEFAULT 0.00,
    percentage REAL DEFAULT 0.00,
    time_taken_seconds INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (paper_id) REFERENCES question_papers(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_attempts_student ON test_attempts(student_id);
CREATE INDEX IF NOT EXISTS idx_attempts_paper ON test_attempts(paper_id);

-- 7. STUDENT INDIVIDUAL ANSWERS (Per Question per Attempt)
CREATE TABLE IF NOT EXISTS student_answers (
    id VARCHAR(36) PRIMARY KEY,
    attempt_id VARCHAR(36) NOT NULL,
    question_id VARCHAR(36) NOT NULL,
    selected_option TEXT,
    text_response TEXT,
    is_correct BOOLEAN DEFAULT 0,
    awarded_marks REAL DEFAULT 0.00,
    faculty_or_ai_feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (attempt_id) REFERENCES test_attempts(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_answers_attempt ON student_answers(attempt_id);
CREATE INDEX IF NOT EXISTS idx_answers_question ON student_answers(question_id);

-- 8. STUDENT PERFORMANCE & TOPIC MASTERY (ANALYTICS CACHE / SUMMARY)
CREATE TABLE IF NOT EXISTS performance_summaries (
    id VARCHAR(36) PRIMARY KEY,
    student_id VARCHAR(36) NOT NULL,
    subject_code VARCHAR(50) NOT NULL,
    topic_name VARCHAR(200) NOT NULL,
    total_questions_attempted INT DEFAULT 0,
    total_questions_correct INT DEFAULT 0,
    mastery_percentage REAL DEFAULT 0.00,
    last_evaluated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_perf_student_subject ON performance_summaries(student_id, subject_code);
