const fs = require('fs');

async function runComprehensiveTests() {
  console.log('====================================================');
  console.log('TEST SUITE: STUDENT & FACULTY PROFILE EDITING');
  console.log('====================================================');

  console.log('\n--- 1. VERIFYING HTML STRUCTURE ACROSS ALL PAGES ---');
  const files = [
    { name: 'student/profile.html', path: './frontend/student/profile.html', role: 'student' },
    { name: 'faculty/profile.html', path: './frontend/faculty/profile.html', role: 'faculty' },
    { name: 'student/index.html (Dashboard Profile Tab)', path: './frontend/student/index.html', role: 'student' },
    { name: 'faculty/index.html (Dashboard Profile Tab)', path: './frontend/faculty/index.html', role: 'faculty' }
  ];

  for (const f of files) {
    const html = fs.readFileSync(f.path, 'utf8');

    // Count edit buttons
    const editCount = (html.match(/id=["']editProfileBtn["']/g) || []).length;
    const saveCount = (html.match(/id=["']saveProfileBtn["']/g) || []).length;
    const cancelCount = (html.match(/id=["']cancelProfileBtn["']/g) || []).length;

    console.log(`[HTML Check] ${f.name}: editBtn=${editCount}, saveBtn=${saveCount}, cancelBtn=${cancelCount}`);
    if (editCount !== 1) throw new Error(`${f.name} must have exactly one id="editProfileBtn", found ${editCount}`);
    if (saveCount !== 1) throw new Error(`${f.name} must have exactly one id="saveProfileBtn", found ${saveCount}`);
    if (cancelCount !== 1) throw new Error(`${f.name} must have exactly one id="cancelProfileBtn", found ${cancelCount}`);

    // Verify edit button is not hidden/disabled on load
    const editTagMatch = html.match(/<button[^>]*id=["']editProfileBtn["'][^>]*>/i);
    if (!editTagMatch) throw new Error(`${f.name} missing editProfileBtn`);
    const editTag = editTagMatch[0];
    if (editTag.includes('disabled')) throw new Error(`${f.name} editProfileBtn has disabled attribute`);
    if (editTag.includes('hidden')) throw new Error(`${f.name} editProfileBtn has hidden attribute`);
    if (editTag.includes('display:none') || editTag.includes('display: none')) throw new Error(`${f.name} editProfileBtn has display:none`);
    console.log(`[HTML Check] ${f.name} editProfileBtn is clean and visible.`);

    // Verify photo preview and upload elements exist
    if (!html.includes('profilePhotoInput')) throw new Error(`${f.name} missing profilePhotoInput`);
    if (!html.includes('changePhotoBtn')) throw new Error(`${f.name} missing changePhotoBtn`);
  }

  console.log('\n--- 2. STUDENT AUTHENTICATION & FULL PROFILE EDIT IN MONGODB ---');
  // Student Login
  const sLogin = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'student', password: 'student123' })
  }).then(r => r.json());

  if (!sLogin.success || !sLogin.token) throw new Error('Student login failed');
  console.log('✓ Student logged in successfully. Token generated.');

  // Check initial Student profile
  const sInitGet = await fetch('http://localhost:5000/api/student/profile', {
    headers: { 'Authorization': 'Bearer ' + sLogin.token }
  }).then(r => r.json());
  console.log('✓ Initial Student Profile retrieved:', {
    name: sInitGet.user.name,
    email: sInitGet.user.email,
    registerNo: sInitGet.user.registerNo,
    department: sInitGet.user.department,
    semester: sInitGet.user.semester
  });

  // Edit Student Profile with ALL fields
  const mockBase64Photo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  const studentUpdatePayload = {
    fullName: 'Anand Kumar V',
    email: 'anand.cs.student@college.edu',
    phone: '9843299881',
    dob: '2004-11-25',
    gender: 'Male',
    department: 'B.Sc Computer Science',
    semester: 3,
    address: '45, Anna Nagar 2nd Street, Madurai - 625020',
    profilePhoto: mockBase64Photo
  };

  const sPutRes = await fetch('http://localhost:5000/api/student/profile', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + sLogin.token
    },
    body: JSON.stringify(studentUpdatePayload)
  });
  const sPut = await sPutRes.json();
  console.log('✓ Student Update PUT status:', sPutRes.status, 'Message:', sPut.message);
  if (!sPut.success) throw new Error('Student update failed: ' + JSON.stringify(sPut));
  if (sPut.message !== 'Profile updated successfully.') {
    throw new Error(`Expected "Profile updated successfully.", got "${sPut.message}"`);
  }

  // Verify MongoDB Persistence by logging in again & fetching
  const sReLogin = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'student', password: 'student123' })
  }).then(r => r.json());

  const sVerifiedGet = await fetch('http://localhost:5000/api/student/profile', {
    headers: { 'Authorization': 'Bearer ' + sReLogin.token }
  }).then(r => r.json());

  console.log('✓ Verified Student Profile from MongoDB after Re-login:');
  console.log('  - Full Name:', sVerifiedGet.user.name);
  console.log('  - Email:', sVerifiedGet.user.email);
  console.log('  - Phone:', sVerifiedGet.user.phone);
  console.log('  - Date of Birth:', sVerifiedGet.user.dob);
  console.log('  - Gender:', sVerifiedGet.user.gender);
  console.log('  - Department:', sVerifiedGet.user.department);
  console.log('  - Semester:', sVerifiedGet.user.semester);
  console.log('  - Address:', sVerifiedGet.user.address);
  console.log('  - Photo length:', sVerifiedGet.user.profilePhoto ? sVerifiedGet.user.profilePhoto.length : 0);
  console.log('  - Register No (locked):', sVerifiedGet.user.registerNo);

  if (sVerifiedGet.user.name !== 'Anand Kumar V') throw new Error('Name mismatch in DB');
  if (sVerifiedGet.user.email !== 'anand.cs.student@college.edu') throw new Error('Email mismatch in DB');
  if (sVerifiedGet.user.phone !== '9843299881') throw new Error('Phone mismatch in DB');
  if (sVerifiedGet.user.semester !== 3) throw new Error('Semester mismatch in DB');
  if (sVerifiedGet.user.dob !== '2004-11-25') throw new Error('DoB mismatch in DB');
  if (sVerifiedGet.user.address !== '45, Anna Nagar 2nd Street, Madurai - 625020') throw new Error('Address mismatch in DB');
  if (!sVerifiedGet.user.profilePhoto || !sVerifiedGet.user.profilePhoto.startsWith('data:image/')) throw new Error('Photo mismatch in DB');
  if (sVerifiedGet.user.registerNo !== 'student') throw new Error('Register number was compromised!');

  console.log('\n--- 3. FACULTY AUTHENTICATION & FULL PROFILE EDIT IN MONGODB ---');
  // Faculty Login
  const fLogin = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'faculty', password: 'faculty123' })
  }).then(r => r.json());

  if (!fLogin.success || !fLogin.token) throw new Error('Faculty login failed');
  console.log('✓ Faculty logged in successfully. Token generated.');

  // Edit Faculty Profile with ALL fields
  const facultyUpdatePayload = {
    fullName: 'Dr. Rajesh Sharma M.Sc., Ph.D.',
    email: 'dr.sharma.cs@college.edu',
    phone: '9876500112',
    dob: '1980-03-22',
    gender: 'Male',
    department: 'B.Sc Computer Science',
    designation: 'Professor & Research Supervisor',
    qualification: 'M.Sc., M.Phil., Ph.D., PostDoc',
    address: 'Staff Quarters, Block B-4, Thiagarajar College Campus, Madurai - 625009',
    profilePhoto: mockBase64Photo
  };

  const fPutRes = await fetch('http://localhost:5000/api/faculty/profile', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + fLogin.token
    },
    body: JSON.stringify(facultyUpdatePayload)
  });
  const fPut = await fPutRes.json();
  console.log('✓ Faculty Update PUT status:', fPutRes.status, 'Message:', fPut.message);
  if (!fPut.success) throw new Error('Faculty update failed: ' + JSON.stringify(fPut));
  if (fPut.message !== 'Profile updated successfully.') {
    throw new Error(`Expected "Profile updated successfully.", got "${fPut.message}"`);
  }

  // Verify MongoDB Persistence by logging in again & fetching
  const fReLogin = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'faculty', password: 'faculty123' })
  }).then(r => r.json());

  const fVerifiedGet = await fetch('http://localhost:5000/api/faculty/profile', {
    headers: { 'Authorization': 'Bearer ' + fReLogin.token }
  }).then(r => r.json());

  console.log('✓ Verified Faculty Profile from MongoDB after Re-login:');
  console.log('  - Full Name:', fVerifiedGet.user.name);
  console.log('  - Email:', fVerifiedGet.user.email);
  console.log('  - Phone:', fVerifiedGet.user.phone);
  console.log('  - Designation:', fVerifiedGet.user.designation);
  console.log('  - Qualification:', fVerifiedGet.user.qualification);
  console.log('  - Date of Birth:', fVerifiedGet.user.dob);
  console.log('  - Address:', fVerifiedGet.user.address);
  console.log('  - Faculty ID (locked):', fVerifiedGet.user.facultyId);

  if (fVerifiedGet.user.name !== 'Dr. Rajesh Sharma M.Sc., Ph.D.') throw new Error('Faculty Name mismatch in DB');
  if (fVerifiedGet.user.email !== 'dr.sharma.cs@college.edu') throw new Error('Faculty Email mismatch in DB');
  if (fVerifiedGet.user.phone !== '9876500112') throw new Error('Faculty Phone mismatch in DB');
  if (fVerifiedGet.user.designation !== 'Professor & Research Supervisor') throw new Error('Faculty Designation mismatch in DB');
  if (fVerifiedGet.user.qualification !== 'M.Sc., M.Phil., Ph.D., PostDoc') throw new Error('Faculty Qualification mismatch in DB');
  if (fVerifiedGet.user.facultyId !== 'faculty') throw new Error('Faculty ID was compromised!');

  console.log('\n--- 4. SECURITY & VALIDATION ENFORCEMENT ---');
  // Test A: Empty name rejected
  const emptyNameRes = await fetch('http://localhost:5000/api/student/profile', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sLogin.token },
    body: JSON.stringify({ fullName: '', email: 'valid@college.edu' })
  });
  const emptyNameJson = await emptyNameRes.json();
  console.log('✓ Empty name validation check:', emptyNameRes.status, emptyNameJson.message);
  if (emptyNameRes.status !== 400) throw new Error('Expected 400 for empty name');

  // Test B: Invalid email rejected
  const badEmailRes = await fetch('http://localhost:5000/api/student/profile', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sLogin.token },
    body: JSON.stringify({ fullName: 'Valid Name', email: 'notanemail' })
  });
  const badEmailJson = await badEmailRes.json();
  console.log('✓ Invalid email validation check:', badEmailRes.status, badEmailJson.message);
  if (badEmailRes.status !== 400) throw new Error('Expected 400 for invalid email');

  // Test C: Duplicate email collision rejected (Conflict 409)
  const dupEmailRes = await fetch('http://localhost:5000/api/student/profile', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sLogin.token },
    body: JSON.stringify({ fullName: 'Valid Name', email: 'dr.sharma.cs@college.edu' }) // already taken by faculty
  });
  const dupEmailJson = await dupEmailRes.json();
  console.log('✓ Duplicate email conflict check:', dupEmailRes.status, dupEmailJson.message);
  if (dupEmailRes.status !== 409) throw new Error('Expected 409 Conflict for duplicate email');

  // Test D: Cross-role route authorization
  // Student trying to call Faculty PUT
  const crossRoleRes1 = await fetch('http://localhost:5000/api/faculty/profile', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sLogin.token },
    body: JSON.stringify({ fullName: 'Hacker Student', email: 'hacker@college.edu' })
  });
  console.log('✓ Student attempting Faculty update:', crossRoleRes1.status);
  if (crossRoleRes1.status !== 403) throw new Error('Expected 403 Forbidden for cross-role student attempt');

  // Faculty trying to call Student PUT
  const crossRoleRes2 = await fetch('http://localhost:5000/api/student/profile', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + fLogin.token },
    body: JSON.stringify({ fullName: 'Faculty As Student', email: 'fac.stu@college.edu' })
  });
  console.log('✓ Faculty attempting Student update:', crossRoleRes2.status);
  if (crossRoleRes2.status !== 403) throw new Error('Expected 403 Forbidden for cross-role faculty attempt');

  // Test E: Passwords never exposed in GET/PUT responses
  if (sVerifiedGet.user.password || fVerifiedGet.user.password) {
    throw new Error('SECURITY VIOLATION: Password hash exposed in user profile response!');
  }
  console.log('✓ Passwords are never exposed in profile responses.');

  console.log('\n====================================================');
  console.log('ALL VERIFICATION TESTS PASSED SUCCESSFULLY! (100%)');
  console.log('====================================================');
}

runComprehensiveTests().catch(err => {
  console.error('\n❌ TEST FAILED:', err.message);
  process.exit(1);
});
