// Student Module Initialization & Route Guard
window.addEventListener('DOMContentLoaded', async () => {
    loadUserFromStorage();
    if (!currentUser || !currentUser.token) {
        // Enforce RBAC: redirect unauthenticated user to login page
        window.location.replace('../index.html');
        return;
    }
    if (!currentUser.role || currentUser.role.toLowerCase() !== 'student') {
        // Enforce RBAC: redirect faculty attempting to access student to faculty dashboard
        window.location.replace('../faculty/index.html');
        return;
    }
    currentPortal = 'STUDENT';
    updateUserUI();
    await loadInitialData();
    if (typeof switchStudentTab === 'function') {
        switchStudentTab(currentStudentTab || 'dashboard');
    }
});
