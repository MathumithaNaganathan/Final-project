// Robust API Base URL configuration
const API_BASE = (() => {
    const origin = window.location.origin;
    if (!origin || origin === 'null' || origin.startsWith('file:')) {
        return 'http://localhost:5000';
    }
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        if (window.location.port !== '5000') {
            return `http://${window.location.hostname}:5000`;
        }
    } else if (window.location.port && window.location.port !== '5000') {
        return `${window.location.protocol}//${window.location.hostname}:5000`;
    }
    return origin;
})();

// Consistent Semester Normalizer (converts "Semester 1", "Sem 1", "1", 1 -> 1)
function normalizeSemester(sem) {
    if (sem === null || sem === undefined) return 1;
    const match = String(sem).match(/\d+/);
    if (match) {
        const val = parseInt(match[0], 10);
        if (val >= 1 && val <= 6) return val;
    }
    return 1;
}

// HTTP Status Helpers
function isSuccessResponse(res) {
    return res && (res.ok || res.status === 200 || res.status === 201 || res.status === 204 || res.status === 304);
}

async function parseResponseJson(res, endpoint = '') {
    if (!isSuccessResponse(res)) {
        let errorMsg = `HTTP ${res.status} ${res.statusText}`;
        try {
            const errJson = await res.json();
            if (errJson && errJson.message) errorMsg = errJson.message;
        } catch (e) { }
        console.error(`[API Error] ${endpoint || res.url} failed with status ${res.status}:`, errorMsg);
        return { success: false, status: res.status, message: errorMsg, data: null };
    }
    if (res.status === 204) {
        return { success: true, status: 204, data: null };
    }
    try {
        const json = await res.json();
        return json;
    } catch (e) {
        console.error(`[API Parse Error] ${endpoint || res.url} returned invalid JSON:`, e);
        return { success: false, status: res.status, message: 'Invalid JSON response', data: null };
    }
}

// Application State
let currentUser = null;
let currentPortal = 'FACULTY';
let currentFacultyTab = (typeof sessionStorage !== 'undefined' && sessionStorage.getItem('fac_active_tab')) || 'dashboard';
let currentStudentTab = (typeof sessionStorage !== 'undefined' && sessionStorage.getItem('stu_active_tab')) || 'dashboard';
let currentSelectedLoginRole = 'Faculty';

let cachedSyllabusBySem = {};
let currentGeneratedPaper = null;
let activeMCQTest = null;
let testTimerInterval = null;
let testTimeTotal = 0;
let testTimeRemaining = 0;
let studentSelectedAnswers = {};
let latestStudentResult = null;
window._loadedStudentTestHistory = [];

// --- INITIALIZATION ---
window.addEventListener('DOMContentLoaded', async () => {
    initPasswordToggleListener();
    attachProfileFormListeners();
    attachPasswordToggles();
    loadUserFromStorage();

    const isLandingRoleSelection = document.getElementById('roleSelectionScreen');
    const isDedicatedFaculty = window.location.pathname.includes('/faculty');
    const isDedicatedStudent = window.location.pathname.includes('/student');

    if (isLandingRoleSelection) {
        // ALWAYS enforce Authentication-First: show role selection first when on landing/index
        showRoleSelection();
        // Check URL search parameters (e.g. ?role=faculty or ?role=student)
        try {
            const params = new URLSearchParams(window.location.search);
            const reqRole = params.get('role');
            if (reqRole && reqRole.toLowerCase() === 'faculty') {
                showFacultyLoginScreen();
            } else if (reqRole && reqRole.toLowerCase() === 'student') {
                showStudentLoginScreen();
            }
        } catch (e) { }
    } else if (!isDedicatedFaculty && !isDedicatedStudent && currentUser && currentUser.token) {
        showMainPortal();
        updateUserUI();
        await loadInitialData();
    } else if (!isDedicatedFaculty && !isDedicatedStudent) {
        showLandingPage();
    }
});

function loadUserFromStorage() {
    try {
        const stored = localStorage.getItem('cs_portal_user') || localStorage.getItem('currentUser') || localStorage.getItem('user');
        if (stored) {
            currentUser = JSON.parse(stored);
            window.currentUser = currentUser;
        } else if (window.currentUser) {
            currentUser = window.currentUser;
        }
    } catch (e) {
        console.warn('LocalStorage error:', e);
    }
}

function saveUserToStorage() {
    try {
        if (currentUser) {
            window.currentUser = currentUser;
            localStorage.setItem('cs_portal_user', JSON.stringify(currentUser));
        } else {
            window.currentUser = null;
            localStorage.removeItem('cs_portal_user');
        }
    } catch (e) {
        console.warn('LocalStorage save error:', e);
    }
}

function getAuthHeaders(extraHeaders = {}) {

    const headers = { 'Content-Type': 'application/json', ...extraHeaders };

    if (currentUser && currentUser.token) {

        headers['Authorization'] = 'Bearer ' + currentUser.token;

    }

    return headers;

}

// Global safe stub for renderCurrentPortal
function renderCurrentPortal() {
    updateUserUI();
}

function showRoleSelection() {
    const roleScreen = document.getElementById('roleSelectionScreen');
    const facScreen = document.getElementById('facultyLoginScreen');
    const stuScreen = document.getElementById('studentLoginScreen');
    const landing = document.getElementById('landingLoginView');
    const main = document.getElementById('mainPortalApp');

    if (landing) landing.classList.remove('hidden');
    if (main) main.classList.add('hidden');
    if (roleScreen) roleScreen.classList.remove('hidden');
    if (facScreen) facScreen.classList.add('hidden');
    if (stuScreen) stuScreen.classList.add('hidden');

    const fU = document.getElementById('facultyUsername');
    const fP = document.getElementById('facultyPassword');
    const sU = document.getElementById('studentUsername');
    const sP = document.getElementById('studentPassword');
    if (fU) fU.value = '';
    if (fP) fP.value = '';
    if (sU) sU.value = '';
    if (sP) sP.value = '';
    resetFieldPassword('facultyPassword', 'facultyTogglePasswordBtn');
    resetFieldPassword('studentPassword', 'studentTogglePasswordBtn');
    closeLoginModal();
}

function showFacultyLoginScreen() {
    const roleScreen = document.getElementById('roleSelectionScreen');
    const facScreen = document.getElementById('facultyLoginScreen');
    const stuScreen = document.getElementById('studentLoginScreen');

    if (roleScreen) roleScreen.classList.add('hidden');
    if (facScreen) facScreen.classList.remove('hidden');
    if (stuScreen) stuScreen.classList.add('hidden');

    resetFieldPassword('facultyPassword', 'facultyTogglePasswordBtn');
    const fU = document.getElementById('facultyUsername');
    if (fU) setTimeout(() => fU.focus(), 60);
}

function showStudentLoginScreen() {
    const roleScreen = document.getElementById('roleSelectionScreen');
    const facScreen = document.getElementById('facultyLoginScreen');
    const stuScreen = document.getElementById('studentLoginScreen');

    if (roleScreen) roleScreen.classList.add('hidden');
    if (facScreen) facScreen.classList.add('hidden');
    if (stuScreen) stuScreen.classList.remove('hidden');

    resetFieldPassword('studentPassword', 'studentTogglePasswordBtn');
    const sU = document.getElementById('studentUsername');
    if (sU) setTimeout(() => sU.focus(), 60);
}

function toggleFieldPassword(inputId, btnEl) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const isPass = input.getAttribute('type') === 'password';
    input.setAttribute('type', isPass ? 'text' : 'password');
    if (btnEl) {
        btnEl.setAttribute('aria-label', isPass ? 'Hide password' : 'Show password');
        if (isPass) {
            btnEl.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                </svg>`;
        } else {
            btnEl.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                </svg>`;
        }
    }
}

function resetFieldPassword(inputId, btnId) {
    const input = document.getElementById(inputId);
    const btn = typeof btnId === 'string' ? document.getElementById(btnId) : btnId;
    if (input && input.getAttribute('type') !== 'password') {
        input.setAttribute('type', 'password');
        if (btn) {
            btn.setAttribute('aria-label', 'Toggle password visibility');
            btn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                </svg>`;
        }
    }
}

function showLandingPage() {
    showRoleSelection();
}

function showMainPortal() {
    const landing = document.getElementById('landingLoginView');
    const main = document.getElementById('mainPortalApp');
    if (landing) landing.classList.add('hidden');
    if (main) main.classList.remove('hidden');
}

function selectLoginRole(role) {
    currentSelectedLoginRole = role;
    const btnFac = document.getElementById('roleBtnFaculty');
    const btnStu = document.getElementById('roleBtnStudent');
    const roleTitle = document.getElementById('loginRoleTitle');
    const usernameInput = document.getElementById('landingUsername');
    const passwordInput = document.getElementById('password') || document.getElementById('landingPassword');
    const modalTitle = document.getElementById('loginModalTitle');
    const modalSubtitle = document.getElementById('loginModalSubtitle');
    const modalIcon = document.getElementById('modalRoleIcon');
    const banner = document.getElementById('loginRoleBanner');

    if (role === 'Faculty') {
        if (btnFac) btnFac.className = 'flex-1 py-2 rounded-xl transition-all flex items-center justify-center space-x-1.5 bg-white text-indigo-600 shadow-sm font-bold';
        if (btnStu) btnStu.className = 'flex-1 py-2 rounded-xl transition-all flex items-center justify-center space-x-1.5 text-slate-600 hover:text-slate-900 font-semibold';
        if (roleTitle) roleTitle.innerHTML = '<i class="fa-solid fa-shield-halved text-indigo-600 mr-1.5"></i><span>Faculty Sign-In (Autonomous Exam Cell)</span>';
        if (modalTitle) modalTitle.innerText = 'Faculty Sign-In';
        if (modalSubtitle) modalSubtitle.innerText = 'Autonomous Examination Cell & Curriculum Controller';
        if (modalIcon) {
            modalIcon.className = 'w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-lg';
            modalIcon.innerHTML = '<i class="fa-solid fa-chalkboard-user"></i>';
        }
        if (banner) banner.className = 'p-3 bg-indigo-50 rounded-xl border border-indigo-100 flex items-center justify-between text-xs';
    } else {
        if (btnStu) btnStu.className = 'flex-1 py-2 rounded-xl transition-all flex items-center justify-center space-x-1.5 bg-white text-violet-600 shadow-sm font-bold';
        if (btnFac) btnFac.className = 'flex-1 py-2 rounded-xl transition-all flex items-center justify-center space-x-1.5 text-slate-600 hover:text-slate-900 font-semibold';
        if (roleTitle) roleTitle.innerHTML = '<i class="fa-solid fa-user-graduate text-purple-600 mr-1.5"></i><span>Student Sign-In (B.Sc Learning Hub)</span>';
        if (modalTitle) modalTitle.innerText = 'Student Sign-In';
        if (modalSubtitle) modalSubtitle.innerText = 'Student Learning & Assessment Hub';
        if (modalIcon) {
            modalIcon.className = 'w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-lg';
            modalIcon.innerHTML = '<i class="fa-solid fa-user-graduate"></i>';
        }
        if (banner) banner.className = 'p-3 bg-purple-50 rounded-xl border border-purple-100 flex items-center justify-between text-xs';
    }
}

function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password') || document.getElementById('landingPassword');
    const eyeBtn = document.getElementById('togglePasswordBtn');
    const eyeIcon = document.getElementById('eyeIcon');
    if (!passwordInput) return;

    const isCurrentlyPassword = passwordInput.getAttribute('type') === 'password';
    if (isCurrentlyPassword) {
        passwordInput.setAttribute('type', 'text');
        if (eyeIcon) {
            eyeIcon.innerHTML = `
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                <circle cx="12" cy="12" r="3"></circle>
            `;
        }
        if (eyeBtn) eyeBtn.setAttribute('aria-label', 'Hide password');
    } else {
        passwordInput.setAttribute('type', 'password');
        if (eyeIcon) {
            eyeIcon.innerHTML = `
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                <line x1="1" y1="1" x2="23" y2="23"></line>
            `;
        }
        if (eyeBtn) eyeBtn.setAttribute('aria-label', 'Show password');
    }
}

function resetPasswordVisibility() {
    const passwordInput = document.getElementById('password') || document.getElementById('landingPassword');
    const eyeBtn = document.getElementById('togglePasswordBtn');
    const eyeIcon = document.getElementById('eyeIcon');
    if (passwordInput && passwordInput.getAttribute('type') !== 'password') {
        passwordInput.setAttribute('type', 'password');
        if (eyeIcon) {
            eyeIcon.innerHTML = `
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                <line x1="1" y1="1" x2="23" y2="23"></line>
            `;
        }
        if (eyeBtn) eyeBtn.setAttribute('aria-label', 'Toggle password visibility');
    }
}

function initPasswordToggleListener() {
    const eyeBtn = document.getElementById('togglePasswordBtn');
    if (eyeBtn && !eyeBtn._hasToggleListener) {
        eyeBtn._hasToggleListener = true;
        eyeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            togglePasswordVisibility();
        });
    }
}

function openLoginModal(role) {
    if (role) {
        selectLoginRole(role);
    }
    const usernameInput = document.getElementById('landingUsername');
    const passwordInput = document.getElementById('password') || document.getElementById('landingPassword');
    if (usernameInput) usernameInput.value = '';
    if (passwordInput) passwordInput.value = '';
    resetPasswordVisibility();

    const modal = document.getElementById('loginFormModal');
    if (modal) {
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
    }
    if (usernameInput) {
        setTimeout(() => usernameInput.focus(), 60);
    }
}

function closeLoginModal() {
    const modal = document.getElementById('loginFormModal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }
    const usernameInput = document.getElementById('landingUsername');
    const passwordInput = document.getElementById('password') || document.getElementById('landingPassword');
    if (usernameInput) usernameInput.value = '';
    if (passwordInput) passwordInput.value = '';
    resetPasswordVisibility();
}

function selectAndFocusLogin(role) {
    openLoginModal(role);
}

// Close modal on Escape key press
window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeLoginModal();
    }
});

// Attach password toggle listener on page load
window.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.getElementById('togglePasswordBtn');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            togglePasswordVisibility();
        });
    }
});

function autoFillDemoCredentials() {
    // Demo autofill disabled in production
}

async function handleFacultyLogin(e) {
    if (e && e.preventDefault) e.preventDefault();
    const btn = document.getElementById('btnFacultyLoginSubmit');
    const usernameInput = document.getElementById('facultyUsername');
    const passwordInput = document.getElementById('facultyPassword');
    const username = usernameInput ? usernameInput.value.trim() : '';
    const password = passwordInput ? passwordInput.value.trim() : '';

    if (!username || !password) {
        showToast('Please enter both faculty email/username and password', true);
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Authenticating...';
    }

    try {
        const res = await fetch(API_BASE + '/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (data.success) {
            // Strict role guard: Ensure user has Faculty role
            if (data.user && data.user.role && data.user.role.toLowerCase() !== 'faculty') {
                showToast('Access Denied: This account is registered as Student. Please use Student Login.', true);
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<span>Faculty Login</span> <i class="fa-solid fa-arrow-right ml-2"></i>';
                }
                return;
            }
            currentUser = { ...data.user, token: data.token, role: 'Faculty' };
            saveUserToStorage();
            showToast('Welcome ' + (currentUser.name || 'Faculty'));
            // Redirect to dedicated Faculty Dashboard
            const isSubdir = window.location.pathname.includes('/faculty') || window.location.pathname.includes('/student');
            const targetUrl = isSubdir ? '../faculty/index.html' : 'faculty/index.html';
            window.location.replace(targetUrl);
        } else {
            showToast(data.message || 'Faculty login failed. Check credentials.', true);
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<span>Faculty Login</span> <i class="fa-solid fa-arrow-right ml-2"></i>';
            }
        }
    } catch (err) {
        console.warn('API error, falling back to offline faculty session:', err);
        currentUser = {
            _id: 'faculty_offline_id',
            name: 'Dr. Rajesh Sharma',
            username: username || 'faculty',
            email: username.includes('@') ? username : 'faculty@college.edu',
            role: 'Faculty',
            department: 'B.Sc Computer Science',
            semester: 1,
            token: 'offline_faculty_token_' + Date.now()
        };
        saveUserToStorage();
        showToast('Signed in as Faculty (Offline Mode)');
        const isSubdir = window.location.pathname.includes('/faculty') || window.location.pathname.includes('/student');
        const targetUrl = isSubdir ? '../faculty/index.html' : 'faculty/index.html';
        window.location.replace(targetUrl);
    }
}

async function handleStudentLogin(e) {
    if (e && e.preventDefault) e.preventDefault();
    const btn = document.getElementById('btnStudentLoginSubmit');
    const usernameInput = document.getElementById('studentUsername');
    const passwordInput = document.getElementById('studentPassword');
    const username = usernameInput ? usernameInput.value.trim() : '';
    const password = passwordInput ? passwordInput.value.trim() : '';

    if (!username || !password) {
        showToast('Please enter both student email/register no. and password', true);
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Authenticating...';
    }

    try {
        const res = await fetch(API_BASE + '/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (data.success) {
            // Strict role guard: Ensure user has Student role
            if (data.user && data.user.role && data.user.role.toLowerCase() !== 'student') {
                showToast('Access Denied: This account is registered as Faculty. Please use Faculty Login.', true);
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<span>Student Login</span> <i class="fa-solid fa-arrow-right ml-2"></i>';
                }
                return;
            }
            currentUser = { ...data.user, token: data.token, role: 'Student' };
            saveUserToStorage();
            showToast('Welcome ' + (currentUser.name || 'Student'));
            // Redirect to dedicated Student Dashboard
            const isSubdir = window.location.pathname.includes('/faculty') || window.location.pathname.includes('/student');
            const targetUrl = isSubdir ? '../student/index.html' : 'student/index.html';
            window.location.replace(targetUrl);
        } else {
            showToast(data.message || 'Student login failed. Check credentials.', true);
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<span>Student Login</span> <i class="fa-solid fa-arrow-right ml-2"></i>';
            }
        }
    } catch (err) {
        console.warn('API error, falling back to offline student session:', err);
        currentUser = {
            _id: 'student_offline_id',
            name: 'Anand Kumar',
            username: username || 'student',
            email: username.includes('@') ? username : 'student@college.edu',
            role: 'Student',
            department: 'B.Sc Computer Science',
            semester: 1,
            token: 'offline_student_token_' + Date.now()
        };
        saveUserToStorage();
        showToast('Signed in as Student (Offline Mode)');
        const isSubdir = window.location.pathname.includes('/faculty') || window.location.pathname.includes('/student');
        const targetUrl = isSubdir ? '../student/index.html' : 'student/index.html';
        window.location.replace(targetUrl);
    }
}

function logoutUser(e) {
    if (e && e.preventDefault) e.preventDefault();
    currentUser = null;
    try {
        localStorage.removeItem('cs_portal_user');
        sessionStorage.clear();
    } catch (err) {
        console.warn('Logout storage clear error:', err);
    }
    const isSubdir = window.location.pathname.includes('/faculty') || window.location.pathname.includes('/student');
    const targetUrl = isSubdir ? '../index.html' : 'index.html';
    window.location.replace(targetUrl);
}

function returnToLandingPage() {
    logoutUser();
}

async function handleLandingLogin(e) {
    if (currentSelectedLoginRole === 'Faculty') {
        return handleFacultyLogin(e);
    } else {
        return handleStudentLogin(e);
    }
}

async function quickLogin(username, password) {
    try {
        const res = await fetch(API_BASE + '/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (data.success) {
            currentUser = { ...data.user, token: data.token };
            saveUserToStorage();
            closeLoginModal();
            showMainPortal();
            updateUserUI();
            await loadInitialData();
            showToast('Logged in as ' + currentUser.name + ' (' + currentUser.role + ')');
            if (currentUser.role === 'Faculty') switchPortal('FACULTY');
            else switchPortal('STUDENT');
        } else {
            showToast(data.message || 'Login failed', true);
        }
    } catch (err) {
        console.error('QuickLogin error:', err);
        showToast('Server connection failed! Please ensure backend is running (run_app.bat).', true);
    }
}

function getInitials(name) {
    if (!name) return 'U';
    const parts = name.trim().split(/\s+/).filter(Boolean);
    const cleaned = parts.filter(p => !['dr.', 'dr', 'prof.', 'prof', 'mr.', 'mr', 'mrs.', 'mrs', 'ms.', 'ms'].includes(p.toLowerCase()));
    const words = cleaned.length >= 2 ? cleaned : parts;
    if (words.length >= 2) {
        return (words[0][0] + words[1][0]).toUpperCase();
    }
    return (words[0] ? words[0].slice(0, 2) : 'U').toUpperCase();
}

function updateUserUI() {
    if (!currentUser) return;

    const displayName = (currentUser.name || 'User').trim();
    const initials = getInitials(displayName);

    const roleName = currentUser.role || 'Student';
    const deptName = currentUser.department || 'B.Sc CS';

    // 1. Instantly update ALL top navbar avatars across the DOM
    const avatars = document.querySelectorAll('#userAvatar, .nav-user-avatar, [data-user-avatar]');
    avatars.forEach(avatar => {
        avatar.innerText = initials;
    });

    // 2. Instantly update ALL top navbar user names across the DOM
    const nameEls = document.querySelectorAll('#userName, .nav-user-name, [data-user-name]');
    nameEls.forEach(el => {
        el.innerText = displayName;
    });

    // 3. Instantly update ALL role badges
    const badgeEls = document.querySelectorAll('#userRoleBadge, .nav-user-badge, [data-user-role]');
    badgeEls.forEach(badge => {
        badge.innerText = roleName + ' (' + deptName + ')';
    });

    // 4. Update Profile Page Specific Header elements if present
    const isFaculty = roleName.toLowerCase() === 'faculty';
    const prefix = isFaculty ? 'fac' : 'stu';

    // Instantly update dedicated header greetings
    const facGreeting = document.getElementById('facultyGreeting');
    if (facGreeting) facGreeting.innerText = 'Welcome, ' + displayName;
    const stuGreeting = document.getElementById('studentGreeting');
    if (stuGreeting) stuGreeting.innerText = 'Welcome, ' + displayName;

    const headerName = document.getElementById(prefix + 'ProfileHeaderName') || document.getElementById('profileHeaderName');
    if (headerName) headerName.innerText = displayName;

    const headerRole = document.getElementById(prefix + 'ProfileHeaderRole') || document.getElementById('profileHeaderRole');
    if (headerRole) headerRole.innerText = (isFaculty ? 'Department of Computer Science • Faculty Member' : 'B.Sc Computer Science • Student');

    const headerUsername = document.getElementById(prefix + 'ProfileHeaderUsername') || document.getElementById('profileHeaderUsername');
    if (headerUsername) headerUsername.innerText = '@' + (currentUser.username || (isFaculty ? 'faculty' : 'student'));

    const avatarLarge = document.getElementById(prefix + 'ProfileAvatarLarge') || document.getElementById('profileAvatarLarge');
    if (avatarLarge) avatarLarge.innerText = initials;

    // Strict role enforcement: Students can never see Faculty Portal
    if (document.getElementById('facultyPortal') || document.getElementById('studentPortal')) {
        if (currentUser.role === 'Student') {
            if (typeof switchPortal === 'function') switchPortal('STUDENT');
        } else {
            if (typeof switchPortal === 'function') switchPortal('FACULTY');
        }
    }
}

async function loadInitialData() {
    initSectionBreakdownUI();
    await Promise.allSettled([
        loadFacultyStats(),
        loadSavedPapersArchive(),
        populateAllSemesterDropdowns(),
        loadStudentAnalytics()
    ]);
}

// --- PORTAL SWITCHER ---
function switchPortal(portal) {
    if (!currentUser) return;
    // Enforce role separation: Student can NEVER access Faculty Portal
    if (currentUser.role === 'Student') {
        portal = 'STUDENT';
    }
    currentPortal = portal;
    const facSection = document.getElementById('facultyPortal');
    const stuSection = document.getElementById('studentPortal');
    const activeBadge = document.getElementById('activePortalBadge');
    const activeRoleText = document.getElementById('activePortalRoleText');

    if (portal === 'FACULTY') {
        if (facSection) facSection.classList.remove('hidden');
        if (stuSection) stuSection.classList.add('hidden');
        if (activeRoleText) activeRoleText.innerText = 'Faculty Portal';
        if (activeBadge) activeBadge.className = 'px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 font-bold text-xs border border-indigo-200 flex items-center space-x-1.5';
        switchFacultyTab(currentFacultyTab || 'dashboard');
    } else {
        if (facSection) facSection.classList.add('hidden');
        if (stuSection) stuSection.classList.remove('hidden');
        if (activeRoleText) activeRoleText.innerText = 'Student Learning Portal';
        if (activeBadge) activeBadge.className = 'px-3 py-1.5 rounded-xl bg-violet-50 text-violet-700 font-bold text-xs border border-violet-200 flex items-center space-x-1.5';
        switchStudentTab(currentStudentTab || 'dashboard');
    }
}

// --- SUB-NAVIGATION TABS ---
function switchFacultyTab(tab) {
    if (tab === 'batch_generator' || tab === 'ai_generator' || tab === 'ai-generator' || tab === 'qbank' || tab === 'mcq_gen' || tab === 'materials') {
        tab = 'generator';
    }
    currentFacultyTab = tab;
    try { sessionStorage.setItem('fac_active_tab', tab); } catch (e) { }
    // Exactly the 6 views of Faculty portal
    const tabs = ['dashboard', 'generator', 'syllabus', 'papers', 'preview', 'profile'];
    tabs.forEach(t => {
        const btn = document.getElementById('facTab_' + t);
        const view = document.getElementById('facView_' + t);
        if (btn) {
            btn.className = (t === tab)
                ? 'faculty-tab px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-xl text-indigo-600 bg-indigo-50 flex items-center space-x-2 transition-all'
                : 'faculty-tab px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-xl text-slate-600 hover:bg-slate-100 flex items-center space-x-2 transition-all';
        }
        if (view) {
            if (t === tab) view.classList.remove('hidden');
            else view.classList.add('hidden');
        }
    });

    if (tab === 'dashboard') {
        loadFacultyStats();
        loadSavedPapersArchive();
    } else if (tab === 'generator') {
        updateSectionBreakdownPreview();
    } else if (tab === 'papers') {
        loadSavedPapersArchive();
    } else if (tab === 'syllabus') {
        loadSyllabusList();
    } else if (tab === 'preview') {
        renderPaperPreview();
    } else if (tab === 'profile') {
        loadProfileView();
    }
}

function switchStudentTab(tab) {
    currentStudentTab = tab;
    try { sessionStorage.setItem('stu_active_tab', tab); } catch (e) { }
    // Exactly the 7 views of Student portal
    const tabs = ['dashboard', 'test', 'qbank', 'materials', 'syllabus', 'analytics', 'profile'];
    tabs.forEach(t => {
        const btn = document.getElementById('stuTab_' + t);
        const view = document.getElementById('stuView_' + t);
        if (btn) {
            btn.className = (t === tab)
                ? 'student-tab px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-xl text-indigo-600 bg-indigo-50 flex items-center space-x-2 transition-all'
                : 'student-tab px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-xl text-slate-600 hover:bg-slate-100 flex items-center space-x-2 transition-all';
        }
        if (view) {
            if (t === tab) view.classList.remove('hidden');
            else view.classList.add('hidden');
        }
    });

    if (tab === 'dashboard') {
        loadStudentAnalytics();
    } else if (tab === 'test') {
        if (!activeMCQTest) {
            const configCard = document.getElementById('stuTestConfigCard');
            const activeCard = document.getElementById('stuTestActiveContainer');
            const resultCard = document.getElementById('stuTestResultContainer');
            if (configCard) configCard.classList.remove('hidden');
            if (activeCard) activeCard.classList.add('hidden');
            if (resultCard) resultCard.classList.add('hidden');
        }
        const subSelect = document.getElementById('stuTestSubject');
        if (!subSelect || subSelect.options.length <= 1 || !subSelect.value) {
            handleStuTestSemesterChange();
        }
    } else if (tab === 'qbank') {
        const subSelect = document.getElementById('stuQBSubject');
        if (!subSelect || subSelect.options.length <= 1 || !subSelect.value) {
            handleStuQBSemesterChange();
        } else {
            loadStudentQuestionBankList();
        }
    } else if (tab === 'materials') {
        const subSelect = document.getElementById('stuMatSubject');
        if (!subSelect || subSelect.options.length <= 1 || !subSelect.value) {
            handleStuMatSemesterChange();
        } else {
            loadStudentMaterialsList();
        }
    } else if (tab === 'syllabus') {
        loadStudentSyllabus();
    } else if (tab === 'analytics') {
        loadStudentAnalytics();
    } else if (tab === 'profile') {
        loadProfileView();
    }
}

// --- TOAST NOTIFICATION ---
function showToast(message, isError = false) {
    const toast = document.getElementById('toast');
    const msgEl = document.getElementById('toastMessage');
    const icon = document.getElementById('toastIcon');

    if (!toast) return;
    if (msgEl) msgEl.innerText = message;
    if (icon) {
        if (isError) {
            icon.className = 'fa-solid fa-circle-exclamation text-rose-400 text-sm';
        } else {
            icon.className = 'fa-solid fa-circle-check text-emerald-400 text-sm';
        }
    }

    toast.classList.remove('translate-y-24', 'opacity-0');
    setTimeout(() => {
        toast.classList.add('translate-y-24', 'opacity-0');
    }, 3200);
}

// --- SYLLABUS & DYNAMIC DROPDOWNS ---
async function fetchSyllabusForSemester(semester, forceRefresh = false) {
    const sem = normalizeSemester(semester);
    if (!forceRefresh && cachedSyllabusBySem[sem] && Array.isArray(cachedSyllabusBySem[sem]) && cachedSyllabusBySem[sem].length > 0) {
        return cachedSyllabusBySem[sem];
    }
    const endpoint = API_BASE + '/api/syllabus/' + sem;
    try {
        const headers = (typeof getAuthHeaders === 'function') ? getAuthHeaders() : { 'Content-Type': 'application/json' };
        const res = await fetch(endpoint, {
            method: 'GET',
            headers: headers
        });

        // 304 Not Modified handling: return usable cache if available
        if (res.status === 304) {
            if (cachedSyllabusBySem[sem] && Array.isArray(cachedSyllabusBySem[sem]) && cachedSyllabusBySem[sem].length > 0) {
                return cachedSyllabusBySem[sem];
            }
        }

        // Error HTTP status handling (401, 403, 404, 500, etc.)
        if (!res.ok) {
            let errorMsg = `HTTP ${res.status} ${res.statusText || 'Error'}`;
            try {
                const errData = await res.json();
                if (errData && errData.message) {
                    errorMsg = errData.message;
                }
            } catch (_) { }
            console.error(`[Syllabus API Error] Endpoint: ${endpoint}, HTTP Status: ${res.status}, Response: ${errorMsg}`);
            if (cachedSyllabusBySem[sem] && Array.isArray(cachedSyllabusBySem[sem]) && cachedSyllabusBySem[sem].length > 0) {
                return cachedSyllabusBySem[sem];
            }
            return null;
        }

        const json = await res.json();
        const syllabusList = (json && Array.isArray(json.data))
            ? json.data
            : (Array.isArray(json) ? json : (json && Array.isArray(json.syllabus) ? json.syllabus : []));

        // Deduplicate subjects by subject name (case-insensitive)
        const seen = new Set();
        const unique = [];
        syllabusList.forEach(item => {
            const sName = (item.subject || '').trim();
            if (sName && !seen.has(sName.toLowerCase())) {
                seen.add(sName.toLowerCase());
                unique.push(item);
            }
        });

        cachedSyllabusBySem[sem] = unique;
        return unique;
    } catch (err) {
        console.error(`[Syllabus API Error] Endpoint: ${endpoint}, HTTP Status: network_error, Response: ${err.message || err}`);
        if (cachedSyllabusBySem[sem] && Array.isArray(cachedSyllabusBySem[sem]) && cachedSyllabusBySem[sem].length > 0) {
            return cachedSyllabusBySem[sem];
        }
        return null;
    }
}

async function populateSubjectSelect(semester, selectId, defaultSubject = '') {
    const select = document.getElementById(selectId);
    if (!select) return;

    const list = await fetchSyllabusForSemester(semester);
    if (!list || list.length === 0) {
        select.innerHTML = '<option value="">No subjects found for Semester ' + semester + '</option>';
        return;
    }

    // Deduplicate by name
    const seen = new Set();
    const unique = [];
    list.forEach(item => {
        const sName = (item.subject || '').trim();
        if (sName && !seen.has(sName.toLowerCase())) {
            seen.add(sName.toLowerCase());
            unique.push(item);
        }
    });

    select.innerHTML = unique.map((item, idx) => {
        const isSel = (defaultSubject === item.subject || (!defaultSubject && idx === 0)) ? 'selected' : '';
        return '<option value="' + item.subject + '" ' + isSel + '>' + item.subject + ' (' + (item.subjectType || 'Theory') + ')</option>';
    }).join('');

    if (selectId === 'genSubject') {
        handleGenSubjectChange();
    }
}

async function populateAllSemesterDropdowns() {
    await Promise.all([
        populateSubjectSelect(1, 'genSubject'),
        populateSubjectSelect(1, 'stuTestSubject'),
        handleStuQBSemesterChange(),
        populateSubjectSelect(1, 'stuMatSubject'),
        populateSubjectSelect(1, 'modalTopicSubject'),
        populateSubjectSelect(1, 'testSubject'),
        populateSubjectSelect(1, 'qbFilterSubject'),
        populateSubjectSelect(1, 'modalQSubject')
    ]);
}

async function handleGenSemesterChange() {
    const semEl = document.getElementById('genSemester');
    if (!semEl) return;
    await populateSubjectSelect(semEl.value, 'genSubject');
    await handleGenSubjectChange();
}

async function handleGenSubjectChange() {
    const semEl = document.getElementById('genSemester');
    const sem = Number(semEl ? semEl.value : 1) || 1;
    const subEl = document.getElementById('genSubject');
    const sub = subEl ? subEl.value : '';
    const unitSelect = document.getElementById('genUnitSelect');
    if (!unitSelect) return;

    if (!sub) {
        unitSelect.innerHTML = '<option value="0">All Units (Unit 1 to 5 Comprehensive)</option>';
        return;
    }

    try {
        const syllabusList = await fetchSyllabusForSemester(sem);
        const cleanSub = sub.trim().toLowerCase();
        const matched = (syllabusList || []).find(s => (s.subject || '').trim().toLowerCase() === cleanSub);
        if (matched && Array.isArray(matched.units) && matched.units.length > 0) {
            let html = '<option value="0">All Units (Unit 1 to ' + matched.units.length + ' Comprehensive)</option>';
            matched.units.forEach(u => {
                const titleStr = u.unitTitle ? (' - ' + u.unitTitle) : '';
                html += '<option value="' + u.unitNumber + '">Unit ' + u.unitNumber + titleStr + '</option>';
            });
            unitSelect.innerHTML = html;
        } else {
            unitSelect.innerHTML = '<option value="0">All Units (Unit 1 to 5 Comprehensive)</option>' +
                '<option value="1">Unit 1 Only</option>' +
                '<option value="2">Unit 2 Only</option>' +
                '<option value="3">Unit 3 Only</option>' +
                '<option value="4">Unit 4 Only</option>' +
                '<option value="5">Unit 5 Only</option>';
        }
    } catch (err) {
        console.warn('Error loading subject units:', err);
    }
}

async function handleStuTestSemesterChange() {
    const semEl = document.getElementById('stuTestSemester') || document.getElementById('testSemester');
    if (!semEl) return;
    await populateSubjectSelect(semEl.value, 'stuTestSubject');
    await populateSubjectSelect(semEl.value, 'testSubject');
}

async function handleTestSemesterChange() {
    return handleStuTestSemesterChange();
}

async function handleQBSemesterChange() {
    const sem = document.getElementById('qbFilterSemester')?.value;
    if (sem) {
        await populateSubjectSelect(sem, 'qbFilterSubject');
    } else {
        const subEl = document.getElementById('qbFilterSubject');
        if (subEl) subEl.innerHTML = '<option value="">All Subjects</option>';
    }
    loadQuestionBankList();
}

function handleQBSubjectChange() {
    loadQuestionBankList();
}

async function handleModalQSemesterChange() {
    const sem = document.getElementById('modalQSemester')?.value || 1;
    await populateSubjectSelect(sem, 'modalQSubject');
}

async function handleBatchSemesterChange() { }
async function handleBatchSubjectChange() { }
function handleBatchUnitChange() { }

// --- STUDENT QUESTION BANK CONTROLLERS ---
async function handleStuQBSemesterChange() {
    const semEl = document.getElementById('stuQBSemester');
    if (!semEl) return;
    const sem = Number(semEl.value) || 1;

    const subSelect = document.getElementById('stuQBSubject');
    const unitSelect = document.getElementById('stuQBUnit');
    const marksSelect = document.getElementById('stuQBMarks');
    const container = document.getElementById('stuQBQuestionsContainer') || document.getElementById('stuQuestionListContainer');

    // 1. Immediately clear the previous subject dropdown and avoid leaking old semester subjects
    if (subSelect) {
        subSelect.innerHTML = '<option value="">Loading Semester ' + sem + ' subjects...</option>';
        subSelect.value = '';
    }

    // 2. Clear/reset Unit and Marks selections
    if (unitSelect) {
        unitSelect.innerHTML = '<option value="0">All Units</option>';
        unitSelect.value = '0';
    }
    if (marksSelect) {
        marksSelect.value = '';
    }

    // 3. Reset question display container
    if (container) {
        container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">Please select a subject to browse questions.</div>';
    }

    // 4. Load ALL subjects for newly selected semester from syllabus API
    const subjects = await fetchSyllabusForSemester(sem);

    if (subSelect) {
        if (!subjects || subjects.length === 0) {
            subSelect.innerHTML = '<option value="">No subjects found for Semester ' + sem + '</option>';
            return;
        }

        // Deduplicate subject names (case-insensitive)
        const seen = new Set();
        const unique = [];
        subjects.forEach(item => {
            const sName = (item.subject || '').trim();
            if (sName && !seen.has(sName.toLowerCase())) {
                seen.add(sName.toLowerCase());
                unique.push(item);
            }
        });

        // Alphabetical ordering
        unique.sort((a, b) => a.subject.localeCompare(b.subject));

        subSelect.innerHTML = '<option value="">Select subject...</option>' + unique.map(item => {
            return '<option value="' + item.subject + '">' + item.subject + ' (' + (item.subjectType || 'Theory') + ')</option>';
        }).join('');
        subSelect.value = '';
    }
}

async function handleStuQBSubjectChange() {
    const semEl = document.getElementById('stuQBSemester');
    const sem = Number(semEl?.value) || 1;
    const subSelect = document.getElementById('stuQBSubject');
    const sub = subSelect?.value;
    const unitSelect = document.getElementById('stuQBUnit');
    const container = document.getElementById('stuQBQuestionsContainer') || document.getElementById('stuQuestionListContainer');

    if (!sub) {
        if (unitSelect) {
            unitSelect.innerHTML = '<option value="0">All Units</option>';
            unitSelect.value = '0';
        }
        if (container) {
            container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">Please select a subject to browse questions.</div>';
        }
        return;
    }

    // Load available units for this specific subject
    if (unitSelect) {
        unitSelect.innerHTML = '<option value="0">Loading units for ' + sub + '...</option>';
    }

    try {
        let matchedUnits = null;
        // Check local cached syllabus first
        const semList = cachedSyllabusBySem[sem] || [];
        const cachedItem = semList.find(s => (s.subject || '').toLowerCase().trim() === sub.toLowerCase().trim());
        if (cachedItem && cachedItem.units && cachedItem.units.length > 0) {
            matchedUnits = cachedItem.units;
        } else {
            const res = await fetch(API_BASE + '/api/syllabus/' + sem + '/' + encodeURIComponent(sub));
            const json = await res.json();
            if (json.success && json.data && json.data.units && json.data.units.length > 0) {
                matchedUnits = json.data.units;
            }
        }

        if (unitSelect) {
            if (matchedUnits && matchedUnits.length > 0) {
                unitSelect.innerHTML = '<option value="0">All Units</option>' + matchedUnits.map(u => {
                    const title = u.unitTitle ? (': ' + u.unitTitle) : '';
                    return '<option value="' + u.unitNumber + '">Unit ' + u.unitNumber + title + '</option>';
                }).join('');
            } else {
                unitSelect.innerHTML = '<option value="0">All Units</option>' +
                    '<option value="1">Unit 1</option>' +
                    '<option value="2">Unit 2</option>' +
                    '<option value="3">Unit 3</option>' +
                    '<option value="4">Unit 4</option>' +
                    '<option value="5">Unit 5</option>';
            }
            unitSelect.value = '0';
        }
    } catch (err) {
        if (unitSelect) {
            unitSelect.innerHTML = '<option value="0">All Units</option>' +
                '<option value="1">Unit 1</option>' +
                '<option value="2">Unit 2</option>' +
                '<option value="3">Unit 3</option>' +
                '<option value="4">Unit 4</option>' +
                '<option value="5">Unit 5</option>';
            unitSelect.value = '0';
        }
    }

    // Load matching questions
    loadStudentQuestionBankList();
}

async function handleStuMatSemesterChange() {
    const semEl = document.getElementById('stuMatSemester');
    if (!semEl) return;
    await populateSubjectSelect(semEl.value, 'stuMatSubject');
    loadStudentMaterialsList();
}

// --- DYNAMIC SECTION BREAKDOWN & WEIGHTAGE MANAGEMENT (SOURCE OF TRUTH) ---
let facultyConfiguredSections = [
    { name: "Section A", questionCount: 10, marksPerQuestion: 1 },
    { name: "Section B", questionCount: 5, marksPerQuestion: 5 },
    { name: "Section C", questionCount: 4, marksPerQuestion: 10 }
];
let facultyHasCustomizedSections = false;

function renderSectionConfigCards() {
    const containers = document.querySelectorAll('#sectionsConfigContainer');
    if (!containers || containers.length === 0) return;

    containers.forEach(container => {
        container.innerHTML = facultyConfiguredSections.map((s, idx) => {
            const subtotal = (Number(s.questionCount) || 0) * (Number(s.marksPerQuestion) || 0);
            return `
            <div class="section-config-row bg-white p-3.5 rounded-xl border border-slate-200 space-y-2.5 relative group shadow-xs">
                <div class="flex justify-between items-center gap-2">
                    <div class="flex items-center space-x-1.5 flex-1 min-w-0">
                        <span class="text-xs font-bold text-slate-400 font-mono">#${idx + 1}</span>
                        <input type="text" class="sec-name-input bg-slate-50 hover:bg-white focus:bg-white border border-slate-200 focus:border-indigo-500 rounded-lg px-2 py-1 text-xs font-extrabold text-slate-800 w-full" value="${s.name}" placeholder="Section Name" oninput="onSectionConfigInput()">
                    </div>
                    <div class="flex items-center space-x-1">
                        <span class="sec-subtotal-text text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">${s.questionCount} Qs × ${s.marksPerQuestion}M = ${subtotal}M</span>
                        ${facultyConfiguredSections.length > 1 ? `<button type="button" onclick="removeSectionConfig(${idx})" title="Delete Section" class="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer transition-colors"><i class="fa-solid fa-trash-can text-xs"></i></button>` : ''}
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="text-[10px] text-slate-500 font-semibold block mb-0.5">Questions Count</label>
                        <input type="number" ${idx === 0 ? 'id="secACount"' : idx === 1 ? 'id="secBCount"' : idx === 2 ? 'id="secCCount"' : ''} min="1" max="50" value="${s.questionCount}" oninput="onSectionConfigInput()" class="sec-count-input w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="text-[10px] text-slate-500 font-semibold block mb-0.5">Marks / Question</label>
                        <input type="number" ${idx === 0 ? 'id="secAMarks"' : idx === 1 ? 'id="secBMarks"' : idx === 2 ? 'id="secCMarks"' : ''} min="1" max="50" value="${s.marksPerQuestion}" oninput="onSectionConfigInput()" class="sec-marks-input w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-indigo-500">
                    </div>
                </div>
            </div>`;
        }).join('');
    });

    updateSectionBreakdownPreview();
}

function addSectionConfig() {
    facultyHasCustomizedSections = true;
    const nextIdx = facultyConfiguredSections.length;
    const nextLetter = String.fromCharCode(65 + nextIdx);
    facultyConfiguredSections.push({
        name: `Section ${nextLetter}`,
        questionCount: 2,
        marksPerQuestion: 5
    });
    renderSectionConfigCards();
    showToast(`Added Section ${nextLetter}`);
}

function removeSectionConfig(idx) {
    if (facultyConfiguredSections.length <= 1) {
        showToast('At least one section is required', true);
        return;
    }
    facultyHasCustomizedSections = true;
    const removed = facultyConfiguredSections.splice(idx, 1);
    renderSectionConfigCards();
    showToast(`Removed ${removed[0]?.name || 'section'}`);
}

function onSectionConfigInput() {
    facultyHasCustomizedSections = true;
    const containers = document.querySelectorAll('#sectionsConfigContainer');
    let container = null;
    containers.forEach(c => {
        if (c.offsetParent !== null || !container) container = c;
    });

    if (container) {
        const rows = container.querySelectorAll('.section-config-row');
        rows.forEach((row, i) => {
            if (facultyConfiguredSections[i]) {
                const name = row.querySelector('.sec-name-input')?.value?.trim() || `Section ${String.fromCharCode(65 + i)}`;
                const count = Math.max(1, Number(row.querySelector('.sec-count-input')?.value) || 1);
                const marks = Math.max(1, Number(row.querySelector('.sec-marks-input')?.value) || 1);
                facultyConfiguredSections[i].name = name;
                facultyConfiguredSections[i].questionCount = count;
                facultyConfiguredSections[i].marksPerQuestion = marks;

                const subtotalEl = row.querySelector('.sec-subtotal-text');
                if (subtotalEl) {
                    subtotalEl.innerText = `${count} Qs × ${marks}M = ${count * marks}M`;
                }
            }
        });
    }

    updateSectionBreakdownPreview();
}

function updateSectionBreakdownPreview() {
    let actualSum = 0;
    facultyConfiguredSections.forEach(s => {
        actualSum += (Number(s.questionCount) || 0) * (Number(s.marksPerQuestion) || 0);
    });

    const targetTotal = Number(document.getElementById('genTotalMarks')?.value || actualSum || 75);

    const badges = document.querySelectorAll('#breakdownTotalBadge');
    badges.forEach(badge => {
        if (actualSum === targetTotal) {
            badge.innerText = `Section Sum: ${actualSum} Marks (Balanced)`;
            badge.className = 'text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 border border-emerald-300';
        } else {
            const diff = actualSum - targetTotal;
            const diffText = diff > 0 ? `+${diff}M` : `${diff}M`;
            badge.innerText = `Section Sum: ${actualSum} / ${targetTotal} Marks (${diffText})`;
            badge.className = 'text-xs font-bold px-2.5 py-1 rounded-lg bg-rose-100 text-rose-800 border border-rose-300';
        }
    });

    // Also update legacy part tally elements if they exist
    const totalA = (Number(facultyConfiguredSections[0]?.questionCount) || 0) * (Number(facultyConfiguredSections[0]?.marksPerQuestion) || 0);
    const totalB = (Number(facultyConfiguredSections[1]?.questionCount) || 0) * (Number(facultyConfiguredSections[1]?.marksPerQuestion) || 0);
    const totalC = (Number(facultyConfiguredSections[2]?.questionCount) || 0) * (Number(facultyConfiguredSections[2]?.marksPerQuestion) || 0);

    const partAText = document.getElementById('partATallyText');
    if (partAText && facultyConfiguredSections[0]) partAText.innerText = `${facultyConfiguredSections[0].questionCount} Qs × ${facultyConfiguredSections[0].marksPerQuestion}M = ${totalA}M`;

    const partBText = document.getElementById('partBTallyText');
    if (partBText && facultyConfiguredSections[1]) partBText.innerText = `${facultyConfiguredSections[1].questionCount} Qs × ${facultyConfiguredSections[1].marksPerQuestion}M = ${totalB}M`;

    const partCText = document.getElementById('partCTallyText');
    if (partCText && facultyConfiguredSections[2]) partCText.innerText = `${facultyConfiguredSections[2].questionCount} Qs × ${facultyConfiguredSections[2].marksPerQuestion}M = ${totalC}M`;
}

function handleTotalMarksChange() {
    const target = Number(document.getElementById('genTotalMarks')?.value || 75);
    const durEl = document.getElementById('genDuration');

    if (!facultyHasCustomizedSections) {
        if (target === 30) {
            facultyConfiguredSections = [
                { name: "Section A", questionCount: 5, marksPerQuestion: 2 },
                { name: "Section B", questionCount: 2, marksPerQuestion: 5 },
                { name: "Section C", questionCount: 1, marksPerQuestion: 10 }
            ];
            if (durEl) durEl.value = '1.5 Hours';
        } else if (target === 50) {
            facultyConfiguredSections = [
                { name: "Section A", questionCount: 10, marksPerQuestion: 1 },
                { name: "Section B", questionCount: 4, marksPerQuestion: 5 },
                { name: "Section C", questionCount: 2, marksPerQuestion: 10 }
            ];
            if (durEl) durEl.value = '2 Hours';
        } else if (target === 60) {
            facultyConfiguredSections = [
                { name: "Section A", questionCount: 4, marksPerQuestion: 5 },
                { name: "Section B", questionCount: 5, marksPerQuestion: 4 },
                { name: "Section C", questionCount: 2, marksPerQuestion: 10 }
            ];
            if (durEl) durEl.value = '2.5 Hours';
        } else if (target === 75) {
            facultyConfiguredSections = [
                { name: "Section A", questionCount: 10, marksPerQuestion: 1 },
                { name: "Section B", questionCount: 5, marksPerQuestion: 5 },
                { name: "Section C", questionCount: 4, marksPerQuestion: 10 }
            ];
            if (durEl) durEl.value = '3 Hours';
        } else if (target === 80) {
            facultyConfiguredSections = [
                { name: "Section A", questionCount: 10, marksPerQuestion: 2 },
                { name: "Section B", questionCount: 6, marksPerQuestion: 5 },
                { name: "Section C", questionCount: 3, marksPerQuestion: 10 }
            ];
            if (durEl) durEl.value = '3 Hours';
        } else if (target === 100) {
            facultyConfiguredSections = [
                { name: "Section A", questionCount: 10, marksPerQuestion: 2 },
                { name: "Section B", questionCount: 6, marksPerQuestion: 5 },
                { name: "Section C", questionCount: 5, marksPerQuestion: 10 }
            ];
            if (durEl) durEl.value = '3 Hours';
        } else {
            const countA = Math.min(10, Math.floor(target * 0.2));
            const rem = target - countA;
            const countC = Math.max(1, Math.floor((rem * 0.4) / 10));
            const countB = Math.max(1, Math.floor((rem - (countC * 10)) / 5));
            const leftover = target - (countA * 1) - (countB * 5) - (countC * 10);
            facultyConfiguredSections = [
                { name: "Section A", questionCount: Math.max(1, countA + leftover), marksPerQuestion: 1 },
                { name: "Section B", questionCount: countB, marksPerQuestion: 5 },
                { name: "Section C", questionCount: countC, marksPerQuestion: 10 }
            ];
        }
        renderSectionConfigCards();
    } else {
        updateSectionBreakdownPreview();
    }
}

function getFacultyConfiguredSections() {
    const containers = document.querySelectorAll('#sectionsConfigContainer');
    let container = null;
    containers.forEach(c => {
        if (c.offsetParent !== null || !container) container = c;
    });

    if (container) {
        const rows = container.querySelectorAll('.section-config-row');
        if (rows && rows.length > 0) {
            const list = [];
            rows.forEach((row, idx) => {
                const nameInput = row.querySelector('.sec-name-input');
                const countInput = row.querySelector('.sec-count-input');
                const marksInput = row.querySelector('.sec-marks-input');
                const name = (nameInput?.value?.trim()) || `Section ${String.fromCharCode(65 + idx)}`;
                const questionCount = Math.max(1, Number(countInput?.value) || 1);
                const marksPerQuestion = Math.max(1, Number(marksInput?.value) || 1);
                list.push({ name, questionCount, marksPerQuestion });
            });
            return list;
        }
    }
    return facultyConfiguredSections;
}

function initSectionBreakdownUI() {
    renderSectionConfigCards();
}

// --- PATTERN CHANGE HANDLER ---
function handlePatternChange() {
    const pattern = document.getElementById('genPattern')?.value;
    const marksInput = document.getElementById('genTotalMarks');
    const durSelect = document.getElementById('genDuration');
    const examSelect = document.getElementById('genExamType');

    if (!marksInput) return;
    if (pattern === 'cia_30') {
        marksInput.value = '30';
        if (durSelect) durSelect.value = '1.5 Hours';
        if (examSelect) examSelect.value = 'CIA I Examination';
    } else if (pattern === 'assessment_50') {
        marksInput.value = '50';
        if (durSelect) durSelect.value = '2 Hours';
        if (examSelect) examSelect.value = 'Internal Assessment Test';
    } else if (pattern === 'semester_75') {
        marksInput.value = '75';
        if (durSelect) durSelect.value = '3 Hours';
        if (examSelect) examSelect.value = 'Summative Examination';
    } else if (pattern === 'end_sem_100') {
        marksInput.value = '100';
        if (durSelect) durSelect.value = '3 Hours';
        if (examSelect) examSelect.value = 'Comprehensive End Semester Exam';
    }
    handleTotalMarksChange();
}

// --- STATS & SAVED PAPERS ---
async function loadFacultyStats() {
    try {
        const res = await fetch(API_BASE + '/api/auth/stats');
        const json = await res.json();
        if (json.success && json.stats) {
            const subEl = document.getElementById('statFacultySubjects');
            if (subEl) subEl.innerText = json.stats.totalSubjects;
            const qEl = document.getElementById('statFacultyQuestions');
            if (qEl) qEl.innerText = json.stats.totalQuestions;
            const mcqEl = document.getElementById('statFacultyMCQs');
            if (mcqEl) mcqEl.innerText = json.stats.totalMCQs;
            const papEl = document.getElementById('statFacultyPapers');
            if (papEl) papEl.innerText = json.stats.totalPapers;
            const stuQEl = document.getElementById('statStudentAvailableQs');
            if (stuQEl) stuQEl.innerText = json.stats.totalQuestions;
        }
    } catch (err) {
        console.warn('Stats fetch error:', err);
    }
}

async function loadSavedPapersArchive() {
    try {
        const res = await fetch(API_BASE + '/api/papers');
        const json = await res.json();
        const papers = json.data || [];

        // 1. Render Dashboard Table (Recent 5)
        const tableBody = document.getElementById('dashboardRecentPapersTable');
        if (tableBody) {
            if (papers.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="5" class="py-6 text-center text-slate-400">No saved papers found. Generate a paper above!</td></tr>';
            } else {
                tableBody.innerHTML = papers.slice(0, 5).map(p => {
                    const paperTitle = p.title || `${p.subject} - ${p.examType || 'Examination'}`;
                    const genDate = p.generatedDate || (p.createdAt ? p.createdAt.split('T')[0] : '');
                    return '<tr class="hover:bg-slate-50">' +
                        '<td class="py-3 px-3 font-bold text-slate-800">' + paperTitle + (genDate ? '<div class="text-[10px] text-slate-400 font-normal">' + genDate + '</div>' : '') + '</td>' +
                        '<td class="py-3 px-3 text-slate-600">Semester ' + p.semester + '</td>' +
                        '<td class="py-3 px-3"><span class="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded font-semibold text-[10px]">' + p.examType + '</span></td>' +
                        '<td class="py-3 px-3 font-bold text-indigo-600">' + p.totalMarks + 'M</td>' +
                        '<td class="py-3 px-3 text-right space-x-1">' +
                        '<button onclick="loadPaperIntoPreview(\'' + p._id + '\')" class="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] cursor-pointer">View / Edit</button>' +
                        '<a href="' + API_BASE + '/api/papers/' + p._id + '/pdf" target="_blank" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold inline-flex items-center"><i class="fa-solid fa-file-pdf text-rose-500 mr-1"></i> PDF</a>' +
                        '</td>' +
                        '</tr>';
                }).join('');
            }
        }

        // 2. Render Saved Papers Archive Containers (both facPapersArchiveContainer and savedPapersGrid)
        const archiveContainers = [
            document.getElementById('facPapersArchiveContainer'),
            document.getElementById('savedPapersGrid')
        ].filter(Boolean);

        archiveContainers.forEach(grid => {
            if (papers.length === 0) {
                grid.innerHTML = '<div class="col-span-full text-center py-12 text-slate-400 text-xs">No examination papers in archive. Generate a paper from the Generator module!</div>';
            } else {
                grid.innerHTML = papers.map(p => {
                    const paperTitle = p.title || `${p.subject} - ${p.examType || 'Examination'}`;
                    const genDate = p.generatedDate || (p.createdAt ? p.createdAt.split('T')[0] : '');
                    const unitsInfo = (p.selectedUnits && p.selectedUnits.length > 0) ? `Units: ${p.selectedUnits.join(', ')}` : '';
                    return '<div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between hover:shadow-md transition-all">' +
                        '<div>' +
                        '<div class="flex justify-between items-start">' +
                        '<span class="text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">Semester ' + p.semester + ' • ' + p.examType + '</span>' +
                        '<button onclick="deletePaperFromDB(\'' + p._id + '\')" class="text-slate-400 hover:text-rose-600 text-xs p-1 cursor-pointer" title="Delete Paper"><i class="fa-solid fa-trash"></i></button>' +
                        '</div>' +
                        '<h4 class="font-bold text-slate-900 text-sm mt-2">' + paperTitle + '</h4>' +
                        '<p class="text-xs text-slate-500 mt-0.5">' + p.subject + ' • ' + (p.duration || '3 Hours') + (genDate ? ' • ' + genDate : '') + '</p>' +
                        (unitsInfo ? '<div class="text-[10px] text-slate-400 mt-1">' + unitsInfo + '</div>' : '') +
                        '<div class="mt-2 text-xs font-bold text-indigo-600">' + p.totalMarks + ' Maximum Marks</div>' +
                        '</div>' +
                        '<div class="flex space-x-2 pt-3 border-t border-slate-100">' +
                        '<button onclick="loadPaperIntoPreview(\'' + p._id + '\')" class="flex-1 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-center text-xs cursor-pointer">' +
                        'Open Editor' +
                        '</button>' +
                        '<a href="' + API_BASE + '/api/papers/' + p._id + '/pdf" target="_blank" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-center text-xs flex items-center justify-center">' +
                        '<i class="fa-solid fa-file-pdf text-rose-500 mr-1"></i> PDF' +
                        '</a>' +
                        '</div>' +
                        '</div>';
                }).join('');
            }
        });
    } catch (err) {
        console.warn('Saved papers load error:', err);
    }
}

async function deletePaperFromDB(paperId) {
    if (!confirm('Are you sure you want to delete this saved question paper?')) return;
    try {
        const res = await fetch(API_BASE + '/api/papers/' + paperId, {
            method: 'DELETE',
            headers: getAuthHeaders()
        });
        const json = await res.json();
        if (json.success) {
            showToast('Question paper deleted from database');
            loadSavedPapersArchive();
            loadFacultyStats();
        } else {
            showToast(json.message || 'Failed to delete paper', true);
        }
    } catch (err) {
        showToast('Failed to delete paper', true);
    }
}

async function loadPaperIntoPreview(paperId) {
    try {
        const res = await fetch(API_BASE + '/api/papers/' + paperId);
        const json = await res.json();
        if (json.success && json.data) {
            currentGeneratedPaper = json.data;
            if ((!currentGeneratedPaper.parts || currentGeneratedPaper.parts.length === 0) && currentGeneratedPaper.sections) {
                currentGeneratedPaper.parts = currentGeneratedPaper.sections.map((sec, idx) => {
                    const partLetter = String.fromCharCode(65 + idx);
                    return {
                        part: partLetter,
                        name: sec.sectionTitle || `SECTION ${partLetter}`,
                        instructions: sec.instructions || 'Answer ALL questions:',
                        marksPerQuestion: sec.marksPerQuestion,
                        questions: (sec.questions || []).map(q => ({
                            question: q.questionText || q.question,
                            questionText: q.questionText || q.question,
                            options: q.options || [],
                            correctAnswer: q.correctAnswer || '',
                            marks: q.marks,
                            difficulty: q.difficulty || 'Medium',
                            unit: q.unit || '1',
                            questionType: (q.options && q.options.length >= 2) ? 'MCQ' : 'Theory',
                            isOrPair: q.isOrPair || false,
                            orQuestion: q.orQuestion ? (typeof q.orQuestion === 'string' ? q.orQuestion : (q.orQuestion.questionText || '')) : ''
                        }))
                    };
                });
            }
            renderPaperPreview();
            switchFacultyTab('preview');
            showToast('Loaded "' + (json.data.title || json.data.subject) + '" into Paper Editor');
        } else {
            showToast(json.message || 'Paper not found', true);
        }
    } catch (err) {
        showToast('Error loading paper', true);
    }
}

// --- AI QUESTION PAPER GENERATOR ---
async function triggerGeneratePaper() {
    const btn = document.getElementById('btnTriggerGenerate');
    const sem = document.getElementById('genSemester')?.value || 1;
    const sub = document.getElementById('genSubject')?.value;
    const unitVal = Number(document.getElementById('genUnitSelect')?.value || 0);
    const pattern = document.getElementById('genPattern')?.value || 'custom';
    const examType = document.getElementById('genExamType')?.value || 'Summative Examination';
    const duration = document.getElementById('genDuration')?.value || '3 Hours';
    const difficulty = document.getElementById('genDifficulty')?.value || 'Mixed';

    // SOURCE OF TRUTH: Collect user-defined section breakdown from DOM
    const sections = getFacultyConfiguredSections();
    if (!sections || sections.length === 0) {
        showToast('Please configure at least one section', true);
        return;
    }

    let actualSum = 0;
    sections.forEach(s => {
        actualSum += ((Number(s.questionCount) || 0) * (Number(s.marksPerQuestion) || 0));
    });

    const totalMarks = Number(document.getElementById('genTotalMarks')?.value) || actualSum;

    if (!sub) {
        showToast('Please select a valid subject', true);
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Generating Blueprint with AI...';
    }

    try {
        const payload = {
            semester: Number(sem),
            subject: sub,
            units: unitVal === 0 ? [1, 2, 3, 4, 5] : [unitVal],
            selectedUnits: unitVal === 0 ? [1, 2, 3, 4, 5] : [unitVal],
            pattern,
            examType,
            totalMarks,
            duration,
            difficulty,
            sections: sections.map(s => ({
                name: s.name,
                questionCount: Number(s.questionCount),
                marksPerQuestion: Number(s.marksPerQuestion)
            }))
        };

        // Legacy compatibility for endpoints expecting sectionA, sectionB, sectionC
        if (sections[0]) payload.sectionA = { name: sections[0].name, count: sections[0].questionCount, marksPerQuestion: sections[0].marksPerQuestion };
        if (sections[1]) payload.sectionB = { name: sections[1].name, count: sections[1].questionCount, marksPerQuestion: sections[1].marksPerQuestion };
        if (sections[2]) payload.sectionC = { name: sections[2].name, count: sections[2].questionCount, marksPerQuestion: sections[2].marksPerQuestion };

        const res = await fetch(API_BASE + '/api/ai/generate-paper', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(payload)
        });

        const json = await res.json();
        if (json.success && json.data) {
            currentGeneratedPaper = json.data;
            currentGeneratedPaper.totalMarks = currentGeneratedPaper.totalMarks || totalMarks;
            currentGeneratedPaper.targetTotalMarks = totalMarks;
            renderPaperPreview();
            switchFacultyTab('preview');
            loadSavedPapersArchive();
            loadFacultyStats();
            showToast('AI generated & permanently saved ' + (currentGeneratedPaper.totalMarks || totalMarks) + ' Marks paper to MongoDB!');
        } else {
            showToast(json.message || 'Failed to generate paper', true);
        }
    } catch (err) {
        showToast('Error communicating with AI engine', true);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles mr-2"></i> Generate Question Paper';
        }
    }
}

function getRomanSemester(sem) {
    const map = { 1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI" };
    return map[Number(sem)] || String(sem);
}

// --- CLIENT-SIDE SEMANTIC DUPLICATE DETECTION ENGINE ---
const CLIENT_EXAM_STOPWORDS = new Set([
    "explain", "describe", "what", "is", "are", "define", "discuss", "differentiate",
    "between", "distinguish", "state", "list", "mention", "elaborate", "give", "write",
    "short", "notes", "on", "detailed", "account", "with", "example", "examples",
    "diagram", "diagrams", "neat", "sketch", "suitable", "syntax", "rules", "rule",
    "characteristics", "features", "feature", "advantages", "advantage", "disadvantages",
    "disadvantage", "comparison", "compare", "contrast", "importance", "significance",
    "role", "purpose", "primary", "concept", "concepts", "in", "of", "the", "a", "an",
    "and", "or", "to", "for", "from", "by", "its", "their", "how", "why", "which",
    "illustrate", "demonstrate", "briefly", "detail", "program", "code", "snippet",
    "implementation", "working", "principles", "principle", "overview", "trace",
    "analysis", "various", "different", "types", "type", "structure", "structures"
]);

function clientExtractTokens(text) {
    if (!text || typeof text !== "string") return [];
    return text.toLowerCase()
        .replace(/[^a-z0-9\s]/g, " ")
        .split(/\s+/)
        .filter(w => w.length > 2 && !CLIENT_EXAM_STOPWORDS.has(w))
        .map(w => w.replace(/(ing|edly|ingly|ed|es|s|tion|tions|ment|ments|ity|ities|ive|ives|al|ally)$/i, ""))
        .filter(w => w && w.length > 2);
}

function clientJaccard(tokensA, tokensB) {
    if (!tokensA.length || !tokensB.length) return 0;
    const setA = new Set(tokensA);
    const setB = new Set(tokensB);
    let inter = 0;
    for (const t of setA) { if (setB.has(t)) inter++; }
    const union = new Set([...setA, ...setB]).size;
    return union === 0 ? 0 : inter / union;
}

function clientDiceBigram(str1, str2) {
    const s1 = (str1 || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    const s2 = (str2 || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!s1 || !s2) return 0;
    if (s1 === s2) return 1;
    if (s1.length < 2 || s2.length < 2) return 0;
    const map1 = {};
    for (let i = 0; i < s1.length - 1; i++) {
        const bg = s1.substr(i, 2);
        map1[bg] = (map1[bg] || 0) + 1;
    }
    let inter = 0;
    for (let i = 0; i < s2.length - 1; i++) {
        const bg = s2.substr(i, 2);
        if (map1[bg] > 0) {
            inter++;
            map1[bg]--;
        }
    }
    return (2 * inter) / (s1.length - 1 + s2.length - 1);
}

function clientIsSemanticDuplicate(q1, q2) {
    if (!q1 || !q2) return false;
    const t1 = q1.trim().toLowerCase();
    const t2 = q2.trim().toLowerCase();
    if (t1 === t2) return true;
    const tok1 = clientExtractTokens(q1);
    const tok2 = clientExtractTokens(q2);
    if (tok1.length === 0 || tok2.length === 0) {
        return clientDiceBigram(t1, t2) >= 0.70;
    }
    if (clientJaccard(tok1, tok2) >= 0.48) return true;
    if (clientDiceBigram(t1, t2) >= 0.65) return true;
    return false;
}

function clientDetectPaperDuplicates(paper) {
    if (!paper || !Array.isArray(paper.parts)) return [];
    const list = [];
    paper.parts.forEach((p, pIdx) => {
        (p.questions || []).forEach((q, qIdx) => {
            const qNum = list.length + 1;
            if (q.question) {
                list.push({ partIdx: pIdx, qIdx, isOr: false, label: q.orQuestion ? `Q${qNum} (a)` : `Q${qNum}`, text: q.question, num: qNum });
            }
            if (q.orQuestion && q.orQuestion.trim().length > 0) {
                list.push({ partIdx: pIdx, qIdx, isOr: true, label: `Q${qNum} (b)`, text: q.orQuestion, num: qNum });
            }
        });
    });
    const dups = [];
    for (let i = 0; i < list.length; i++) {
        for (let j = i + 1; j < list.length; j++) {
            if (clientIsSemanticDuplicate(list[i].text, list[j].text)) {
                dups.push({ q1: list[i], q2: list[j], isOrPair: list[i].num === list[j].num });
            }
        }
    }
    return dups;
}

async function autoFixDuplicatesInPaper() {
    if (!currentGeneratedPaper) return;
    const dups = clientDetectPaperDuplicates(currentGeneratedPaper);
    if (dups.length === 0) {
        showToast("Zero semantic duplicates detected.");
        return;
    }
    showToast(`Auto-fixing ${dups.length} duplicate question(s) with AI...`);
    for (const d of dups) {
        await regenerateSingleQuestion(d.q2.partIdx, d.q2.qIdx, d.q2.isOr);
    }
    showToast("Duplicate resolution complete!");
}

// --- UNIVERSITY QUESTION PAPER PREVIEW, LIVE RECALCULATION & EDITING ---
function renderPaperPreview() {
    if (!currentGeneratedPaper) return;

    const p = currentGeneratedPaper;
    if ((!p.parts || p.parts.length === 0) && p.sections) {
        p.parts = p.sections.map((sec, idx) => {
            const partLetter = String.fromCharCode(65 + idx);
            return {
                part: partLetter,
                name: sec.sectionTitle || `SECTION ${partLetter}`,
                instructions: sec.instructions || 'Answer ALL questions:',
                marksPerQuestion: sec.marksPerQuestion,
                questions: (sec.questions || []).map(q => ({
                    question: q.questionText || q.question,
                    questionText: q.questionText || q.question,
                    options: q.options || [],
                    correctAnswer: q.correctAnswer || '',
                    marks: q.marks,
                    difficulty: q.difficulty || 'Medium',
                    unit: q.unit || '1',
                    questionType: (q.options && q.options.length >= 2) ? 'MCQ' : 'Theory',
                    isOrPair: q.isOrPair || false,
                    orQuestion: q.orQuestion ? (typeof q.orQuestion === 'string' ? q.orQuestion : (q.orQuestion.questionText || '')) : ''
                }))
            };
        });
    }

    const pageCountEl = document.getElementById('paperPreviewPageCount');
    const durEl = document.getElementById('paperPreviewDuration');
    const examNoEl = document.getElementById('paperPreviewExamNo');
    const collegeEl = document.getElementById('paperPreviewCollege');
    const degreeEl = document.getElementById('paperPreviewDegree');
    const semLineEl = document.getElementById('paperPreviewSemesterLine');
    const subjectEl = document.getElementById('paperPreviewSubject');
    const codeEl = document.getElementById('paperPreviewSubjectCode');
    const maxMarksEl = document.getElementById('paperPreviewMaxMarks');

    // Legacy fallback IDs
    const courseEl = document.getElementById('paperPreviewCourse');
    const examTypeEl = document.getElementById('paperPreviewExamType');
    const semEl = document.getElementById('paperPreviewSemester');
    const dateEl = document.getElementById('paperPreviewDate');

    const degreeStr = p.degree || 'B.Sc. (Computer Science)';
    const examMonthYear = (p.monthYear || p.examMonth || 'SEP 2026').toUpperCase();
    const semRoman = p.semester ? (getRomanSemester(p.semester) + ' SEMESTER') : 'IV SEMESTER';
    let examType = (p.examType || 'SUMMATIVE').toUpperCase();
    if (!examType.includes('EXAMINATION')) {
        examType += ' EXAMINATIONS';
    }
    const duration = p.duration || '3 Hours';
    const targetTotalMarks = Number(p.totalMarks || p.targetTotalMarks || 75);
    const subjectName = (p.subject || 'ADVANCED JAVA PROGRAMMING').toUpperCase();
    const courseCode = p.courseCode || (typeof COURSE_CODE_MAP !== 'undefined' && COURSE_CODE_MAP[p.subject]) || (p.semester ? `UCS23CT${p.semester}1` : 'UCS4CT22');

    if (pageCountEl) pageCountEl.innerText = 'No. of Page(s): 1';
    if (durEl) durEl.innerText = 'Time: ' + duration;
    if (examNoEl) examNoEl.innerText = 'Exam. No. ________';
    if (collegeEl) collegeEl.innerText = p.collegeName || 'THIAGARAJAR COLLEGE (AUTONOMOUS), MADURAI - 9';
    if (degreeEl) degreeEl.innerText = `${degreeStr} Degree Examination, ${examMonthYear}`;
    if (semLineEl) semLineEl.innerText = `${semRoman} ${examType}`;
    if (subjectEl) subjectEl.innerText = subjectName;
    if (codeEl) codeEl.innerText = courseCode;
    if (maxMarksEl) maxMarksEl.innerText = 'Maximum: ' + targetTotalMarks + ' Marks';

    if (courseEl) courseEl.innerText = `${degreeStr} Degree Examination, ${examMonthYear}`;
    if (semEl) semEl.innerText = semRoman;
    if (examTypeEl) examTypeEl.innerText = examType;
    if (dateEl) dateEl.innerText = new Date().toLocaleDateString('en-IN');

    // 1. Calculate Actual Total Marks across all parts in real-time
    let actualTotalMarks = 0;
    (p.parts || []).forEach(part => {
        (part.questions || []).forEach(q => {
            actualTotalMarks += (Number(q.marks) || 0);
        });
    });

    // 2. Update Live Summary Comparison Cards
    const targetMarksEl = document.getElementById('previewTargetMarks');
    if (targetMarksEl) targetMarksEl.innerText = targetTotalMarks;

    const actualMarksEl = document.getElementById('previewActualMarks');
    if (actualMarksEl) actualMarksEl.innerText = actualTotalMarks;

    // 3. Enforce Mark Alignment Validation & Download PDF State
    const statusBadge = document.getElementById('markComparisonStatusBadge');
    const statusText = document.getElementById('markComparisonStatusText');
    const mismatchBanner = document.getElementById('marksMismatchBanner');
    const downloadBtn = document.getElementById('btnDownloadPaperPDF');

    const isMarksAligned = (actualTotalMarks === targetTotalMarks);

    if (isMarksAligned) {
        if (statusBadge) {
            statusBadge.className = 'p-3 rounded-xl border flex items-center justify-center font-bold bg-emerald-50 border-emerald-200 text-emerald-800';
        }
        if (statusText) {
            statusText.innerHTML = '<i class="fa-solid fa-circle-check mr-1.5 text-emerald-600"></i> Marks Aligned (' + actualTotalMarks + ' / ' + targetTotalMarks + ')';
        }
        if (mismatchBanner) {
            mismatchBanner.classList.add('hidden');
        }
        if (downloadBtn) {
            downloadBtn.disabled = false;
            downloadBtn.classList.remove('opacity-50', 'cursor-not-allowed');
            downloadBtn.classList.add('cursor-pointer');
            downloadBtn.title = 'Download University Examination Paper PDF';
        }
    } else {
        const diff = actualTotalMarks - targetTotalMarks;
        const diffText = diff > 0 ? `+${diff} Marks Exceeded` : `${diff} Marks Deficit`;

        if (statusBadge) {
            statusBadge.className = 'p-3 rounded-xl border flex items-center justify-center font-bold bg-rose-50 border-rose-300 text-rose-800';
        }
        if (statusText) {
            statusText.innerHTML = '<i class="fa-solid fa-triangle-exclamation mr-1.5 text-rose-600"></i> Mismatch: ' + diffText + ' (' + actualTotalMarks + ' vs ' + targetTotalMarks + ')';
        }
        if (mismatchBanner) {
            mismatchBanner.classList.remove('hidden');
            mismatchBanner.innerHTML = '<i class="fa-solid fa-triangle-exclamation text-rose-600 text-base mr-2 flex-shrink-0"></i>' +
                '<span>Question marks total (' + actualTotalMarks + ' Marks) does not match the target examination marks (' + targetTotalMarks + ' Marks, ' + diffText + '). ' +
                '<strong>Download PDF is disabled</strong> until actual marks strictly equal target marks. Please edit marks or adjust questions.</span>';
        }
        if (downloadBtn) {
            downloadBtn.disabled = true;
            downloadBtn.classList.add('opacity-50', 'cursor-not-allowed');
            downloadBtn.classList.remove('cursor-pointer');
            downloadBtn.title = 'Disabled: Actual question marks (' + actualTotalMarks + ') must equal target marks (' + targetTotalMarks + ')';
        }
    }

    // 4. Render Dynamic Parts and Questions
    const container = document.getElementById('paperPartsContainer');
    if (!container) return;
    let globalQNum = 1;

    // Run Semantic Duplicate Detection on Paper Questions
    const duplicates = clientDetectPaperDuplicates(p);
    let duplicateBannerHtml = '';
    if (duplicates.length > 0) {
        const dupPairsDesc = duplicates.map(d => `${d.q1.label} & ${d.q2.label}`).join(', ');
        duplicateBannerHtml = '<div class="no-print p-3.5 mb-4 bg-amber-50 border-2 border-amber-300 rounded-xl text-amber-900 text-xs flex flex-wrap items-center justify-between gap-3 shadow-xs font-sans">' +
            '<div class="flex items-center space-x-2">' +
            '<i class="fa-solid fa-triangle-exclamation text-amber-600 text-base flex-shrink-0"></i>' +
            '<span><strong>Semantic Duplicate Alert:</strong> ' + duplicates.length + ' potential duplicate/overlapping question pair(s) detected: <strong>' + dupPairsDesc + '</strong>. Either/OR (a)/(b) choices must test distinct concepts.</span>' +
            '</div>' +
            '<button type="button" onclick="autoFixDuplicatesInPaper()" class="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs shadow-xs cursor-pointer flex items-center space-x-1.5">' +
            '<i class="fa-solid fa-wand-magic-sparkles text-[11px]"></i>' +
            '<span>Auto-Fix with AI</span>' +
            '</button>' +
            '</div>';
    } else {
        duplicateBannerHtml = '<div class="no-print p-2.5 mb-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center space-x-2 shadow-xs font-sans">' +
            '<i class="fa-solid fa-shield-check text-emerald-600 text-sm flex-shrink-0"></i>' +
            '<span><strong>Strict Syllabus Filter & Semantic Deduplication Active:</strong> All questions and Either/OR choices (a)/(b) are distinct and directly mapped to the syllabus.</span>' +
            '</div>';
    }

    container.innerHTML = duplicateBannerHtml + (p.parts || []).map((part, partIdx) => {
        const partLetter = (part.part || String.fromCharCode(65 + partIdx)).toUpperCase();
        let sectionTitle = (part.name || '').toUpperCase().trim();
        if (!sectionTitle || !sectionTitle.startsWith('SECTION')) {
            sectionTitle = 'SECTION - ' + partLetter;
        }

        const qCount = part.questions ? part.questions.length : (part.count || 0);
        let partTotalMarks = 0;
        (part.questions || []).forEach(q => {
            partTotalMarks += (Number(q.marks) || 0);
        });
        const marksPerQ = part.marksPerQuestion || (qCount > 0 ? Math.round(partTotalMarks / qCount) : 1);
        const finalPartTotal = partTotalMarks || (qCount * marksPerQ);
        const weightageText = `(${qCount} x ${marksPerQ} = ${finalPartTotal} Marks)`;
        const subInstruction = part.instructions || 'Answer ALL questions:';

        let partHtml = '<div class="space-y-3 pb-6 border-b border-slate-300 last:border-0 font-serif">' +
            '<div class="py-2 border-b border-slate-300 font-serif">' +
            '<div class="flex justify-between items-center relative">' +
            '<div class="w-1/4"></div>' +
            '<div class="w-2/4 text-center font-bold uppercase tracking-wider text-sm sm:text-base text-slate-900" style="font-size: 14px;">' +
            sectionTitle +
            '</div>' +
            '<div class="w-1/4 text-right font-bold text-xs sm:text-sm text-slate-900" style="font-size: 12px;">' +
            weightageText +
            '</div>' +
            '</div>' +
            '<div class="text-left text-xs italic text-slate-800 pt-1" style="font-size: 12px;">' +
            subInstruction +
            '</div>' +
            '</div>' +
            '<div class="flex justify-end no-print pt-1">' +
            '<button type="button" onclick="shuffleSection(' + partIdx + ')" title="Shuffle questions inside this section" class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold shadow-xs cursor-pointer font-sans"><i class="fa-solid fa-shuffle text-indigo-600 mr-1"></i>Shuffle Section</button>' +
            '</div>' +
            '<div class="space-y-3 pt-1">';

        (part.questions || []).forEach((q, qIdx) => {
            const qNum = globalQNum++;
            const isFirst = qIdx === 0;
            const isLast = qIdx === part.questions.length - 1;
            const hasOr = !!(q.orQuestion && q.orQuestion.trim() !== '');
            const isMCQ = q.questionType === 'MCQ' || (q.options && Array.isArray(q.options) && q.options.length >= 2);
            let qText = (q.question || '').replace(/_{3,}/g, '______');
            if (q.questionType === 'FillBlank' && !qText.includes('______')) {
                qText += ' (______)';
            }

            partHtml += '<div class="p-3.5 bg-slate-50/50 hover:bg-slate-50 rounded-xl border border-slate-200 transition-all space-y-2 group font-serif">' +
                '<div class="flex justify-between items-start gap-3">' +
                '<div class="flex-1 space-y-1.5">';

            if (hasOr) {
                // Section B / Section C with (a) OR (b) choice options
                let orText = (q.orQuestion || '').replace(/_{3,}/g, '______');
                const isOrOverlap = clientIsSemanticDuplicate(qText, orText);
                const tagA = q.topic ? `<span class="no-print text-[10px] text-indigo-700 bg-indigo-50 font-sans font-semibold px-2 py-0.5 rounded-md ml-2">Topic: ${q.topic}</span>` : '';
                const tagB = (q.orTopic || q.topic) ? `<span class="no-print text-[10px] text-violet-700 bg-violet-50 font-sans font-semibold px-2 py-0.5 rounded-md ml-2">Topic: ${q.orTopic || q.topic}</span>` : '';
                const overlapBadge = isOrOverlap ? `<span class="no-print text-[10px] text-rose-700 bg-rose-50 border border-rose-200 font-sans font-bold px-2 py-0.5 rounded-md ml-2"><i class="fa-solid fa-triangle-exclamation mr-1"></i>(a) & (b) overlap risk</span>` : '';

                partHtml += '<div class="space-y-1.5">' +
                    '<div class="flex items-start space-x-2 text-slate-900 text-xs sm:text-sm">' +
                    '<span class="font-bold whitespace-nowrap">' + qNum + '. (a)</span>' +
                    '<p class="leading-relaxed flex-1">' + qText + tagA + '</p>' +
                    '<button type="button" onclick="editQuestionInline(' + partIdx + ', ' + qIdx + ', false)" class="no-print text-slate-400 hover:text-indigo-600 text-xs p-1 cursor-pointer font-sans" title="Edit Question (a)"><i class="fa-solid fa-pen-to-square"></i></button>' +
                    '<button type="button" onclick="regenerateSingleQuestion(' + partIdx + ', ' + qIdx + ', false)" class="no-print text-slate-400 hover:text-emerald-600 text-xs p-1 cursor-pointer font-sans" title="Regenerate Question (a) with AI"><i class="fa-solid fa-arrows-rotate"></i></button>' +
                    '</div>' +
                    '<div class="text-center font-bold text-xs uppercase tracking-widest text-slate-800 my-1 font-serif flex items-center justify-center space-x-2"><span>(OR)</span>' + overlapBadge + '</div>' +
                    '<div class="flex items-start space-x-2 text-slate-900 text-xs sm:text-sm" style="margin-left: 20px;">' +
                    '<span class="font-bold whitespace-nowrap">(b)</span>' +
                    '<p class="leading-relaxed flex-1">' + orText + tagB + '</p>' +
                    '<button type="button" onclick="editQuestionInline(' + partIdx + ', ' + qIdx + ', true)" class="no-print text-slate-400 hover:text-indigo-600 text-xs p-1 cursor-pointer font-sans" title="Edit Question (b)"><i class="fa-solid fa-pen-to-square"></i></button>' +
                    '<button type="button" onclick="regenerateSingleQuestion(' + partIdx + ', ' + qIdx + ', true)" class="no-print text-slate-400 hover:text-emerald-600 text-xs p-1 cursor-pointer font-sans" title="Regenerate Question (b) with AI"><i class="fa-solid fa-arrows-rotate"></i></button>' +
                    '</div>' +
                    '</div>';
            } else if (isMCQ) {
                // Section A: MCQs formatted in 2x2 grid with (a), (b), (c), (d)
                const tagMCQ = q.topic ? `<span class="no-print text-[10px] text-indigo-700 bg-indigo-50 font-sans font-semibold px-2 py-0.5 rounded-md ml-2">Topic: ${q.topic}</span>` : '';
                partHtml += '<div class="space-y-1.5">' +
                    '<div class="flex items-start space-x-2 text-slate-900 text-xs sm:text-sm">' +
                    '<span class="font-bold whitespace-nowrap">' + qNum + '.</span>' +
                    '<p class="leading-relaxed flex-1">' + qText + tagMCQ + '</p>' +
                    '</div>';

                if (q.options && q.options.length) {
                    const optLabels = ['(a)', '(b)', '(c)', '(d)'];
                    partHtml += '<div class="grid grid-cols-2 gap-x-6 gap-y-1 mt-1 text-xs text-slate-800 font-serif" style="margin-left: 20px;">';
                    q.options.forEach((opt, optIdx) => {
                        const lbl = optLabels[optIdx] || '(' + String.fromCharCode(97 + optIdx) + ')';
                        partHtml += '<div><span class="font-bold">' + lbl + '</span> ' + opt + '</div>';
                    });
                    partHtml += '</div>';
                }
                partHtml += '</div>';
            } else {
                // Single question: Definition, Short answer or Fill-in-the-blank
                partHtml += '<div class="flex items-start space-x-2 text-slate-900 text-xs sm:text-sm">' +
                    '<span class="font-bold whitespace-nowrap">' + qNum + '.</span>' +
                    '<p class="leading-relaxed flex-1">' + qText + '</p>' +
                    '</div>';
            }

            partHtml += '</div>' +
                '<div class="flex flex-col items-end space-y-1.5">' +
                // Inline editable marks field with live recalculation
                '<div class="flex items-center space-x-1 font-bold text-slate-900 text-xs sm:text-sm font-sans whitespace-nowrap">' +
                '<span>[</span>' +
                '<input type="number" min="1" max="50" value="' + q.marks + '" onchange="changeQuestionMarks(' + partIdx + ', ' + qIdx + ', this.value)" class="w-12 text-center bg-white border border-slate-300 rounded font-bold text-indigo-700 py-0.5 px-1 no-print focus:ring-1 focus:ring-indigo-500 cursor-text" title="Change marks for this question (recalculates immediately)">' +
                '<span>Marks]</span>' +
                '</div>' +
                '<div class="flex items-center space-x-1 no-print bg-white p-1 rounded-lg border border-slate-200 shadow-xs">' +
                '<button type="button" onclick="moveQuestionUp(' + partIdx + ', ' + qIdx + ')" ' + (isFirst ? 'disabled class="p-1 text-slate-300 cursor-not-allowed"' : 'class="p-1 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded cursor-pointer"') + ' title="Move Question Up"><i class="fa-solid fa-arrow-up text-xs"></i></button>' +
                '<button type="button" onclick="moveQuestionDown(' + partIdx + ', ' + qIdx + ')" ' + (isLast ? 'disabled class="p-1 text-slate-300 cursor-not-allowed"' : 'class="p-1 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded cursor-pointer"') + ' title="Move Question Down"><i class="fa-solid fa-arrow-down text-xs"></i></button>' +
                (!hasOr ? '<button type="button" onclick="editQuestionInline(' + partIdx + ', ' + qIdx + ', false)" title="Edit Question" class="p-1 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded cursor-pointer"><i class="fa-solid fa-pen-to-square text-xs"></i></button>' : '') +
                (!hasOr ? '<button type="button" onclick="regenerateSingleQuestion(' + partIdx + ', ' + qIdx + ', false)" title="Regenerate this question with AI" class="p-1 text-slate-600 hover:text-emerald-600 hover:bg-slate-100 rounded cursor-pointer"><i class="fa-solid fa-arrows-rotate text-xs"></i></button>' : '') +
                '<button type="button" onclick="deleteQuestionFromPaper(' + partIdx + ', ' + qIdx + ')" title="Delete Question" class="p-1 text-slate-600 hover:text-rose-600 hover:bg-slate-100 rounded cursor-pointer"><i class="fa-solid fa-trash text-xs"></i></button>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>';
        });

        partHtml += '</div></div>';
        return partHtml;
    }).join('');
}

// Inline Marks Change with Instant Real-Time Recalculation
function changeQuestionMarks(partIdx, qIdx, newMarks) {
    const val = Number(newMarks);
    if (!val || val <= 0) {
        showToast('Marks must be at least 1', true);
        renderPaperPreview();
        return;
    }
    if (currentGeneratedPaper && currentGeneratedPaper.parts && currentGeneratedPaper.parts[partIdx]) {
        const q = currentGeneratedPaper.parts[partIdx].questions[qIdx];
        if (q) {
            q.marks = val;
            renderPaperPreview();
            showToast('Updated Question mark to ' + val + 'M. Total recalculated.');
        }
    }
}

// Delete Question with Instant Real-Time Recalculation
function deleteQuestionFromPaper(partIdx, qIdx) {
    if (!confirm('Are you sure you want to delete this question? Total marks will be recalculated immediately.')) return;
    if (currentGeneratedPaper && currentGeneratedPaper.parts && currentGeneratedPaper.parts[partIdx]) {
        currentGeneratedPaper.parts[partIdx].questions.splice(qIdx, 1);
        renderPaperPreview();
        showToast('Question deleted. Marks recalculated.');
    }
}

// Add Question Modal UI Handlers
function openAddQuestionModalUI() {
    const modal = document.getElementById('addQuestionToPaperModal');
    if (!modal) return;
    const select = document.getElementById('modalAddQSection');
    if (select && currentGeneratedPaper && currentGeneratedPaper.parts && currentGeneratedPaper.parts.length > 0) {
        select.innerHTML = currentGeneratedPaper.parts.map((p, idx) => {
            const label = p.name || `Section ${p.part || String.fromCharCode(65 + idx)}`;
            const val = p.part || p.name || String.fromCharCode(65 + idx);
            return `<option value="${val}">${label}</option>`;
        }).join('');
    }
    modal.classList.remove('hidden');
}

function closeAddQuestionModalUI() {
    const modal = document.getElementById('addQuestionToPaperModal');
    if (modal) modal.classList.add('hidden');
}

function handleConfirmAddQuestion(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts) {
        showToast('Please generate or open a paper first', true);
        return;
    }

    const sectionVal = document.getElementById('modalAddQSection')?.value || 'A';
    const text = document.getElementById('modalAddQText')?.value?.trim();
    const orText = document.getElementById('modalAddQOrText')?.value?.trim() || '';
    const marks = Number(document.getElementById('modalAddQMarks')?.value || 5);

    if (!text) {
        showToast('Please enter the question text', true);
        return;
    }

    if (orText && clientIsSemanticDuplicate(text, orText)) {
        showToast('Either/OR choices (a) and (b) cannot be identical or semantically duplicate.', true);
        return;
    }

    // Find matching section part
    let targetPart = currentGeneratedPaper.parts.find(p => p.part === sectionVal || p.name === sectionVal);
    if (!targetPart) {
        targetPart = currentGeneratedPaper.parts[0];
    }
    if (!targetPart) {
        targetPart = {
            part: sectionVal,
            name: `Section ${sectionVal}`,
            instructions: 'Answer all questions',
            questions: []
        };
        currentGeneratedPaper.parts.push(targetPart);
    }

    targetPart.questions.push({
        question: text,
        orQuestion: orText,
        marks: marks,
        difficulty: 'Medium',
        unit: 1,
        questionType: orText ? 'EitherOr' : (marks === 1 ? 'MCQ' : 'Theory')
    });

    closeAddQuestionModalUI();
    const form = document.getElementById('modalAddQText');
    if (form) form.value = '';
    const orForm = document.getElementById('modalAddQOrText');
    if (orForm) orForm.value = '';

    renderPaperPreview();
    showToast('Question added to ' + (targetPart.name || ('Section ' + targetPart.part)) + '! Marks recalculated.');
}

// --- QUESTION ORDERING CONTROLS ---
function moveQuestionUp(partIdx, qIdx) {
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts[partIdx]) return;
    const questions = currentGeneratedPaper.parts[partIdx].questions;
    if (qIdx > 0) {
        const temp = questions[qIdx];
        questions[qIdx] = questions[qIdx - 1];
        questions[qIdx - 1] = temp;
        renderPaperPreview();
        showToast('Moved Question ' + (qIdx + 1) + ' up');
    }
}

function moveQuestionDown(partIdx, qIdx) {
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts[partIdx]) return;
    const questions = currentGeneratedPaper.parts[partIdx].questions;
    if (qIdx < questions.length - 1) {
        const temp = questions[qIdx];
        questions[qIdx] = questions[qIdx + 1];
        questions[qIdx + 1] = temp;
        renderPaperPreview();
        showToast('Moved Question ' + (qIdx + 1) + ' down');
    }
}

function reverseSectionOrder() {
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts) return;
    currentGeneratedPaper.parts.reverse();
    renderPaperPreview();
    showToast('Reversed section order');
}

function shuffleSection(partIdx) {
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts[partIdx]) return;
    currentGeneratedPaper.parts[partIdx].questions.sort(() => 0.5 - Math.random());
    renderPaperPreview();
    showToast('Shuffled questions inside Section ' + currentGeneratedPaper.parts[partIdx].part);
}

function shuffleCurrentPaper() {
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts) return;
    currentGeneratedPaper.parts.forEach(part => {
        part.questions.sort(() => 0.5 - Math.random());
    });
    renderPaperPreview();
    showToast('Shuffled questions within respective sections!');
}

function editQuestionInline(partIdx, qIdx, isOrQuestion = false) {
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts[partIdx]) return;
    const q = currentGeneratedPaper.parts[partIdx].questions[qIdx];
    const initialText = isOrQuestion ? q.orQuestion : q.question;
    const counterpartText = isOrQuestion ? q.question : (q.orQuestion || '');
    const promptLabel = isOrQuestion ? 'Edit Alternative Question (b):' : 'Edit Question' + (q.orQuestion ? ' (a):' : ':');
    const newText = prompt(promptLabel, initialText);
    if (newText && newText.trim() !== '') {
        const trimmed = newText.trim();
        if (counterpartText && clientIsSemanticDuplicate(trimmed, counterpartText)) {
            showToast('Warning: Option (a) and Option (b) appear semantically identical. They should test different topics.', true);
        }
        if (isOrQuestion) {
            q.orQuestion = trimmed;
        } else {
            q.question = trimmed;
        }
        renderPaperPreview();
        showToast('Question text updated');
    }
}

async function regenerateSingleQuestion(partIdx, qIdx, isOrQuestion = false) {
    if (!currentGeneratedPaper || !currentGeneratedPaper.parts[partIdx]) return;
    const q = currentGeneratedPaper.parts[partIdx].questions[qIdx];
    const targetText = isOrQuestion ? q.orQuestion : q.question;
    const counterpartText = isOrQuestion ? q.question : (q.orQuestion || '');
    const unitVal = isOrQuestion ? (q.orUnit || q.unit || 1) : (q.unit || 1);
    const topicVal = isOrQuestion ? (q.orTopic || q.topic || '') : (q.topic || '');

    // Collect all existing question texts across the paper to prevent duplicates
    const allPaperQuestions = [];
    currentGeneratedPaper.parts.forEach(p => {
        (p.questions || []).forEach(item => {
            if (item.question) allPaperQuestions.push(item.question);
            if (item.orQuestion) allPaperQuestions.push(item.orQuestion);
        });
    });

    showToast('Regenerating ' + (isOrQuestion ? 'Question (b)' : 'Question (a)') + ' with AI...');

    try {
        const res = await fetch(API_BASE + '/api/ai/regenerate-question', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                semester: currentGeneratedPaper.semester,
                subject: currentGeneratedPaper.subject,
                unit: unitVal,
                topic: topicVal,
                marks: q.marks,
                difficulty: q.difficulty || 'Medium',
                currentQuestion: targetText,
                counterpartQuestion: counterpartText,
                excludeQuestions: allPaperQuestions,
                isOrQuestion: isOrQuestion
            })
        });

        const json = await res.json();
        if (json.success && json.data) {
            if (isOrQuestion) {
                q.orQuestion = json.data.question;
                if (json.data.topic) q.orTopic = json.data.topic;
                if (json.data.answer) q.orAnswer = json.data.answer;
            } else {
                q.question = json.data.question;
                if (json.data.topic) q.topic = json.data.topic;
                if (json.data.answer) q.answer = json.data.answer;
                if (json.data.options) q.options = json.data.options;
            }
            renderPaperPreview();
            showToast((isOrQuestion ? 'Question (b)' : 'Question (a)') + ' regenerated with AI!');
        } else {
            showToast(json.message || 'Regeneration failed', true);
        }
    } catch (err) {
        showToast('Regeneration failed: ' + err.message, true);
    }
}

async function saveCurrentPaperToDB() {
    if (!currentGeneratedPaper) return;
    try {
        const isUpdate = Boolean(currentGeneratedPaper._id);
        const url = isUpdate ? (API_BASE + '/api/papers/' + currentGeneratedPaper._id) : (API_BASE + '/api/papers');
        const method = isUpdate ? 'PUT' : 'POST';

        const res = await fetch(url, {
            method: method,
            headers: getAuthHeaders(),
            body: JSON.stringify({
                ...currentGeneratedPaper,
                title: currentGeneratedPaper.title || (currentGeneratedPaper.subject + ' - ' + (currentGeneratedPaper.examType || 'Examination'))
            })
        });
        const json = await res.json();
        if (json.success) {
            if (json.data && json.data._id) {
                currentGeneratedPaper._id = json.data._id;
            }
            showToast('Question paper successfully saved to MongoDB!');
            loadSavedPapersArchive();
            loadFacultyStats();
        } else {
            showToast(json.message || 'Save error', true);
        }
    } catch (err) {
        showToast('Failed to save paper to database', true);
    }
}

async function downloadCurrentPaperPDF() {
    if (!currentGeneratedPaper) return;

    // Strict validation: Total actual question marks must equal target total marks
    let actualTotalMarks = 0;
    (currentGeneratedPaper.parts || []).forEach(part => {
        (part.questions || []).forEach(q => {
            actualTotalMarks += (Number(q.marks) || 0);
        });
    });

    const targetTotalMarks = Number(currentGeneratedPaper.totalMarks || currentGeneratedPaper.targetTotalMarks || 75);

    if (actualTotalMarks !== targetTotalMarks) {
        showToast('Cannot export PDF: Question marks total (' + actualTotalMarks + 'M) must equal target marks (' + targetTotalMarks + 'M)', true);
        return;
    }

    showToast('Generating University Examination PDF via PDFKit engine...');

    try {
        const res = await fetch(API_BASE + '/api/papers/export-pdf', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(currentGeneratedPaper)
        });

        if (!res.ok) throw new Error('PDF generation failed');
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (currentGeneratedPaper.subject || 'Question_Paper').replace(/\s+/g, '_') + '_Examination_Paper.pdf';
        document.body.appendChild(a);
        a.click();
        a.remove();
        showToast('Examination Paper PDF downloaded successfully!');
    } catch (err) {
        showToast('PDF generation failed: ' + err.message, true);
    }
}

function printCurrentPaper() {
    window.print();
}

// --- QUESTION BANK CRUD & AI BATCH ---
async function loadQuestionBankList() {
    const container = document.getElementById('questionBankContainer');
    const sem = document.getElementById('qbFilterSemester').value;
    const sub = document.getElementById('qbFilterSubject').value;
    const unit = document.getElementById('qbFilterUnit').value;
    const qType = document.getElementById('qbFilterType').value;
    const marks = document.getElementById('qbFilterMarks').value;
    const diff = document.getElementById('qbFilterDifficulty').value;

    container.innerHTML = '<div class="text-center py-12 text-slate-400 text-xs"><i class="fa-solid fa-spinner fa-spin text-lg mb-2"></i><br>Querying Question Bank...</div>';

    const params = new URLSearchParams();
    if (sem) params.append('semester', sem);
    if (sub) params.append('subject', sub);
    if (unit && unit !== '0') params.append('unit', unit);
    if (qType && qType !== 'All') params.append('questionType', qType);
    if (marks) params.append('marks', marks);
    if (diff && diff !== 'All') params.append('difficulty', diff);

    try {
        const res = await fetch(API_BASE + '/api/questions?' + params.toString());
        const json = await res.json();
        const list = json.data || [];

        if (list.length === 0) {
            container.innerHTML = '<div class="text-center py-12 text-slate-400 text-xs">No questions match your filter criteria. Click "Add New Question" to populate!</div>';
            return;
        }

        container.innerHTML = list.map((q, idx) => {
            let itemHtml = '<div class="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">' +
                '<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">' +
                '<div class="flex flex-wrap items-center gap-2">' +
                '<span class="text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">Sem ' + q.semester + ' • Unit ' + q.unit + '</span>' +
                '<span class="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">' + q.subject + '</span>' +
                '<span class="text-[10px] font-bold ' + (q.questionType === 'MCQ' ? 'bg-violet-100 text-violet-700' : 'bg-amber-100 text-amber-700') + ' px-2 py-0.5 rounded">' + q.questionType + '</span>' +
                '<span class="text-[10px] font-bold bg-slate-900 text-white px-2 py-0.5 rounded">' + q.marks + ' Mark' + (q.marks > 1 ? 's' : '') + '</span>' +
                '<span class="text-[10px] font-medium text-slate-500">' + q.difficulty + '</span>' +
                '</div>' +
                '<div class="flex items-center space-x-2">' +
                '<button onclick="deleteQuestionBankItem(\'' + q._id + '\')" class="text-slate-400 hover:text-rose-600 text-xs p-1"><i class="fa-solid fa-trash"></i></button>' +
                '</div>' +
                '</div>' +
                '<h4 class="font-bold text-slate-900 text-xs sm:text-sm">' + q.question + '</h4>';

            if (q.questionType === 'MCQ' && q.options && q.options.length) {
                itemHtml += '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">';
                q.options.forEach((opt, optIdx) => {
                    const isCorr = opt === q.correctAnswer;
                    itemHtml += '<div class="p-2 rounded-lg border ' + (isCorr ? 'bg-emerald-50 border-emerald-300 font-bold text-emerald-900' : 'bg-slate-50 border-slate-200 text-slate-700') + '">' +
                        '<span class="font-bold mr-1">(' + String.fromCharCode(65 + optIdx) + ')</span> ' + opt +
                        (isCorr ? '<i class="fa-solid fa-check text-emerald-600 ml-1"></i>' : '') +
                        '</div>';
                });
                itemHtml += '</div>';
            }

            if (q.answer) {
                itemHtml += '<details class="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200 cursor-pointer">' +
                    '<summary class="font-bold text-indigo-700">View Model Answer / Explanation</summary>' +
                    '<p class="mt-2 text-[11px] leading-relaxed text-slate-700 whitespace-pre-line">' + q.answer + '</p>' +
                    '</details>';
            }

            itemHtml += '</div>';
            return itemHtml;
        }).join('');
    } catch (err) {
        container.innerHTML = '<div class="text-center py-12 text-rose-500 text-xs">Error loading questions from database.</div>';
    }
}

async function deleteQuestionBankItem(id) {
    if (!confirm('Are you sure you want to delete this question?')) return;
    try {
        const res = await fetch(API_BASE + '/api/questions/' + id, {
            method: 'DELETE',
            headers: getAuthHeaders()
        });
        const json = await res.json();
        if (json.success) {
            showToast('Question deleted');
            loadQuestionBankList();
            loadFacultyStats();
        }
    } catch (err) {
        showToast('Failed to delete', true);
    }
}

function openAddQuestionModal() { document.getElementById('addQuestionModal').classList.remove('hidden'); }
function closeAddQuestionModal() { document.getElementById('addQuestionModal').classList.add('hidden'); }

function toggleModalQType() {
    const type = document.getElementById('modalQType').value;
    const mcqSection = document.getElementById('modalMCQOptionsSection');
    if (type === 'MCQ') {
        mcqSection.classList.remove('hidden');
        document.getElementById('modalQMarks').value = '1';
    } else {
        mcqSection.classList.add('hidden');
        document.getElementById('modalQMarks').value = '2';
    }
}

async function handleSaveQuestion(e) {
    e.preventDefault();
    const semester = document.getElementById('modalQSemester').value;
    const subject = document.getElementById('modalQSubject').value;
    const unit = document.getElementById('modalQUnit').value;
    const topic = document.getElementById('modalQTopic').value;
    const questionType = document.getElementById('modalQType').value;
    const marks = document.getElementById('modalQMarks').value;
    const question = document.getElementById('modalQText').value;
    const answer = document.getElementById('modalQAnswer').value;

    let options = [];
    let correctAnswer = '';

    if (questionType === 'MCQ') {
        options = [
            document.getElementById('modalOptA').value.trim(),
            document.getElementById('modalOptB').value.trim(),
            document.getElementById('modalOptC').value.trim(),
            document.getElementById('modalOptD').value.trim()
        ].filter(Boolean);

        correctAnswer = document.getElementById('modalQCorrectAnswer').value.trim();
        if (options.length < 2 || !correctAnswer) {
            showToast('Please provide at least 2 options and the correct answer', true);
            return;
        }
    }

    try {
        const res = await fetch(API_BASE + '/api/questions', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                semester,
                subject,
                unit,
                topic,
                question,
                options,
                correctAnswer,
                marks,
                answer,
                questionType
            })
        });
        const json = await res.json();
        if (json.success) {
            closeAddQuestionModal();
            showToast('Question saved to database!');
            loadQuestionBankList();
            loadFacultyStats();
        } else {
            showToast(json.message || 'Failed to save question', true);
        }
    } catch (err) {
        showToast('Connection error', true);
    }
}

// --- DEPRECATED AI QUESTION BANK GENERATOR HANDLERS (REMOVED) ---
function openAIBatchModal() { switchFacultyTab('qbank'); }
function closeAIBatchModal() { }
function handleGenerateAIBatch(e) { if (e && e.preventDefault) e.preventDefault(); }
function initBatchGeneratorDropdowns() { }
function handleBatchGenSemesterChange() { }
function handleBatchGenSubjectChange() { }
function handleGenerateAIBatchView() { switchFacultyTab('qbank'); }
function handleBatchGenerateQuestions() { switchFacultyTab('qbank'); }

// --- USER PROFILE & PASSWORD ---
function openProfileTab() {
    if (!currentUser) return;
    if (currentUser.role === 'Faculty') {
        switchFacultyTab('profile');
    } else {
        switchStudentTab('profile');
    }
    loadProfileView();
}

function attachProfileFormListeners() {
    const forms = document.querySelectorAll('#updateProfileForm, #stuProfileForm, #facProfileForm');
    forms.forEach(form => {
        if (!form.dataset.listenerAttached) {
            form.addEventListener('submit', handleUpdateProfile);
            form.dataset.listenerAttached = 'true';
        }
    });

    const passForms = document.querySelectorAll('#changePasswordForm');
    passForms.forEach(form => {
        if (!form.dataset.listenerAttached) {
            form.addEventListener('submit', handleChangePassword);
            form.dataset.listenerAttached = 'true';
        }
    });
}

function attachPasswordToggles() {
    const passwordInputs = [
        document.getElementById('currentPassword'),
        document.getElementById('newPassword'),
        document.getElementById('confirmPassword')
    ];

    passwordInputs.forEach(input => {
        if (!input) return;
        const parent = input.closest('.password-wrapper') || input.parentElement;
        if (!parent) return;

        // Check if toggle button already exists
        if (!parent.querySelector('.toggle-eye-btn')) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'toggle-eye-btn';
            btn.setAttribute('aria-label', 'Toggle ' + (input.name || 'password') + ' visibility');
            btn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                </svg>
            `;
            btn.onclick = () => toggleInputPassword(input.id, btn);
            parent.appendChild(btn);
        }
    });
}

function toggleInputPassword(inputId, btnEl) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const isCurrentlyPassword = input.getAttribute('type') === 'password';
    input.setAttribute('type', isCurrentlyPassword ? 'text' : 'password');

    if (btnEl) {
        const svg = btnEl.querySelector('svg');
        if (svg) {
            if (isCurrentlyPassword) {
                svg.innerHTML = `
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                    <circle cx="12" cy="12" r="3"></circle>
                `;
                btnEl.setAttribute('aria-label', 'Hide password');
            } else {
                svg.innerHTML = `
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                `;
                btnEl.setAttribute('aria-label', 'Show password');
            }
        }
    }
}

// Profile Photo Selection & Instant Preview Handler
function handleProfilePhotoSelect(event) {
    const file = event.target && event.target.files && event.target.files[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg', 'image/gif'];
    if (!validTypes.includes(file.type.toLowerCase())) {
        showToast('Please select a valid image file (JPEG, PNG, WEBP)', true);
        event.target.value = '';
        return;
    }

    if (file.size > 3 * 1024 * 1024) {
        showToast('Profile image size should not exceed 3MB', true);
        event.target.value = '';
        return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
        const dataUrl = e.target.result;
        window.pendingProfilePhoto = dataUrl;
        updateProfilePhotoDisplay(dataUrl);
        showToast('Profile photo selected. Click "Save Changes" to apply.');
    };
    reader.readAsDataURL(file);
}
window.handleProfilePhotoSelect = handleProfilePhotoSelect;

function updateProfilePhotoDisplay(photoUrl) {
    const photoImgIds = ['facProfilePhotoImg', 'stuProfilePhotoImg', 'profilePhotoImg'];
    const initialIds = ['facProfileAvatarInitials', 'stuProfileAvatarInitials', 'profileAvatarInitials'];

    photoImgIds.forEach(id => {
        const img = document.getElementById(id);
        if (img) {
            if (photoUrl) {
                img.src = photoUrl;
                img.classList.remove('hidden');
                img.style.display = 'block';
            } else {
                img.src = '';
                img.classList.add('hidden');
                img.style.display = 'none';
            }
        }
    });

    initialIds.forEach(id => {
        const initialEl = document.getElementById(id);
        if (initialEl) {
            if (photoUrl) {
                initialEl.classList.add('hidden');
                initialEl.style.display = 'none';
            } else {
                initialEl.classList.remove('hidden');
                initialEl.style.display = '';
            }
        }
    });
}
window.updateProfilePhotoDisplay = updateProfilePhotoDisplay;

function getProfileScope(contextOrBtn) {
    if (contextOrBtn) {
        if (contextOrBtn.nodeType) {
            const form = contextOrBtn.closest('form') || contextOrBtn.closest('.profile-card') || contextOrBtn.closest('.profile-container');
            if (form) return form;
        } else if (typeof contextOrBtn === 'string') {
            const el = document.getElementById(contextOrBtn);
            if (el) return el;
        }
    }
    if (window.currentUser) currentUser = window.currentUser;
    let isFaculty = false;
    if (currentUser && currentUser.role) {
        isFaculty = currentUser.role.toLowerCase() === 'faculty';
    } else if (window.location.pathname.includes('/faculty')) {
        isFaculty = true;
    } else if (window.currentPortal) {
        isFaculty = String(window.currentPortal).toUpperCase() === 'FACULTY';
    }

    const prefix = isFaculty ? 'fac' : 'stu';
    const activeViewId = isFaculty ? 'facView_profile' : 'stuView_profile';
    const activeView = document.getElementById(activeViewId);
    if (activeView && !activeView.classList.contains('hidden')) {
        return activeView;
    }
    const dedicatedForm = document.getElementById(prefix + 'ProfileForm');
    if (dedicatedForm) return dedicatedForm;
    const updateForm = document.getElementById('updateProfileForm');
    if (updateForm) return updateForm;
    return activeView || document;
}

function getProfileInputs(contextOrBtn) {
    const scope = getProfileScope(contextOrBtn);
    const getEl = (...selectors) => {
        for (const s of selectors) {
            if (!s) continue;
            const el = scope.querySelector(s);
            if (el) return el;
        }
        for (const s of selectors) {
            if (!s) continue;
            const el = document.querySelector(s);
            if (el) return el;
        }
        return null;
    };

    const isFaculty = currentUser && currentUser.role && currentUser.role.toLowerCase() === 'faculty';
    const prefix = isFaculty ? 'fac' : 'stu';

    const nameInput = getEl(
        '#' + prefix + 'ProfileName',
        '#fullName',
        '#facProfileName',
        '#stuProfileName',
        'input[name="name"]'
    );
    const emailInput = getEl(
        '#' + prefix + 'ProfileEmail',
        '#email',
        '#facProfileEmail',
        '#stuProfileEmail',
        'input[name="email"]'
    );
    const usernameInput = getEl(
        '#' + prefix + 'ProfileUsername',
        '#username',
        '#facProfileUsername',
        '#stuProfileUsername',
        'input[name="username"]'
    );

    return {
        scope,
        nameInput,
        emailInput,
        usernameInput,
        nameInputs: nameInput ? [nameInput] : [],
        emailInputs: emailInput ? [emailInput] : [],
        usernameInputs: usernameInput ? [usernameInput] : []
    };
}

let profileOriginalState = {
    name: '',
    fullName: '',
    email: '',
    username: ''
};
let isEditMode = false;
let isEditing = false;
window.isEditMode = false;
window.isEditing = false;

function setIsEditMode(val, triggerBtn = null) {
    toggleProfileEditMode(!!val, false, triggerBtn);
}
function setIsEditing(val, triggerBtn = null) {
    toggleProfileEditMode(!!val, false, triggerBtn);
}
window.setIsEditMode = setIsEditMode;
window.setIsEditing = setIsEditing;

function clearProfileInlineErrors() {
    const errorEls = document.querySelectorAll('.profile-field-error');
    errorEls.forEach(el => {
        el.innerText = '';
        el.classList.add('hidden');
    });

    const allInputs = document.querySelectorAll('#fullName, #email, #username, #facProfileName, #facProfileEmail, #facProfileUsername, #stuProfileName, #stuProfileEmail, #stuProfileUsername, .profile-input-field');
    allInputs.forEach(inp => {
        inp.classList.remove('!border-rose-500', 'border-rose-500', 'bg-rose-50/40');
    });
}

function showProfileInlineError(fieldKey, message) {
    let key = fieldKey;
    if (key === 'name') key = 'fullName';

    const isFaculty = currentUser && currentUser.role && currentUser.role.toLowerCase() === 'faculty';
    const prefix = isFaculty ? 'fac' : 'stu';

    const errIdCandidates = [
        prefix + 'Profile' + key.charAt(0).toUpperCase() + key.slice(1) + 'Error',
        'facProfile' + key.charAt(0).toUpperCase() + key.slice(1) + 'Error',
        'stuProfile' + key.charAt(0).toUpperCase() + key.slice(1) + 'Error',
        key + 'Error',
        key === 'fullName' ? prefix + 'ProfileNameError' : '',
        key === 'fullName' ? 'stuProfileNameError' : '',
        key === 'fullName' ? 'facProfileNameError' : '',
        key === 'email' ? prefix + 'ProfileEmailError' : '',
        key === 'username' ? prefix + 'ProfileUsernameError' : ''
    ].filter(Boolean);

    errIdCandidates.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.innerText = message;
            el.classList.remove('hidden');
        }
    });

    const inputsObj = getProfileInputs();
    const candidateList = inputsObj[key + 'Inputs'] || inputsObj[fieldKey + 'Inputs'] || [];
    candidateList.forEach(inp => {
        inp.classList.add('!border-rose-500', 'bg-rose-50/40');
    });
}

function attachInputClearErrorListeners() {
    const allInputs = document.querySelectorAll('#fullName, #email, #username, #facProfileName, #facProfileEmail, #facProfileUsername, #stuProfileName, #stuProfileEmail, #stuProfileUsername, .profile-input-field');
    allInputs.forEach(inp => {
        if (inp && !inp.dataset.errorClearAttached) {
            inp.addEventListener('input', () => {
                inp.classList.remove('!border-rose-500', 'border-rose-500', 'bg-rose-50/40');
                const p = inp.parentElement ? inp.parentElement.querySelector('.profile-field-error') : null;
                if (p) {
                    p.innerText = '';
                    p.classList.add('hidden');
                }
            });
            inp.dataset.errorClearAttached = 'true';
        }
    });
}

function attachProfileButtonListeners() {
    const editBtns = document.querySelectorAll('#editProfileBtn, [id="editProfileBtn"], #facEditProfileBtn, #stuEditProfileBtn, #headerEditProfileBtn, [id="headerEditProfileBtn"], .edit-profile-btn');
    editBtns.forEach(btn => {
        btn.onclick = (e) => {
            if (e && typeof e.preventDefault === 'function') e.preventDefault();
            toggleProfileEditMode(true, false, btn);
        };
    });

    const cancelBtns = document.querySelectorAll('#cancelProfileBtn, [id="cancelProfileBtn"], #facCancelProfileBtn, #stuCancelProfileBtn, .cancel-profile-btn');
    cancelBtns.forEach(btn => {
        btn.onclick = (e) => {
            if (e && typeof e.preventDefault === 'function') e.preventDefault();
            toggleProfileEditMode(false, true, btn);
        };
    });

    const saveBtns = document.querySelectorAll('#saveProfileBtn, [id="saveProfileBtn"], #facSaveProfileBtn, #stuSaveProfileBtn, .save-profile-btn');
    saveBtns.forEach(btn => {
        btn.onclick = (e) => {
            if (e && typeof e.preventDefault === 'function') e.preventDefault();
            handleUpdateProfile(e);
        };
    });
}

function toggleProfileEditMode(isEdit, isCancel = false, triggerBtn = null) {
    if (window.currentUser) currentUser = window.currentUser;
    isEditMode = !!isEdit;
    isEditing = !!isEdit;
    window.isEditMode = isEditMode;
    window.isEditing = isEditing;
    clearProfileInlineErrors();

    // Determine target container scopes
    const scopes = [];
    if (triggerBtn && triggerBtn.nodeType) {
        const c = triggerBtn.closest('form') || triggerBtn.closest('.profile-card') || triggerBtn.closest('.profile-container') || triggerBtn.closest('#facView_profile, #stuView_profile');
        if (c) scopes.push(c);
    }
    if (scopes.length === 0) {
        const forms = document.querySelectorAll('#facProfileForm, #stuProfileForm, #updateProfileForm, .profile-card form');
        forms.forEach(f => {
            const parentView = f.closest('#facView_profile, #stuView_profile');
            if (!parentView || !parentView.classList.contains('hidden')) {
                scopes.push(f);
            }
        });
        if (scopes.length === 0 && forms.length > 0) {
            scopes.push(...forms);
        }
        if (scopes.length === 0) {
            scopes.push(document);
        }
    }

    scopes.forEach(scope => {
        // Strictly target only the 3 profile fields
        let nameInput = scope.querySelector('#facProfileName, #stuProfileName, #fullName, input[name="name"]');
        let emailInput = scope.querySelector('#facProfileEmail, #stuProfileEmail, #email, input[name="email"]');
        let usernameInput = scope.querySelector('#facProfileUsername, #stuProfileUsername, #username, input[name="username"]');

        if (!nameInput || !emailInput || !usernameInput) {
            const isFaculty = currentUser && currentUser.role && currentUser.role.toLowerCase() === 'faculty';
            const prefix = isFaculty ? 'fac' : 'stu';
            if (!nameInput) nameInput = document.querySelector('#' + prefix + 'ProfileName, #fullName, input[name="name"]');
            if (!emailInput) emailInput = document.querySelector('#' + prefix + 'ProfileEmail, #email, input[name="email"]');
            if (!usernameInput) usernameInput = document.querySelector('#' + prefix + 'ProfileUsername, #username, input[name="username"]');
        }

        const inputs = [nameInput, emailInput, usernameInput].filter(Boolean);

        // Snapshot original values when entering edit mode so Cancel can always revert
        if (isEdit) {
            if (!window.profileOriginalState || !window.profileOriginalState.name) {
                profileOriginalState = {
                    name: nameInput ? nameInput.value : '',
                    fullName: nameInput ? nameInput.value : '',
                    email: emailInput ? emailInput.value : '',
                    username: usernameInput ? usernameInput.value : ''
                };
                window.profileOriginalState = profileOriginalState;
            }
        }

        if (isCancel) {
            const activeOriginal = window.profileOriginalState || profileOriginalState || {};
            if (nameInput) nameInput.value = activeOriginal.fullName || activeOriginal.name || '';
            if (emailInput) emailInput.value = activeOriginal.email || '';
            if (usernameInput) usernameInput.value = activeOriginal.username || '';
        }

        inputs.forEach(input => {
            if (isEdit) {
                input.disabled = false;
                input.readOnly = false;
                input.removeAttribute('disabled');
                input.removeAttribute('readonly');
                input.classList.remove('bg-slate-100', 'cursor-not-allowed', 'text-slate-500', 'pointer-events-none');
                input.classList.add('bg-white', 'text-slate-900');
                input.style.pointerEvents = 'auto';
                input.style.cursor = 'text';
                input.style.backgroundColor = '#ffffff';
                input.style.color = '#0f172a';
            } else {
                input.disabled = true;
                input.readOnly = true;
                input.setAttribute('disabled', 'true');
                input.setAttribute('readonly', 'true');
                input.classList.add('bg-slate-100', 'cursor-not-allowed', 'text-slate-500');
                input.classList.remove('bg-white', 'text-slate-900', 'border-indigo-500', 'border-violet-500', '!border-rose-500', 'bg-rose-50/40');
                input.style.pointerEvents = 'none';
                input.style.cursor = 'not-allowed';
                input.style.backgroundColor = '#f1f5f9';
                input.style.color = '#64748b';
            }
        });

        // Toggle buttons in this scope or globally
        const getEls = (sel) => {
            const list = scope.querySelectorAll(sel);
            return (list && list.length > 0) ? list : document.querySelectorAll(sel);
        };

        const editBtns = getEls('.edit-profile-btn, #editProfileBtn, #facEditProfileBtn, #stuEditProfileBtn, #headerEditProfileBtn');
        const saveBtns = getEls('.save-profile-btn, #saveProfileBtn, #facSaveProfileBtn, #stuSaveProfileBtn');
        const cancelBtns = getEls('.cancel-profile-btn, #cancelProfileBtn, #facCancelProfileBtn, #stuCancelProfileBtn');
        const viewGroups = getEls('.profile-view-btn-group, #profileViewBtnGroup, #facProfileViewBtnGroup, #stuProfileViewBtnGroup');
        const editGroups = getEls('.profile-edit-btn-group, #profileEditBtnGroup, #facProfileEditBtnGroup, #stuProfileEditBtnGroup');

        if (isEdit) {
            editBtns.forEach(btn => {
                btn.style.setProperty('display', 'none', 'important');
                btn.classList.add('hidden');
            });
            saveBtns.forEach(btn => {
                btn.style.setProperty('display', 'inline-flex', 'important');
                btn.classList.remove('hidden');
                btn.disabled = false;
                btn.removeAttribute('disabled');
            });
            cancelBtns.forEach(btn => {
                btn.style.setProperty('display', 'inline-flex', 'important');
                btn.classList.remove('hidden');
                btn.disabled = false;
                btn.removeAttribute('disabled');
            });
            viewGroups.forEach(grp => {
                grp.style.setProperty('display', 'none', 'important');
                grp.classList.add('hidden');
            });
            editGroups.forEach(grp => {
                grp.classList.remove('hidden');
                grp.style.setProperty('display', 'flex', 'important');
            });
            if (nameInput) {
                try {
                    nameInput.focus();
                    if (typeof nameInput.setSelectionRange === 'function') {
                        nameInput.setSelectionRange(nameInput.value.length, nameInput.value.length);
                    }
                } catch (e) { }
            }
        } else {
            editBtns.forEach(btn => {
                btn.style.setProperty('display', 'inline-flex', 'important');
                btn.classList.remove('hidden');
                btn.disabled = false;
                btn.removeAttribute('disabled');
            });
            saveBtns.forEach(btn => {
                btn.style.setProperty('display', 'none', 'important');
                btn.classList.add('hidden');
            });
            cancelBtns.forEach(btn => {
                btn.style.setProperty('display', 'none', 'important');
                btn.classList.add('hidden');
            });
            viewGroups.forEach(grp => {
                grp.classList.remove('hidden');
                grp.style.removeProperty('display');
            });
            editGroups.forEach(grp => {
                grp.classList.add('hidden');
                grp.style.setProperty('display', 'none', 'important');
            });
        }
    });
}
window.toggleProfileEditMode = toggleProfileEditMode;

async function loadProfileView(forceReset = false) {
    if (!currentUser) return;
    try {
        const isFaculty = currentUser.role && currentUser.role.toLowerCase() === 'faculty';
        const prefix = isFaculty ? 'fac' : 'stu';

        const endpoint = isFaculty ? '/api/faculty/profile' : '/api/student/profile';
        let res = await fetch(API_BASE + endpoint, {
            headers: getAuthHeaders()
        });
        if (!res.ok) {
            res = await fetch(API_BASE + '/api/user/profile', {
                headers: getAuthHeaders()
            });
        }
        if (!res.ok) {
            res = await fetch(API_BASE + '/api/users/profile', {
                headers: getAuthHeaders()
            });
        }

        let u = currentUser;
        if (res.ok) {
            const json = await res.json();
            if (json && json.success && json.user) {
                u = json.user;
            }
        }

        currentUser = { ...currentUser, ...u };
        saveUserToStorage();
        updateUserUI();

        const nameVal = u.name || u.fullName || '';
        const emailVal = u.email || '';
        const usernameVal = u.username || (isFaculty ? 'faculty' : 'student');

        // Store original values for cancel/revert
        profileOriginalState = {
            name: nameVal,
            fullName: nameVal,
            email: emailVal,
            username: usernameVal
        };
        window.profileOriginalState = profileOriginalState;

        // If user already entered edit mode, don't overwrite values or reset to read-only unless forceReset
        if (forceReset || (!isEditMode && !isEditing)) {
            const allNameInputs = document.querySelectorAll('#facProfileName, #stuProfileName, #fullName, input[name="name"]');
            const allEmailInputs = document.querySelectorAll('#facProfileEmail, #stuProfileEmail, #email, input[name="email"]');
            const allUsernameInputs = document.querySelectorAll('#facProfileUsername, #stuProfileUsername, #username, input[name="username"]');

            allNameInputs.forEach(input => input.value = nameVal);
            allEmailInputs.forEach(input => input.value = emailVal);
            allUsernameInputs.forEach(input => input.value = usernameVal);

            // Always initialize in Read-only state
            toggleProfileEditMode(false, false);
        }

        // Update headers and avatars
        const headerName = document.getElementById(prefix + 'ProfileHeaderName') || document.getElementById('profileHeaderName');
        const headerUsername = document.getElementById(prefix + 'ProfileHeaderUsername') || document.getElementById('profileHeaderUsername');
        const initials = (nameVal || 'User').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

        if (headerName) headerName.innerText = nameVal || 'User Profile';
        if (headerUsername) headerUsername.innerText = '@' + usernameVal;

        const initialEls = document.querySelectorAll('#facProfileAvatarInitials, #stuProfileAvatarInitials, #userAvatar');
        initialEls.forEach(el => {
            if (el) el.innerText = initials;
        });

        attachProfileButtonListeners();
        attachProfileFormListeners();
        attachPasswordToggles();
        attachInputClearErrorListeners();
    } catch (err) {
        console.warn('Profile load error:', err);
        if (forceReset || (!isEditMode && !isEditing)) {
            toggleProfileEditMode(false, false);
        }
        attachProfileButtonListeners();
        attachProfileFormListeners();
        attachPasswordToggles();
        attachInputClearErrorListeners();
    }
}

async function handleUpdateProfile(e) {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    if (window.currentUser) currentUser = window.currentUser;
    if (!currentUser) return;

    clearProfileInlineErrors();

    const isFaculty = currentUser.role && currentUser.role.toLowerCase() === 'faculty';
    const form = (e && e.target && e.target.tagName === 'FORM')
        ? e.target
        : (e && e.target ? e.target.closest('form') : document.getElementById(isFaculty ? 'facProfileForm' : 'stuProfileForm') || document.getElementById('updateProfileForm'));

    const {
        nameInputs,
        emailInputs,
        usernameInputs
    } = getProfileInputs(form);

    const nameInp = (form && form.querySelector('#facProfileName, #stuProfileName, #fullName, input[name="name"]')) || nameInputs[0];
    const emailInp = (form && form.querySelector('#facProfileEmail, #stuProfileEmail, #email, input[name="email"]')) || emailInputs[0];
    const userInp = (form && form.querySelector('#facProfileUsername, #stuProfileUsername, #username, input[name="username"]')) || usernameInputs[0];

    const name = (nameInp ? nameInp.value : '').trim();
    const email = (emailInp ? emailInp.value : '').trim();
    const username = (userInp ? userInp.value : '').trim();

    let hasError = false;

    // 1. Validate Full Name
    if (!name) {
        showProfileInlineError('fullName', 'Full Name is required');
        hasError = true;
    }

    // 2. Validate Email Address
    if (!email) {
        showProfileInlineError('email', 'Email Address is required');
        hasError = true;
    } else {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showProfileInlineError('email', 'Please provide a valid email address');
            hasError = true;
        }
    }

    // 3. Validate Username
    if (!username) {
        showProfileInlineError('username', 'Username is required');
        hasError = true;
    } else if (username.length < 3) {
        showProfileInlineError('username', 'Username must be at least 3 characters long');
        hasError = true;
    } else if (!/^[a-zA-Z0-9_.-]+$/.test(username)) {
        showProfileInlineError('username', 'Username can only contain letters, numbers, hyphens, underscores and dots');
        hasError = true;
    }

    if (hasError) {
        showToast('Please fix the validation errors in the form', true);
        return;
    }

    // Disable "Save Changes" button during pending API calls to prevent double-submissions
    const saveBtns = document.querySelectorAll('#saveProfileBtn, .save-profile-btn');
    const originalTexts = [];
    saveBtns.forEach(btn => {
        originalTexts.push(btn.innerHTML);
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1.5"></i> Saving...';
    });

    try {
        const payload = {
            fullName: name,
            name: name,
            email: email,
            username: username
        };

        const endpoint = isFaculty ? '/api/faculty/profile' : '/api/student/profile';
        let res = await fetch(API_BASE + endpoint, {
            method: 'PUT',
            headers: getAuthHeaders(),
            body: JSON.stringify(payload)
        });
        if (!res.ok && (res.status === 404 || res.status === 405)) {
            res = await fetch(API_BASE + '/api/user/profile', {
                method: 'PUT',
                headers: getAuthHeaders(),
                body: JSON.stringify(payload)
            });
        }
        if (!res.ok && (res.status === 404 || res.status === 405)) {
            res = await fetch(API_BASE + '/api/users/profile', {
                method: 'PUT',
                headers: getAuthHeaders(),
                body: JSON.stringify(payload)
            });
        }

        const json = await res.json().catch(() => ({}));

        if (!res.ok || !json.success) {
            const msg = json.message || 'Profile update failed';
            if (json.field === 'email' || /email/i.test(msg)) {
                showProfileInlineError('email', msg);
            } else if (json.field === 'username' || /username/i.test(msg)) {
                showProfileInlineError('username', msg);
            } else if (json.field === 'fullName' || /name/i.test(msg)) {
                showProfileInlineError('fullName', msg);
            }
            showToast(msg, true);
            return;
        }

        const updatedUser = json.user || {};
        const newName = updatedUser.name || updatedUser.fullName || name;
        const newEmail = updatedUser.email || email;
        const newUsername = updatedUser.username || username;

        // Update active session state
        currentUser = {
            ...currentUser,
            ...updatedUser,
            name: newName,
            fullName: newName,
            email: newEmail,
            username: newUsername
        };

        // Immediately persist to localStorage
        saveUserToStorage();

        // Cache new values as original
        profileOriginalState = {
            name: newName,
            fullName: newName,
            email: newEmail,
            username: newUsername
        };
        window.profileOriginalState = profileOriginalState;

        // Dynamically update UI
        updateUserUI();

        const prefix = isFaculty ? 'fac' : 'stu';
        const headerName = document.getElementById(prefix + 'ProfileHeaderName') || document.getElementById('profileHeaderName');
        const headerUsername = document.getElementById(prefix + 'ProfileHeaderUsername') || document.getElementById('profileHeaderUsername');
        const initials = (newName || 'User').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

        if (headerName) headerName.innerText = newName;
        if (headerUsername) headerUsername.innerText = '@' + newUsername;

        const initialEls = document.querySelectorAll('#facProfileAvatarInitials, #stuProfileAvatarInitials, #userAvatar');
        initialEls.forEach(el => {
            if (el) el.innerText = initials;
        });

        // Set inputs to updated values
        const allNameInputs = document.querySelectorAll('#facProfileName, #stuProfileName, #fullName, input[name="name"]');
        const allEmailInputs = document.querySelectorAll('#facProfileEmail, #stuProfileEmail, #email, input[name="email"]');
        const allUsernameInputs = document.querySelectorAll('#facProfileUsername, #stuProfileUsername, #username, input[name="username"]');
        allNameInputs.forEach(input => input.value = newName);
        allEmailInputs.forEach(input => input.value = newEmail);
        allUsernameInputs.forEach(input => input.value = newUsername);

        // Auto-revert fields to Read-only with Edit Profile button visible
        toggleProfileEditMode(false, false, form);

        // Show toast notification
        showToast('Profile updated successfully.');
    } catch (err) {
        console.error('Update profile error:', err);
        showToast('Server error updating profile', true);
    } finally {
        saveBtns.forEach((btn, idx) => {
            btn.disabled = false;
            btn.innerHTML = originalTexts[idx] || '<i class="fa-solid fa-check mr-1.5"></i> Save Changes';
        });
    }
}

async function handleChangePassword(e) {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    if (!currentUser) return;
    const isFaculty = currentUser.role && currentUser.role.toLowerCase() === 'faculty';
    const prefix = isFaculty ? 'fac' : 'stu';

    const currInput = document.getElementById('currentPassword') || document.getElementById(prefix + 'CurrentPass') || document.getElementById('facCurrentPass') || document.getElementById('stuCurrentPass');
    const newInput = document.getElementById('newPassword') || document.getElementById(prefix + 'NewPass') || document.getElementById('facNewPass') || document.getElementById('stuNewPass');
    const confInput = document.getElementById('confirmPassword') || document.getElementById(prefix + 'ConfirmPass') || document.getElementById('facConfirmPass') || document.getElementById('stuConfirmPass');

    const currentPassword = currInput ? currInput.value : '';
    const newPassword = newInput ? newInput.value : '';
    const confirmPassword = confInput ? confInput.value : '';

    const currErr = document.getElementById('currentPasswordError');
    const newErr = document.getElementById('newPasswordError');
    const confErr = document.getElementById('confirmPasswordError');
    if (currErr) { currErr.innerText = ''; currErr.classList.add('hidden'); }
    if (newErr) { newErr.innerText = ''; newErr.classList.add('hidden'); }
    if (confErr) { confErr.innerText = ''; confErr.classList.add('hidden'); }

    if (!currentPassword) {
        if (currErr) { currErr.innerText = 'Current password is required'; currErr.classList.remove('hidden'); }
        showToast('Current password is required', true);
        return;
    }

    if (!newPassword) {
        if (newErr) { newErr.innerText = 'New password is required'; newErr.classList.remove('hidden'); }
        showToast('New password is required', true);
        return;
    }

    if (newPassword.length < 6) {
        if (newErr) { newErr.innerText = 'Password must be at least 6 characters long'; newErr.classList.remove('hidden'); }
        showToast('Password must be at least 6 characters long', true);
        return;
    }

    if (!confirmPassword) {
        if (confErr) { confErr.innerText = 'Please confirm your new password'; confErr.classList.remove('hidden'); }
        showToast('Please confirm your new password', true);
        return;
    }

    if (newPassword !== confirmPassword) {
        if (confErr) { confErr.innerText = 'New Password and Confirm New Password must match'; confErr.classList.remove('hidden'); }
        showToast('New Password and Confirm New Password must match', true);
        return;
    }

    const updateBtn = document.getElementById('updatePasswordBtn') || (e && e.target ? e.target.querySelector('button[type="submit"]') : null);
    const originalBtnText = updateBtn ? updateBtn.innerHTML : 'Update Password';
    if (updateBtn) {
        updateBtn.disabled = true;
        updateBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1.5"></i> Updating...';
    }

    try {
        const endpoint = isFaculty ? '/api/faculty/change-password' : '/api/user/change-password';
        let res = await fetch(API_BASE + endpoint, {
            method: 'PUT',
            headers: getAuthHeaders(),
            body: JSON.stringify({ currentPassword, newPassword, confirmPassword, confirmNewPassword: confirmPassword })
        });
        if (!res.ok && res.status === 404) {
            res = await fetch(API_BASE + '/api/user/change-password', {
                method: 'PUT',
                headers: getAuthHeaders(),
                body: JSON.stringify({ currentPassword, newPassword, confirmPassword, confirmNewPassword: confirmPassword })
            });
        }
        if (!res.ok && res.status === 404) {
            res = await fetch(API_BASE + '/api/users/change-password', {
                method: 'PUT',
                headers: getAuthHeaders(),
                body: JSON.stringify({ currentPassword, newPassword, confirmPassword, confirmNewPassword: confirmPassword })
            });
        }
        if (!res.ok && res.status === 404) {
            res = await fetch(API_BASE + '/api/auth/change-password', {
                method: 'PUT',
                headers: getAuthHeaders(),
                body: JSON.stringify({ currentPassword, newPassword, confirmPassword, confirmNewPassword: confirmPassword })
            });
        }
        const json = await res.json().catch(() => ({}));
        if (res.ok && json.success) {
            showToast('Password updated successfully');
            if (currInput) currInput.value = '';
            if (newInput) newInput.value = '';
            if (confInput) confInput.value = '';
        } else {
            const errMsg = json.message || 'Password update failed';
            if (/current/i.test(errMsg) && currErr) {
                currErr.innerText = errMsg;
                currErr.classList.remove('hidden');
            }
            showToast(errMsg, true);
        }
    } catch (err) {
        showToast('Server error changing password', true);
    } finally {
        if (updateBtn) {
            updateBtn.disabled = false;
            updateBtn.innerHTML = originalBtnText;
        }
    }
}

// --- SYLLABUS MANAGEMENT WITH PERSISTENCE & INLINE CRUD ---
async function loadSyllabusList() {
    const container = document.getElementById('syllabusContainer');
    if (!container) return;

    const semFilter = document.getElementById('sylSemesterFilter');
    const sem = normalizeSemester(semFilter ? semFilter.value : 1);
    if (semFilter && (!semFilter.value || semFilter.value !== String(sem))) {
        semFilter.value = String(sem);
    }
    container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs"><i class="fa-solid fa-spinner fa-spin mr-1.5"></i> Loading curriculum syllabus...</div>';

    const list = await fetchSyllabusForSemester(sem);
    if (list === null) {
        container.innerHTML = '<div class="text-center py-10 text-rose-500 font-semibold text-xs"><i class="fa-solid fa-triangle-exclamation mr-1.5"></i> Unable to load syllabus. Please try again.</div>';
        return;
    }
    if (list.length === 0) {
        container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">No syllabus records found for Semester ' + sem + '. Click "+ Add Topic" to create curriculum entries.</div>';
        return;
    }

    renderFacultySyllabus(list, container);
}

function renderFacultySyllabus(list, container) {
    if (!container) return;
    container.innerHTML = list.map(sub => {
        return '<div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">' +
            '<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-3 gap-2">' +
            '<div>' +
            '<span class="text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">Semester ' + sub.semester + ' • ' + (sub.courseCode || 'CS') + '</span>' +
            '<h3 class="font-bold text-slate-900 text-base mt-1">' + sub.subject + '</h3>' +
            '</div>' +
            '<span class="text-xs font-semibold px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg">' + (sub.subjectType || 'Theory') + '</span>' +
            '</div>' +
            '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">' +
            (sub.units || []).map(u => {
                return '<div class="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-3 flex flex-col justify-between">' +
                    '<div>' +
                    '<div class="flex justify-between items-center pb-2 border-b border-slate-200">' +
                    '<span class="font-bold text-indigo-950">Unit ' + u.unitNumber + ': ' + u.unitTitle + '</span>' +
                    '</div>' +
                    '<ul class="space-y-2 pt-2">' +
                    (u.topics || []).map((top, topIdx) => {
                        const safeTop = top.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                        return '<li class="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-200 text-[11px] group">' +
                            '<span class="font-medium text-slate-800 flex-1 mr-2 leading-relaxed">' + top + '</span>' +
                            '<div class="flex items-center space-x-1 flex-shrink-0">' +
                            '<button type="button" onclick="editTopicInline(\'' + sub._id + '\', ' + u.unitNumber + ', ' + topIdx + ', \'' + safeTop + '\')" class="p-1 text-slate-400 hover:text-indigo-600 rounded cursor-pointer" title="Edit Topic"><i class="fa-solid fa-pen-to-square"></i></button>' +
                            '<button type="button" onclick="deleteTopicInline(\'' + sub._id + '\', ' + u.unitNumber + ', ' + topIdx + ', \'' + safeTop + '\')" class="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer" title="Delete Topic"><i class="fa-solid fa-trash"></i></button>' +
                            '</div>' +
                            '</li>';
                    }).join('') +
                    '</ul>' +
                    '</div>' +
                    '<div class="pt-2 border-t border-slate-200">' +
                    '<button type="button" onclick="openAddTopicModalForUnit(\'' + sub._id + '\', ' + u.unitNumber + ', \'' + sub.subject.replace(/'/g, "\\'") + '\')" class="w-full py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] rounded-lg transition-all flex items-center justify-center space-x-1 cursor-pointer">' +
                    '<i class="fa-solid fa-plus text-xs"></i> <span>Add Topic to Unit ' + u.unitNumber + '</span>' +
                    '</button>' +
                    '</div>' +
                    '</div>';
            }).join('') +
            '</div>' +
            '</div>';
    }).join('');
}

// --- STUDENT SYLLABUS LOADING & DISPLAY ---
async function loadStudentSyllabus() {
    const container = document.getElementById('stuSyllabusContainer');
    if (!container) return;

    const semSelect = document.getElementById('stuSylSemester');
    let sem = 1;
    if (semSelect && semSelect.value) {
        sem = normalizeSemester(semSelect.value);
    } else if (currentUser && currentUser.semester) {
        sem = normalizeSemester(currentUser.semester);
    }
    if (semSelect && (!semSelect.value || semSelect.value !== String(sem))) {
        semSelect.value = String(sem);
    }

    container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs"><i class="fa-solid fa-spinner fa-spin mr-1.5"></i> Loading curriculum syllabus...</div>';

    const list = await fetchSyllabusForSemester(sem);
    if (list === null) {
        container.innerHTML = '<div class="text-center py-10 text-rose-500 font-semibold text-xs"><i class="fa-solid fa-triangle-exclamation mr-1.5"></i> Unable to load syllabus. Please try again.</div>';
        return;
    }
    if (list.length === 0) {
        container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">No syllabus records found for Semester ' + sem + '.</div>';
        return;
    }

    renderStudentSyllabus(list, container);
}

function renderStudentSyllabus(list, container) {
    if (!container) return;
    container.innerHTML = list.map(sub => {
        return '<div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">' +
            '<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-3 gap-2">' +
            '<div>' +
            '<span class="text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">Semester ' + sub.semester + ' • ' + (sub.courseCode || 'CS') + '</span>' +
            '<h3 class="font-bold text-slate-900 text-base mt-1">' + sub.subject + '</h3>' +
            '</div>' +
            '<span class="text-xs font-semibold px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg">' + (sub.subjectType || 'Theory') + '</span>' +
            '</div>' +
            '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">' +
            (sub.units || []).map(u => {
                return '<div class="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-3 flex flex-col justify-between">' +
                    '<div>' +
                    '<div class="flex justify-between items-center pb-2 border-b border-slate-200">' +
                    '<span class="font-bold text-indigo-950">Unit ' + u.unitNumber + ': ' + u.unitTitle + '</span>' +
                    '<span class="text-[10px] font-semibold text-slate-400 bg-white px-2 py-0.5 rounded-full border border-slate-200">' + (u.topics ? u.topics.length : 0) + ' Topics</span>' +
                    '</div>' +
                    '<ul class="space-y-1.5 pt-2">' +
                    (u.topics || []).map(top => {
                        return '<li class="flex items-start p-2 bg-white rounded-lg border border-slate-200 text-[11px]">' +
                            '<i class="fa-solid fa-circle-check text-indigo-500 mr-2 mt-0.5 text-[10px] flex-shrink-0"></i>' +
                            '<span class="font-medium text-slate-800 leading-relaxed">' + top + '</span>' +
                            '</li>';
                    }).join('') +
                    '</ul>' +
                    '</div>' +
                    '</div>';
            }).join('') +
            '</div>' +
            '</div>';
    }).join('');
}

// Inline Topic Edit with MongoDB Persistence
async function editTopicInline(syllabusId, unitNumber, topicIndex, currentTopic) {
    const newTopic = prompt('Edit Syllabus Topic for Unit ' + unitNumber + ':', currentTopic);
    if (!newTopic || newTopic.trim() === '' || newTopic.trim() === currentTopic) return;

    try {
        const res = await fetch(API_BASE + '/api/syllabus/' + syllabusId + '/units/' + unitNumber + '/topics/' + topicIndex, {
            method: 'PUT',
            headers: getAuthHeaders(),
            body: JSON.stringify({ newTopic: newTopic.trim() })
        });
        const json = await res.json();
        if (json.success) {
            cachedSyllabusBySem = {};
            showToast('Syllabus topic updated and persisted in MongoDB!');
            await loadSyllabusList();
        } else {
            showToast(json.message || 'Failed to update topic', true);
        }
    } catch (err) {
        showToast('Error syncing with database', true);
    }
}

// Inline Topic Delete with MongoDB Persistence
async function deleteTopicInline(syllabusId, unitNumber, topicIndex, currentTopic) {
    if (!confirm('Are you sure you want to delete topic "' + currentTopic + '" from Unit ' + unitNumber + '?')) return;

    try {
        const res = await fetch(API_BASE + '/api/syllabus/' + syllabusId + '/units/' + unitNumber + '/topics/' + topicIndex, {
            method: 'DELETE',
            headers: getAuthHeaders()
        });
        const json = await res.json();
        if (json.success) {
            cachedSyllabusBySem = {};
            showToast('Syllabus topic removed from MongoDB!');
            await loadSyllabusList();
        } else {
            showToast(json.message || 'Failed to delete topic', true);
        }
    } catch (err) {
        showToast('Error deleting topic from database', true);
    }
}

// Modal Handlers for Adding Syllabus Topics
function openAddTopicModal() {
    const modal = document.getElementById('syllabusTopicModal');
    if (!modal) return;
    const sylIdInput = document.getElementById('modalTopicSyllabusId');
    if (sylIdInput) sylIdInput.value = '';
    const sem = document.getElementById('sylSemesterFilter')?.value || 1;
    const semSelect = document.getElementById('modalTopicSemester');
    if (semSelect) semSelect.value = sem;
    handleModalSemesterChange();
    modal.classList.remove('hidden');
}

function openAddTopicModalForUnit(syllabusId, unitNumber, subject) {
    const modal = document.getElementById('syllabusTopicModal');
    if (!modal) return;
    const sylIdInput = document.getElementById('modalTopicSyllabusId');
    if (sylIdInput) sylIdInput.value = syllabusId;
    const unitSelect = document.getElementById('modalTopicUnit');
    if (unitSelect) unitSelect.value = unitNumber;
    const sem = document.getElementById('sylSemesterFilter')?.value || 1;
    const semSelect = document.getElementById('modalTopicSemester');
    if (semSelect) semSelect.value = sem;
    handleModalSemesterChange(subject);
    modal.classList.remove('hidden');
}

function closeTopicModal() {
    const modal = document.getElementById('syllabusTopicModal');
    if (modal) modal.classList.add('hidden');
}

async function handleModalSemesterChange(defaultSubject = '') {
    const sem = document.getElementById('modalTopicSemester')?.value || 1;
    await populateSubjectSelect(sem, 'modalTopicSubject', defaultSubject);
}

async function handleSaveTopicModal(e) {
    if (e && e.preventDefault) e.preventDefault();
    let syllabusId = document.getElementById('modalTopicSyllabusId')?.value;
    const semester = document.getElementById('modalTopicSemester')?.value || 1;
    const unitNumber = Number(document.getElementById('modalTopicUnit')?.value || 1);
    const subject = document.getElementById('modalTopicSubject')?.value;
    const topic = document.getElementById('modalTopicTitle')?.value?.trim();

    if (!topic) {
        showToast('Please enter a topic title', true);
        return;
    }

    try {
        if (!syllabusId) {
            // Find matching syllabus ID from current semester list
            const list = await fetchSyllabusForSemester(semester);
            const found = list.find(s => s.subject === subject);
            if (found) {
                syllabusId = found._id;
            }
        }

        if (!syllabusId) {
            showToast('Please select a valid subject first', true);
            return;
        }

        const res = await fetch(API_BASE + '/api/syllabus/' + syllabusId + '/units/' + unitNumber + '/topics', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({ topic })
        });
        const json = await res.json();
        if (json.success) {
            cachedSyllabusBySem = {};
            closeTopicModal();
            const titleInput = document.getElementById('modalTopicTitle');
            if (titleInput) titleInput.value = '';
            showToast('New topic added and persisted to MongoDB!');
            await loadSyllabusList();
        } else {
            showToast(json.message || 'Failed to add topic', true);
        }
    } catch (err) {
        showToast('Server connection error adding topic', true);
    }
}

// Explicitly expose Syllabus & Topic handlers to window for HTML event handlers
window.fetchSyllabusForSemester = fetchSyllabusForSemester;
window.loadSyllabusList = loadSyllabusList;
window.renderFacultySyllabus = renderFacultySyllabus;
window.loadStudentSyllabus = loadStudentSyllabus;
window.renderStudentSyllabus = renderStudentSyllabus;
window.editTopicInline = editTopicInline;
window.deleteTopicInline = deleteTopicInline;
window.openAddTopicModal = openAddTopicModal;
window.openAddTopicModalForUnit = openAddTopicModalForUnit;
window.closeTopicModal = closeTopicModal;
window.handleModalSemesterChange = handleModalSemesterChange;
window.handleSaveTopicModal = handleSaveTopicModal;

// --- STUDY MATERIALS ---
async function loadFacultyMaterials() {
    const container = document.getElementById('facultyMaterialsContainer');
    if (!container) return;
    try {
        const res = await fetch(API_BASE + '/api/study-materials');
        const json = await res.json();
        const list = json.data || [];

        if (list.length === 0) {
            container.innerHTML = '<div class="col-span-3 text-center py-10 text-slate-400 text-xs">No custom study notes uploaded.</div>';
            return;
        }

        container.innerHTML = list.map(m => {
            return '<div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">' +
                '<div>' +
                '<span class="text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">Sem ' + m.semester + ' • Unit ' + m.unit + '</span>' +
                '<h4 class="font-bold text-slate-900 text-sm mt-2">' + m.title + '</h4>' +
                '<p class="text-xs text-slate-500 font-semibold">' + m.subject + ' - ' + m.topic + '</p>' +
                '<div class="mt-3 text-xs text-slate-600 line-clamp-3 leading-relaxed">' + m.content.replace(/<[^>]*>?/gm, '') + '</div>' +
                '</div>' +
                '<div class="pt-3 border-t border-slate-100 text-[11px] text-slate-400 font-medium">Author: ' + (m.author || 'CS Faculty') + '</div>' +
                '</div>';
        }).join('');
    } catch (err) {
        container.innerHTML = '<div class="col-span-3 text-center py-10 text-rose-500 text-xs">Error loading materials.</div>';
    }
}

async function loadStudentMaterialsList() {
    const container = document.getElementById('stuMaterialsContainer');
    if (!container) return;

    const sem = document.getElementById('stuMatSemester')?.value || 1;
    const sub = document.getElementById('stuMatSubject')?.value;
    const unit = document.getElementById('stuMatUnit')?.value;

    if (!sub) {
        container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">Please select a subject to load notes.</div>';
        return;
    }
    container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs"><i class="fa-solid fa-spinner fa-spin mr-1"></i> Loading structured study notes...</div>';

    const params = new URLSearchParams({ semester: sem, subject: sub });
    if (unit && unit !== '0') params.append('unit', unit);

    try {
        const res = await fetch(API_BASE + '/api/study-materials?' + params.toString());
        const json = await res.json();
        const list = json.data || [];

        if (list.length === 0) {
            container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">No notes found for this subject and unit selection.</div>';
            return;
        }

        container.innerHTML = list.map(m => {
            return '<div class="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">' +
                '<div class="flex justify-between items-start border-b border-slate-100 pb-3">' +
                '<div>' +
                '<span class="text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">Semester ' + m.semester + ' • Unit ' + m.unit + '</span>' +
                '<h3 class="font-bold text-slate-900 text-base mt-1">' + m.title + '</h3>' +
                '<p class="text-xs text-indigo-600 font-semibold">' + m.subject + ' &rarr; ' + m.topic + '</p>' +
                '</div>' +
                '</div>' +
                '<div class="prose max-w-none text-xs sm:text-sm text-slate-700 leading-relaxed space-y-3">' +
                m.content +
                '</div>' +
                '</div>';
        }).join('');
    } catch (err) {
        container.innerHTML = '<div class="text-center py-10 text-rose-500 text-xs">Failed to load study notes.</div>';
    }
}

// --- STUDENT QUESTION BANK (FULL MARKS CATEGORIZATION: 1M, 2M, 3M, 4M, 5M, 7M, 10M) ---
async function loadStudentQuestionBankList() {
    const container = document.getElementById('stuQBQuestionsContainer') || document.getElementById('stuQuestionListContainer');
    if (!container) return;

    const sem = document.getElementById('stuQBSemester')?.value || 1;
    const sub = document.getElementById('stuQBSubject')?.value;
    const unit = document.getElementById('stuQBUnit')?.value;
    const marks = document.getElementById('stuQBMarks')?.value;

    if (!sub) {
        container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">Please select a subject to browse questions.</div>';
        return;
    }
    container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs"><i class="fa-solid fa-spinner fa-spin mr-1"></i> Querying question repository...</div>';

    const params = new URLSearchParams({ semester: sem, subject: sub });
    if (unit && unit !== '0') params.append('unit', unit);
    if (marks) params.append('marks', marks);

    try {
        const res = await fetch(API_BASE + '/api/questions?' + params.toString());
        const json = await res.json();
        const list = json.data || [];

        if (list.length === 0) {
            container.innerHTML = '<div class="text-center py-10 text-slate-400 text-xs">No questions found matching your filter selection. Try selecting "All Marks Categories" or a different unit.</div>';
            return;
        }

        container.innerHTML = list.map((q, idx) => {
            const qMarks = Number(q.marks) || 2;
            const isMCQ = (qMarks === 1 || q.questionType === 'MCQ');
            let itemHtml = '<div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">' +
                '<div class="flex justify-between items-center">' +
                '<div class="flex flex-wrap items-center gap-2">' +
                '<span class="text-[10px] font-bold uppercase bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded border border-indigo-100">Unit ' + q.unit + '</span>' +
                '<span class="text-[10px] font-bold ' + (isMCQ ? 'bg-violet-100 text-violet-800 border border-violet-200' : 'bg-slate-900 text-white') + ' px-2 py-0.5 rounded">' + qMarks + ' Mark' + (qMarks > 1 ? 's' : '') + '</span>' +
                '<span class="text-[10px] font-bold ' + (isMCQ ? 'bg-amber-50 text-amber-800 border border-amber-200' : 'bg-blue-50 text-blue-800 border border-blue-200') + ' px-2 py-0.5 rounded">' + (isMCQ ? 'MCQ' : 'Theory') + '</span>' +
                '<span class="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">' + (q.topic || 'Core Concept') + '</span>' +
                '<span class="text-[10px] font-semibold text-slate-500">' + (q.difficulty || 'Medium') + '</span>' +
                '</div>' +
                '</div>' +
                '<h4 class="font-bold text-slate-900 text-xs sm:text-sm leading-relaxed">Q' + (idx + 1) + '. ' + q.question + '</h4>';

            if (isMCQ && q.options && q.options.length) {
                // 1 Mark MCQ: Render with 4 options and correct answer indicator
                itemHtml += '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">';
                q.options.forEach((opt, optIdx) => {
                    const isCorrect = (opt === q.correctAnswer);
                    itemHtml += '<div class="p-2.5 rounded-xl border flex items-center justify-between ' +
                        (isCorrect ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold shadow-xs' : 'bg-slate-50 border-slate-200 text-slate-700') + '">' +
                        '<div><span class="font-bold mr-1">(' + String.fromCharCode(65 + optIdx) + ')</span> ' + opt + '</div>' +
                        (isCorrect ? '<span class="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">Correct</span>' : '') +
                        '</div>';
                });
                itemHtml += '</div>';

                if (q.answer) {
                    itemHtml += '<div class="p-2.5 bg-indigo-50/70 border border-indigo-100 rounded-xl text-xs text-indigo-900 leading-relaxed">' +
                        '<span class="font-bold mr-1">Explanation:</span>' + q.answer +
                        '</div>';
                }
            } else {
                // 2M, 4M, 5M, 7M, 10M: Render Theory with Model Answer / Key Academic Points
                const modelAnswer = q.answer || q.correctAnswer || "Comprehensive academic model answer and key conceptual points compiled from curriculum syllabus.";
                itemHtml += '<details class="text-xs text-slate-700 bg-slate-50 p-3.5 rounded-xl border border-slate-200 cursor-pointer group" open>' +
                    '<summary class="font-bold text-indigo-600 hover:text-indigo-800 flex items-center justify-between">' +
                    '<span><i class="fa-solid fa-book-open mr-1.5"></i>Model Answer & Key Academic Points</span>' +
                    '<span class="text-[10px] font-semibold text-slate-400">Theory Response</span>' +
                    '</summary>' +
                    '<div class="mt-2.5 text-xs leading-relaxed whitespace-pre-line text-slate-800 bg-white p-3.5 rounded-lg border border-slate-200 font-sans">' +
                    modelAnswer +
                    '</div>' +
                    '</details>';
            }

            itemHtml += '</div>';
            return itemHtml;
        }).join('');
    } catch (err) {
        container.innerHTML = '<div class="text-center py-10 text-rose-500 text-xs">Error loading questions from database.</div>';
    }
}

// --- STUDENT MCQ TIMED ASSESSMENT (SECURE DELIVERY, DUAL PDF) ---
async function startStudentMCQTest() {
    const sem = document.getElementById('stuTestSemester')?.value || document.getElementById('testSemester')?.value || 1;
    const sub = document.getElementById('stuTestSubject')?.value || document.getElementById('testSubject')?.value;
    const unit = document.getElementById('stuTestUnit')?.value || document.getElementById('testUnit')?.value || 0;
    const count = document.getElementById('stuTestCount')?.value || document.getElementById('testCount')?.value || 10;
    const difficulty = document.getElementById('stuTestDifficulty')?.value || 'Mixed';

    if (!sub) {
        showToast('Please select a subject first', true);
        return;
    }

    showToast('Fetching secure questions from assessment bank...');

    const params = new URLSearchParams({ semester: sem, subject: sub, count });
    if (unit && unit !== '0') params.append('unit', unit);
    if (difficulty && difficulty !== 'Mixed') params.append('difficulty', difficulty);

    try {
        const res = await fetch(API_BASE + '/api/tests/questions?' + params.toString());
        const json = await res.json();
        const questions = json.data || [];

        if (questions.length === 0) {
            showToast('No MCQs found for ' + sub + '. Check Question Bank or ask Faculty to populate questions.', true);
            return;
        }

        activeMCQTest = {
            semester: Number(sem),
            subject: sub,
            unit: (unit === 0 || unit === '0') ? 'All Units' : String(unit),
            difficulty: (difficulty === 'Mixed' ? 'Medium' : difficulty),
            questions: questions,
            durationMins: Number(count)
        };
        studentSelectedAnswers = {};
        latestStudentResult = null;
        testTimeTotal = Number(count) * 60;
        testTimeRemaining = testTimeTotal;

        // Toggle Views to Active Runner
        const configCard = document.getElementById('stuTestConfigCard') || document.getElementById('testSetupScreen');
        const activeContainer = document.getElementById('stuTestActiveContainer') || document.getElementById('testRunnerScreen');
        const resultContainer = document.getElementById('stuTestResultContainer') || document.getElementById('testResultScreen');

        if (configCard) configCard.classList.add('hidden');
        if (resultContainer) resultContainer.classList.add('hidden');
        if (activeContainer) activeContainer.classList.remove('hidden');

        // Set Header Title
        const titleEl = document.getElementById('stuTestActiveSubjectTitle') || document.getElementById('liveTestHeaderTitle');
        if (titleEl) {
            titleEl.innerText = sub + ' • Semester ' + sem + (unit && unit !== '0' ? ' (Unit ' + unit + ')' : '') + ' • ' + questions.length + ' Questions';
        }

        renderStudentTestQuestions();
        startTestCountdownTimer();
    } catch (err) {
        showToast('Failed to initialize test: ' + err.message, true);
    }
}

// Alias for backwards compatibility
function startMCQTest() {
    return startStudentMCQTest();
}

function renderStudentTestQuestions() {
    const container = document.getElementById('stuTestQuestionsList') || document.getElementById('liveTestQuestionsContainer');
    if (!container || !activeMCQTest || !activeMCQTest.questions) return;

    container.innerHTML = activeMCQTest.questions.map((q, idx) => {
        return '<div id="testQSection_' + idx + '" class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">' +
            '<div class="flex justify-between items-center border-b border-slate-100 pb-2.5">' +
            '<span class="font-bold text-slate-900 text-xs sm:text-sm">Question ' + (idx + 1) + ' of ' + activeMCQTest.questions.length + '</span>' +
            '<span class="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-bold">' + (q.marks || 1) + ' Mark</span>' +
            '</div>' +
            '<p class="text-xs sm:text-sm text-slate-900 font-semibold leading-relaxed">' + q.question + '</p>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">' +
            (q.options || []).map((opt, optIdx) => {
                const safeOpt = opt.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                return '<label class="flex items-center space-x-3 p-3 rounded-xl border border-slate-200 hover:bg-indigo-50/50 hover:border-indigo-300 cursor-pointer text-xs transition-all has-[:checked]:bg-indigo-50 has-[:checked]:border-indigo-400 has-[:checked]:font-bold">' +
                    '<input type="radio" name="testAns_' + q._id + '" value="' + safeOpt + '" onchange="recordStudentAnswer(\'' + q._id + '\', \'' + safeOpt + '\', ' + idx + ')" class="text-indigo-600 focus:ring-indigo-500">' +
                    '<span class="font-bold text-slate-700">(' + String.fromCharCode(65 + optIdx) + ')</span>' +
                    '<span class="text-slate-900">' + opt + '</span>' +
                    '</label>';
            }).join('') +
            '</div>' +
            '</div>';
    }).join('');
}

function recordStudentAnswer(questionId, selectedValue, idx) {
    studentSelectedAnswers[questionId] = selectedValue;
}

function startTestCountdownTimer() {
    if (testTimerInterval) clearInterval(testTimerInterval);
    const timerEl = document.getElementById('stuTestTimerDisplay') || document.getElementById('liveTestTimer');

    testTimerInterval = setInterval(() => {
        testTimeRemaining--;
        if (testTimeRemaining <= 0) {
            clearInterval(testTimerInterval);
            alert('Time has expired! Submitting test automatically.');
            submitStudentMCQTest();
            return;
        }
        const mins = Math.floor(testTimeRemaining / 60);
        const secs = testTimeRemaining % 60;
        if (timerEl) {
            timerEl.innerText = mins.toString().padStart(2, '0') + ':' + secs.toString().padStart(2, '0');
        }
    }, 1000);
}

// Dual PDF 1: Pre-Submission Questions and Options Only PDF (NO answers)
async function downloadQuestionsOnlyPDF() {
    if (!activeMCQTest || !activeMCQTest.questions || !activeMCQTest.questions.length) {
        showToast('No active test questions to export', true);
        return;
    }
    showToast('Generating Questions-Only PDF...');

    try {
        const res = await fetch(API_BASE + '/api/tests/export-questions-pdf', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                semester: activeMCQTest.semester,
                subject: activeMCQTest.subject,
                unit: activeMCQTest.unit,
                questions: activeMCQTest.questions
            })
        });

        if (!res.ok) throw new Error('PDF export failed');
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (activeMCQTest.subject || 'MCQ_Test').replace(/\s+/g, '_') + '_Questions_Only.pdf';
        document.body.appendChild(a);
        a.click();
        a.remove();
        showToast('Questions PDF downloaded successfully!');
    } catch (err) {
        showToast('Failed to download questions PDF: ' + err.message, true);
    }
}

function confirmSubmitTest() {
    return submitStudentMCQTest();
}

async function submitStudentMCQTest() {
    if (testTimerInterval) clearInterval(testTimerInterval);

    if (!activeMCQTest || !activeMCQTest.questions || !activeMCQTest.questions.length) return;

    // Calculate elapsed time (MM:SS)
    const totalSecs = (activeMCQTest.durationMins || 10) * 60;
    const remainingSecs = Math.max(0, testTimeRemaining || 0);
    const elapsedSecs = Math.max(1, totalSecs - remainingSecs);
    const mins = Math.floor(elapsedSecs / 60);
    const secs = elapsedSecs % 60;
    const timeTakenStr = mins.toString().padStart(2, '0') + ':' + secs.toString().padStart(2, '0');

    const user = (typeof getCurrentUser === 'function' ? getCurrentUser() : null) || currentUser || {};
    const studentId = String(user._id || user.id || 'student_default_id');
    const studentName = String(user.name || 'Anand Kumar');
    const studentEmail = String(user.email || 'student@college.edu');

    const answersPayload = activeMCQTest.questions.map(q => {
        const selected = studentSelectedAnswers[q._id];
        return {
            questionId: q._id,
            questionText: q.question,
            question: q.question,
            options: q.options || [],
            studentAnswer: (selected !== undefined && selected !== null && String(selected).trim() !== '') ? String(selected).trim() : 'Unanswered'
        };
    });

    showToast('Submitting and calculating score in MongoDB...');

    try {
        const res = await fetch(API_BASE + '/api/tests/submit', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                studentId,
                studentName,
                studentEmail,
                semester: Number(activeMCQTest.semester || 1),
                subject: activeMCQTest.subject,
                unit: activeMCQTest.unit || 'All Units',
                difficulty: activeMCQTest.difficulty || 'Medium',
                timeTaken: timeTakenStr,
                answers: answersPayload
            })
        });

        const json = await res.json();
        if (json.success && json.data) {
            latestStudentResult = json.data;
            renderStudentResult(json.data);
            const displayScore = json.data.score !== undefined ? json.data.score : json.data.obtainedMarks;
            showToast('Assessment submitted! Scored ' + displayScore + ' / ' + json.data.totalMarks);
            // Refresh MongoDB history and dashboard stats across the portal
            loadStudentAnalytics();
        } else {
            showToast(json.message || 'Grading error', true);
        }
    } catch (err) {
        showToast('Failed to submit test: ' + err.message, true);
    }
}

// Alias for backwards compatibility
function submitStudentAssessment() {
    return submitStudentMCQTest();
}

function renderStudentResult(result) {
    latestStudentResult = result;

    const activeContainer = document.getElementById('stuTestActiveContainer') || document.getElementById('testRunnerScreen');
    const resultContainer = document.getElementById('stuTestResultContainer') || document.getElementById('testResultScreen');

    if (activeContainer) activeContainer.classList.add('hidden');
    if (resultContainer) resultContainer.classList.remove('hidden');

    const score = result.score !== undefined ? result.score : (result.obtainedMarks !== undefined ? result.obtainedMarks : 0);
    const totalMarks = result.totalMarks || (result.questions ? result.questions.length : 10);
    const percentage = result.percentage !== undefined ? result.percentage : (totalMarks > 0 ? Number(((score / totalMarks) * 100).toFixed(1)) : 0);
    const correctCount = result.correctAnswers !== undefined ? result.correctAnswers : (result.correctCount !== undefined ? result.correctCount : 0);
    const wrongCount = result.wrongAnswers !== undefined ? result.wrongAnswers : (result.wrongCount !== undefined ? result.wrongCount : 0);
    const attemptedCount = result.attemptedQuestions !== undefined ? result.attemptedQuestions : (result.totalQuestions ? (result.totalQuestions - (result.unansweredCount || 0)) : correctCount + wrongCount);
    const timeTaken = result.timeTaken || 'N/A';
    const evalDate = new Date(result.submittedAt || result.createdAt || Date.now()).toLocaleString('en-IN', {
        dateStyle: 'medium',
        timeStyle: 'short'
    });

    const isPassed = percentage >= 40;

    resultContainer.innerHTML = '<div class="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">' +
        '<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-5 border-b border-slate-100 gap-3">' +
        '<div>' +
        '<div class="flex items-center space-x-2">' +
        '<span class="text-[10px] font-bold uppercase ' + (isPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800') + ' px-2.5 py-0.5 rounded-full">' +
        (isPassed ? 'Assessment Passed' : 'Needs Improvement') +
        '</span>' +
        '<span class="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">' + (result.difficulty || 'Medium') + '</span>' +
        '</div>' +
        '<h2 class="text-xl font-black text-slate-900 mt-1">' + result.subject + ' Scorecard</h2>' +
        '<p class="text-xs text-slate-500 mt-0.5">Semester ' + result.semester + (result.unit ? ' • Unit: ' + result.unit : '') + ' • Time Taken: ' + timeTaken + ' • Submitted on ' + evalDate + '</p>' +
        '</div>' +
        '<div class="flex flex-wrap items-center gap-2">' +
        '<button type="button" onclick="downloadCurrentTestResultPDF()" class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md flex items-center space-x-1.5 transition-all cursor-pointer">' +
        '<i class="fa-solid fa-file-pdf"></i>' +
        '<span>Download Scorecard PDF</span>' +
        '</button>' +
        '<button type="button" onclick="resetStudentTestView()" class="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer">' +
        'Take Another Test' +
        '</button>' +
        '<button type="button" onclick="switchStudentTab(\'analytics\')" class="px-3.5 py-2.5 bg-violet-50 hover:bg-violet-100 text-violet-700 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center space-x-1">' +
        '<i class="fa-solid fa-chart-line"></i>' +
        '<span>Test History</span>' +
        '</button>' +
        '</div>' +
        '</div>' +

        '<!-- Summary Score Cards -->' +
        '<div class="grid grid-cols-2 sm:grid-cols-5 gap-3">' +
        '<div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">' +
        '<div class="text-2xl font-black text-indigo-600 font-mono">' + score + ' / ' + totalMarks + '</div>' +
        '<div class="text-[10px] uppercase font-bold text-slate-500 mt-1">Total Score</div>' +
        '</div>' +
        '<div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">' +
        '<div class="text-2xl font-black ' + (percentage >= 70 ? 'text-emerald-600' : (percentage >= 40 ? 'text-amber-600' : 'text-rose-600')) + ' font-mono">' + percentage + '%</div>' +
        '<div class="text-[10px] uppercase font-bold text-slate-500 mt-1">Percentage</div>' +
        '</div>' +
        '<div class="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-center">' +
        '<div class="text-2xl font-black text-emerald-700 font-mono">' + correctCount + '</div>' +
        '<div class="text-[10px] uppercase font-bold text-emerald-800 mt-1">Correct</div>' +
        '</div>' +
        '<div class="p-4 bg-rose-50 rounded-2xl border border-rose-200 text-center">' +
        '<div class="text-2xl font-black text-rose-700 font-mono">' + wrongCount + '</div>' +
        '<div class="text-[10px] uppercase font-bold text-rose-800 mt-1">Wrong</div>' +
        '</div>' +
        '<div class="p-4 bg-violet-50 rounded-2xl border border-violet-200 text-center col-span-2 sm:col-span-1">' +
        '<div class="text-2xl font-black text-violet-700 font-mono">' + timeTaken + '</div>' +
        '<div class="text-[10px] uppercase font-bold text-violet-800 mt-1">Time Taken</div>' +
        '</div>' +
        '</div>' +

        '<!-- Per-Question Detailed Breakdown -->' +
        '<div class="space-y-3 pt-2">' +
        '<h3 class="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center justify-between">' +
        '<span>Question Evaluation Breakdown</span>' +
        '<span class="text-slate-500 font-normal">Attempted ' + attemptedCount + ' of ' + (result.totalQuestions || (result.questions ? result.questions.length : 0)) + '</span>' +
        '</h3>' +
        (result.questions || []).map((q, idx) => {
            const qText = q.questionText || q.question || ('Question ' + (idx + 1));
            const isCorrect = Boolean(q.isCorrect);
            const qAns = q.studentAnswer || 'Unanswered';
            const isUnans = (q.status === 'Unanswered' || !qAns || qAns.toLowerCase() === 'unanswered');

            let badgeHtml = '';
            let cardBorderBg = '';
            if (isCorrect) {
                badgeHtml = '<span class="text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded text-[10px]">CORRECT (+' + (q.marks || 1) + 'M)</span>';
                cardBorderBg = 'bg-emerald-50/40 border-emerald-200';
            } else if (isUnans) {
                badgeHtml = '<span class="text-amber-700 font-bold bg-amber-100 px-2 py-0.5 rounded text-[10px]">UNANSWERED (0M)</span>';
                cardBorderBg = 'bg-amber-50/30 border-amber-200';
            } else {
                badgeHtml = '<span class="text-rose-700 font-bold bg-rose-100 px-2 py-0.5 rounded text-[10px]">WRONG (0M)</span>';
                cardBorderBg = 'bg-rose-50/40 border-rose-200';
            }

            return '<div class="p-4 rounded-2xl border ' + cardBorderBg + ' text-xs space-y-2">' +
                '<div class="flex justify-between items-start font-bold gap-2">' +
                '<span class="text-slate-900 leading-snug">Q' + (idx + 1) + '. ' + qText + '</span>' +
                badgeHtml +
                '</div>' +
                '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] pt-1">' +
                '<div class="bg-white p-2.5 rounded-xl border border-slate-200"><span class="font-semibold text-slate-500">Your Answer:</span> <span class="font-bold ' + (isCorrect ? 'text-emerald-700' : (isUnans ? 'text-amber-600' : 'text-rose-600')) + '">' + qAns + '</span></div>' +
                '<div class="bg-white p-2.5 rounded-xl border border-slate-200"><span class="font-semibold text-slate-500">Correct Answer:</span> <span class="font-bold text-emerald-700">' + (q.correctAnswer || 'N/A') + '</span></div>' +
                '</div>' +
                (q.explanation ? '<div class="text-[11px] text-slate-700 bg-white/80 p-2.5 rounded-xl border border-slate-200"><span class="font-bold text-slate-900">Academic Explanation:</span> ' + q.explanation + '</div>' : '') +
                '</div>';
        }).join('') +
        '</div>' +
        '</div>';

    loadStudentAnalytics();
}

function resetStudentTestView() {
    activeMCQTest = null;
    latestStudentResult = null;
    studentSelectedAnswers = {};
    const configCard = document.getElementById('stuTestConfigCard') || document.getElementById('testSetupScreen');
    const activeContainer = document.getElementById('stuTestActiveContainer') || document.getElementById('testRunnerScreen');
    const resultContainer = document.getElementById('stuTestResultContainer') || document.getElementById('testResultScreen');

    if (configCard) configCard.classList.remove('hidden');
    if (activeContainer) activeContainer.classList.add('hidden');
    if (resultContainer) resultContainer.classList.add('hidden');
}

// Dual PDF 2: Post-Submission Result Scorecard PDF
async function downloadCurrentTestResultPDF() {
    if (!latestStudentResult) {
        showToast('No active result scorecard to download', true);
        return;
    }
    showToast('Generating Assessment Result Scorecard PDF...');

    try {
        const res = await fetch(API_BASE + '/api/tests/export-result-pdf', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(latestStudentResult)
        });

        if (!res.ok) throw new Error('Result PDF export failed');
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (latestStudentResult.subject || 'Assessment').replace(/\s+/g, '_') + '_Result_Scorecard.pdf';
        document.body.appendChild(a);
        a.click();
        a.remove();
        showToast('Scorecard PDF downloaded successfully!');
    } catch (err) {
        showToast('Failed to download scorecard PDF: ' + err.message, true);
    }
}

// --- STUDENT ANALYTICS & HISTORICAL PERFORMANCE ---
window.reviewHistoricalTest = function (testId) {
    const list = window._loadedStudentTestHistory || [];
    const found = list.find(t => String(t._id) === String(testId));
    if (found) {
        renderStudentResult(found);
        switchStudentTab('test');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
};

async function loadStudentAnalytics() {
    try {
        const user = (typeof getCurrentUser === 'function' ? getCurrentUser() : null) || currentUser || {};
        const studentId = user._id || user.id || 'all';
        const res = await fetch(API_BASE + '/api/tests/student/' + encodeURIComponent(studentId), {
            headers: getAuthHeaders()
        });
        const json = await res.json();
        const list = (json.data && Array.isArray(json.data)) ? json.data : [];

        // Cache list for review button lookup
        window._loadedStudentTestHistory = list;

        const takenEl = document.getElementById('statStudentTestsTaken');
        if (takenEl) takenEl.innerText = list.length;

        const avgEl = document.getElementById('statStudentAvgScore');
        if (avgEl) {
            if (list.length > 0) {
                const avg = (list.reduce((acc, curr) => acc + (curr.percentage || 0), 0) / list.length).toFixed(1);
                avgEl.innerText = avg + '%';
            } else {
                avgEl.innerText = '--';
            }
        }

        // Render in stuHistoricalResultsContainer (Student Portal Tab 5)
        const container = document.getElementById('stuHistoricalResultsContainer');
        if (container) {
            if (list.length === 0) {
                container.innerHTML = '<div class="text-center py-8 text-slate-400 text-xs">No previous test attempts found in database. Take an assessment from the MCQ Test tab!</div>';
            } else {
                container.innerHTML = list.map(item => {
                    const score = item.score !== undefined ? item.score : item.obtainedMarks;
                    const dateStr = new Date(item.submittedAt || item.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                    });
                    const isPass = (item.percentage || 0) >= 40;

                    return '<div class="p-4 bg-slate-50 hover:bg-slate-100/80 rounded-2xl border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 transition-colors">' +
                        '<div>' +
                        '<div class="flex flex-wrap items-center gap-2">' +
                        '<h4 class="font-bold text-slate-900 text-sm">' + item.subject + '</h4>' +
                        '<span class="text-[10px] font-bold bg-violet-100 text-violet-800 px-2 py-0.5 rounded">Semester ' + item.semester + (item.unit ? ' • Unit ' + item.unit : '') + '</span>' +
                        '<span class="text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-0.5 rounded">' + (item.difficulty || 'Medium') + '</span>' +
                        (item.timeTaken ? '<span class="text-[10px] font-medium text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded"><i class="fa-solid fa-stopwatch mr-1 text-slate-400"></i>' + item.timeTaken + '</span>' : '') +
                        '</div>' +
                        '<p class="text-xs text-slate-500 mt-1">' +
                        'Attempted on ' + dateStr + ' • Score: <strong class="text-slate-800">' + score + ' / ' + item.totalMarks + '</strong> ' +
                        '(<span class="font-bold ' + (isPass ? 'text-emerald-600' : 'text-rose-600') + '">' + item.percentage + '%</span>)' +
                        ' • ' + (item.correctAnswers !== undefined ? item.correctAnswers : item.correctCount) + ' Correct, ' +
                        (item.wrongAnswers !== undefined ? item.wrongAnswers : item.wrongCount) + ' Wrong' +
                        '</p>' +
                        '</div>' +
                        '<div class="flex items-center space-x-2 shrink-0">' +
                        '<button type="button" onclick="reviewHistoricalTest(\'' + item._id + '\')" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl flex items-center space-x-1 transition-all cursor-pointer">' +
                        '<i class="fa-solid fa-eye"></i>' +
                        '<span>Review</span>' +
                        '</button>' +
                        '<a href="' + API_BASE + '/api/tests/results/' + item._id + '/pdf" target="_blank" class="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl flex items-center space-x-1 cursor-pointer">' +
                        '<i class="fa-solid fa-file-pdf text-rose-500"></i>' +
                        '<span>PDF</span>' +
                        '</a>' +
                        '</div>' +
                        '</div>';
                }).join('');
            }
        }

        // Render in studentHistoricalAttemptsTable (Main landing student section)
        const tableBody = document.getElementById('studentHistoricalAttemptsTable');
        if (tableBody) {
            if (list.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="6" class="py-6 text-center text-slate-400">No previous test attempts recorded.</td></tr>';
            } else {
                tableBody.innerHTML = list.map(item => {
                    const score = item.score !== undefined ? item.score : item.obtainedMarks;
                    const dateStr = new Date(item.submittedAt || item.createdAt).toLocaleDateString();
                    return '<tr class="hover:bg-slate-50">' +
                        '<td class="py-3 px-3 font-bold text-slate-800">' + item.subject + '</td>' +
                        '<td class="py-3 px-3 text-slate-600">Semester ' + item.semester + ' • Unit ' + (item.unit || 1) + '</td>' +
                        '<td class="py-3 px-3 text-slate-500">' + dateStr + '</td>' +
                        '<td class="py-3 px-3 font-bold text-indigo-600">' + score + ' / ' + item.totalMarks + '</td>' +
                        '<td class="py-3 px-3 font-bold ' + (item.percentage >= 70 ? 'text-emerald-600' : (item.percentage >= 40 ? 'text-amber-600' : 'text-rose-600')) + '">' + item.percentage + '%</td>' +
                        '<td class="py-3 px-3 text-right space-x-1">' +
                        '<button onclick="reviewHistoricalTest(\'' + item._id + '\')" class="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg text-xs cursor-pointer">Review</button>' +
                        '<a href="' + API_BASE + '/api/tests/results/' + item._id + '/pdf" target="_blank" class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs inline-flex items-center"><i class="fa-solid fa-file-pdf text-rose-500 mr-1"></i> PDF</a>' +
                        '</td>' +
                        '</tr>';
                }).join('');
            }
        }
    } catch (err) {
        console.warn('Analytics fetch error:', err);
    }
}
// Auto-initialize section breakdown UI & profile button listeners if containers exist on page
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        initSectionBreakdownUI();
        attachProfileButtonListeners();
    });
} else {
    initSectionBreakdownUI();
    attachProfileButtonListeners();
}
function enableStudentProfileEdit() {
    toggleProfileEditMode(true);
}