// Faculty Module Initialization & Route Guard
window.addEventListener('DOMContentLoaded', async () => {
    loadUserFromStorage();
    if (!currentUser || !currentUser.token) {
        // Enforce RBAC: redirect unauthenticated user to login page
        window.location.replace('../index.html');
        return;
    }
    if (!currentUser.role || currentUser.role.toLowerCase() !== 'faculty') {
        // Enforce RBAC: redirect student attempting to access faculty to student dashboard
        window.location.replace('../student/index.html');
        return;
    }
    currentPortal = 'FACULTY';
    updateUserUI();
    await loadInitialData();
    if (typeof switchFacultyTab === 'function') {
        switchFacultyTab(currentFacultyTab || 'dashboard');
    }
});
