# AI Question Paper Generator & Student Assessment System
### Enterprise Full-Stack Architecture & Database Integration Blueprint

An autonomous, database-driven academic examination system featuring **AI Question Paper Synthesis**, **Bloom's Revised Taxonomy validation**, **Set A / Set B automated shuffling**, **real-time online MCQ testing**, and **topic mastery analytics**.

---

## 🏛️ System Architecture

```mermaid
graph TD
    subgraph ClientLayer ["Client Layer (Responsive SPA)"]
        FacultyUI["Faculty Portal (Syllabus, AI Gen, Shuffle, Profile)"]
        StudentUI["Student Portal (Q-Bank, Notes, MCQ Test, Analytics)"]
    end

    subgraph APILayer ["Backend REST API (FastAPI)"]
        AuthRouter["Auth & Profile Router (/api/auth)"]
        SyllabusRouter["Syllabus CRUD Router (/api/syllabus)"]
        PaperRouter["Question Paper & Shuffle Router (/api/papers)"]
        MaterialRouter["Study Materials Router (/api/study-materials)"]
        TestRouter["Online MCQ Test Runner (/api/tests)"]
        AnalyticsRouter["Performance Analytics Router (/api/analytics)"]
    end

    subgraph AIEngine ["AI Autonomous Generation Engine"]
        LLMService["Gemini 1.5 / OpenAI Structured API"]
        PromptEngine["Bloom's Taxonomy Context Synthesizer"]
        ShuffleEngine["Set A -> Set B Option Permutation Engine"]
    end

    subgraph DataLayer ["Relational Database (PostgreSQL / SQLite)"]
        UsersTbl[("users")]
        SyllabusTbl[("syllabus_units & syllabus_topics")]
        PapersTbl[("question_papers & questions")]
        MaterialsTbl[("study_materials")]
        AttemptsTbl[("test_attempts & student_answers")]
        AnalyticsTbl[("performance_summaries")]
    end

    FacultyUI --> APILayer
    StudentUI --> APILayer
    PaperRouter --> AIEngine
    AIEngine --> PromptEngine --> LLMService
    PaperRouter --> ShuffleEngine
    APILayer --> DataLayer
```

---

## 📊 Database Schema Design (Entity Relationships)

```mermaid
erDiagram
    users ||--o{ syllabus_units : "faculty creates"
    users ||--o{ question_papers : "faculty authors"
    users ||--o{ study_materials : "faculty uploads"
    users ||--o{ test_attempts : "student takes"
    users ||--o{ performance_summaries : "student tracks"

    syllabus_units ||--|{ syllabus_topics : "contains"
    syllabus_units ||--o{ study_materials : "associated with"

    syllabus_topics ||--o{ questions : "mapped to"

    question_papers ||--|{ questions : "composed of"
    question_papers ||--o{ test_attempts : "attempted in"

    test_attempts ||--|{ student_answers : "records"
    questions ||--o{ student_answers : "evaluates"
```

---

## 🚀 Quickstart & Step-by-Step Setup

### Step 1: Clone or Navigate to Directory
```powershell
cd C:\Users\ELCOT\.gemini\antigravity\scratch\ai-assessment-system
```

### Step 2: Install Python Backend Dependencies
```bash
pip install -r backend/requirements.txt
```

### Step 3: Configure Environment Variables (Optional)
Create a `.env` file in the root or set in terminal:
```bash
# Optional: Set your Gemini or OpenAI API Key for live LLM generation
# If omitted, high-fidelity academic heuristic fallback will automatically execute!
export GEMINI_API_KEY="your-gemini-api-key"
export DATABASE_URL="sqlite:///./assessment_system.db" # Or postgresql://user:pass@localhost:5432/exam_db
```

### Step 4: Run the Backend & Frontend Server
```bash
cd backend
python -m uvicorn main:app --reload --port 8000
```

- **Interactive Web Application**: `http://localhost:8000/`
- **Interactive Swagger REST API Docs**: `http://localhost:8000/docs`
- **Alternative ReDoc Documentation**: `http://localhost:8000/redoc`

---

## 📑 Core Module Endpoints & Database Operations

| Module | HTTP Method | Endpoint | Database Action |
| :--- | :--- | :--- | :--- |
| **Auth & Profile** | `POST` | `/api/auth/register` | Inserts new user credentials into `users` table |
| **Auth & Profile** | `POST` | `/api/auth/login` | Validates hash and issues JWT access token |
| **Auth & Profile** | `GET` / `PUT` | `/api/auth/profile` | Reads / updates faculty and student profile fields |
| **Syllabus** | `POST` | `/api/syllabus/units` | Inserts unit & nested topics into `syllabus_units` & `syllabus_topics` |
| **Syllabus** | `GET` | `/api/syllabus/units` | Fetches units by subject or faculty with eager-loaded topics |
| **Syllabus** | `PUT` / `DELETE`| `/api/syllabus/units/{id}`| Updates / cascades deletion to child topics |
| **AI Paper Gen** | `POST` | `/api/papers/generate-ai`| Queries DB syllabus $\rightarrow$ prompts LLM $\rightarrow$ persists paper & questions to DB |
| **Paper Shuffle**| `POST` | `/api/papers/shuffle` | Copies paper, permutes question order & remaps MCQ options $\rightarrow$ saves Set B to DB |
| **Paper Publish**| `PATCH`| `/api/papers/{id}/publish`| Toggles student visibility flag `is_published` |
| **Study Materials**| `POST` / `GET` | `/api/study-materials/` | CRUD for syllabus-mapped PDFs, slides, and reference links |
| **MCQ Online Test**| `GET` | `/api/tests/active/{id}` | Fetches active test for student (masks `correct_answer` & explanations) |
| **MCQ Online Test**| `POST` | `/api/tests/submit` | Auto-grades responses $\rightarrow$ records `test_attempts` & `student_answers` $\rightarrow$ updates topic mastery |
| **Analytics** | `GET` | `/api/analytics/student/{id}`| Aggregates score distributions, strengths, weaknesses & history |
